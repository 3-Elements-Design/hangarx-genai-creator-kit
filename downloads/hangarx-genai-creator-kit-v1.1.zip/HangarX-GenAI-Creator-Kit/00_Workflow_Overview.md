# Workflow Overview — Concept to Release in Seven Phases

The seven-phase arc the kit is built around. Every Part in the kit slots into one of these phases. Run them roughly in order. Loop back to earlier phases whenever the system tells you to.

---

## Phase 1 — Define the film

**Goal:** Produce one paragraph that is true.

Logline, theme, central question, runtime, emotional arc, ending. The deliverable is a single one-page document a stranger can read and understand what you're making and why.

If you can't write Phase 1 in plain language, you don't have a film yet. Don't generate anything until you can.

> *See Part I — Story Foundations.*

## Phase 2 — Build the world system

**Goal:** Make the world legible to a machine.

World rules, hidden logic, what's normal here, what's secret here, the thematic contradiction. Plus the **visual language** (palette, texture, lensing, atmosphere) and **audio language** (motifs, room tone, signature cues) — both treated as load-bearing infrastructure, not decoration.

The output is a *world file* you can paste into any prompt.

> *See Part II — Worldbuilding & Continuity.*

## Phase 3 — Lock continuity

**Goal:** Make your characters the same person in clip 1 and clip 40.

For each character: face/body rules, wardrobe logic, performance range, lighting relationship, and a **Continuity Prompt Base Block** that gets pasted into every image and video prompt that includes them.

If you skip this phase you will spend Phase 7 trying to fix it. You won't be able to.

> *See Part II — Worldbuilding & Continuity.*

## Phase 4 — Design clip architecture

**Goal:** Plot the film as a clip grid, not a script.

Apply the 15-second clip rule and the three-jobs principle (atmosphere + information + handoff) to design the full grid — for HangarX, 40 clips × 15 seconds = 10 minutes. Map escalation per act. Identify the high-pressure clips and the breath clips.

The deliverable is a single table: clip # → time → purpose → three jobs → motif. This becomes the spine for everything downstream.

> *See Part III — Clip Architecture.*

## Phase 5 — Write model-specific prompts

**Goal:** Translate each clip into prompts your tools can execute.

One clip can become four prompts — image prompt (for the still or storyboard), video prompt (for the motion), voice prompt (for the line), music brief (for the bed). Each model has its own structural quirks; the kit gives you the skeleton for each.

Same beat, different engines, side-by-side. Pick the right tool per beat instead of forcing one tool to do everything.

> *See Part IV — Prompting System.*

## Phase 6 — Add audio structure

**Goal:** Treat sound as a load-bearing wall.

Score the room tone, the motif cues, the coherence tones, the silences. Place them on the clip grid. Direct the VO with breath and pacing, not just text.

A film with poor audio architecture feels disconnected even when the visuals are perfect. A film with strong audio architecture can survive imperfect visuals.

> *See Part V — Audio & Performance.*

## Phase 7 — Iterate, assemble, publish

**Goal:** Find the weak clips. Fix them. Ship.

Run the iteration loop on the scenes that are almost-but-not-quite. (The kit shows four before/after rewrites from HangarX.) Run the QA checklists. Assemble. Package for release with a folder structure that survives festival submission, collaborator handoff, and your own memory three months later.

> *See Part VI — Production Assembly.*

---

## When to loop back

| Symptom in Phase 7 | Phase to revisit |
|---|---|
| Characters look like different people across clips | 3 (continuity) |
| Scenes are beautiful but boring | 4 (clip architecture — handoffs missing) |
| The film feels disjointed even though every clip is good | 6 (audio — no through-line) |
| You can't explain what the film is about in one sentence | 1 (story foundations) |
| A specific tool keeps giving you slop for this scene | 5 (wrong engine for this beat) |
| The world feels generic | 2 (visual + audio language too thin) |

---

## The graphic novel branch

If you're producing a graphic novel companion (or only the graphic novel), Phases 1–3 are identical. Phase 4 swaps the clip grid for a page grid. Phase 5 swaps prompt models. Phase 6 becomes lettering and pacing rather than audio. Phase 7 is the same.

> *See Part VII — Graphic Novel Companion.*
