# Core Principles

Six rules that govern every decision in this kit. When you're stuck, when a clip isn't working, when a prompt won't behave — one of these is probably broken. Reread them.

---

## 1. Every clip must do three jobs

Every shot in your film does at least three things at once:

- **Atmosphere** — establishes mood, place, palette, sensory state.
- **Information** — tells the audience something they did not know before.
- **Handoff** — sets up the next clip so the cut feels inevitable.

A clip that only delivers atmosphere is decoration. A clip that only delivers information is exposition. A clip that doesn't hand off creates a film that feels like a slideshow.

When a clip is failing, ask which of the three it's missing. Then add it.

> **HangarX example.** Clip 02 (HELIX's apartment, dawn). *Atmosphere:* lonely dawn noir, sparse city hum. *Information:* she is alone, exhausted, but watching something most people aren't. *Handoff:* her coffee cup discrepancy in the window reflection — the anomaly that triggers Clip 03's investigation.

## 2. Continuity packs are essential

Your protagonist is one person. The machine doesn't know that. Without an explicit, paste-into-every-prompt **Continuity Prompt Base Block**, your character will drift — different cheekbones, different age, different posture — clip to clip.

A continuity pack is not a vibe. It's a literal block of text covering face geometry, age, build, wardrobe rules, lighting relationship, and emotional baseline. It's boring to write. It's the single highest-leverage thing in the kit.

> *See Part II — Worldbuilding & Continuity, file `03_character_continuity_file.md`.*

## 3. Audio is structural

Sound is not "added in post." Sound is plotted on the same grid as the clips, and often before. The motif cue (HangarX's `BWEEE-OOP` notification), the room tone, the coherence harmonic, the silences — all of these are load-bearing. A film with thin audio architecture feels untethered no matter how strong the visuals.

If you can't describe your film's audio in one paragraph the way you describe its visuals, your audio architecture is missing. Build it.

> *See Part V — Audio & Performance.*

## 4. A system beats a prompt dump

Two hundred good prompts that you wrote in a blur, in different formats, with no continuity blocks, do not compound. Forty mediocre prompts that all share the same continuity pack, the same world file, the same audio motif library — those compound into a film.

The system is the unit of value. Prompts are interchangeable inputs to it.

## 5. Story logic must survive the tools

Tools constrain what you can shoot. Sora can't easily do certain camera moves. Voice models drop emotional range under three seconds. Image models hate certain compositions. These constraints will pull your film toward the things they can do — and away from the things your story needs.

Decide what the story needs **first**, in plain language (Phase 1). Then translate to tools. Don't let the tools write the film.

When a tool can't deliver a beat your story needs, you have three options, in order:
1. Find a different tool that can.
2. Rewrite the beat to use what the tool *can* do — without losing meaning.
3. Cut the beat. The film is better without a half-rendered version of it.

Never do option 4: keep the half-rendered version.

## 6. Small improvements compound

A film is forty 15-second clips (or forty graphic-novel pages). If each clip is 5% better than it could have been, the film is *not* 5% better — it's substantially more than that, because each weak clip is a permission slip for the audience to disengage. Two weak clips in a row and the audience is out.

Run the iteration loop (Part VI) on the clips that are 80%. Get them to 95%. The film changes.

---

## Reading these together

These six aren't independent. They're aspects of the same idea: **GenAI filmmaking succeeds when treated as production**, not as prompting. Production has continuity, audio, iteration, architecture, and a story that's been thought through before the tools turn on. The kit is built to make that production stance the default.
