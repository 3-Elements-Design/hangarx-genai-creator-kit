# The Fifteen Second Rule

**Phase 4 · Design clip architecture**

## Why this matters

Most GenAI films break for the same boring reason: someone tried to shoot a two-minute scene with a tool that performs best at five to ten seconds. The model hallucinates an extra finger. The lighting drifts mid-shot. A face becomes a different face. By the time the clip is salvageable, you have spent more compute than the entire rest of the film and the cut is still soft.

Fifteen seconds is the structural unit that survives current GenAI video. It is long enough to carry one image with one motion and one beat of meaning. It is short enough to regenerate cleanly when a take fails, which it will. And it forces the kind of narrative compression that punishes mood-only filmmaking — the disease that kills almost every AI short on the internet.

HANGAR X is built on forty fifteen-second clips plus two shorter ending beats. That is not a coincidence. It is the discipline that let a 10-minute philosophical techno-thriller hold its shape across thousands of generations without the protagonist quietly becoming three different people.

## The rule

**Default every clip to 15 seconds. Break that default only with a written reason.**

The rule has three justifications, in order of importance:

1. **Generation quality.** Current image-to-video and text-to-video models hit their sweet spot at 5–10 seconds. At 15 seconds you get one beat of breathing room past the sweet spot — enough for an action and a small follow-through — without entering the territory where coherence collapses. Most providers either cap at this range or charge punishingly above it.

2. **Narrative compression.** A 15-second clip can hold one image with one motion. That is it. Trying to fit two ideas into a clip is the most common pacing failure in GenAI cinema. The 15-second box forces you to choose, which forces the script to escalate.

3. **Iteration economics.** You will regenerate every clip 3–10 times. A 15-second unit is cheap enough to throw away without flinching, and small enough that a failed take does not cascade through the timeline.

### When to break the rule

Break the 15-second default only for one of these reasons:

- **Unbroken VO monologue.** A philosophical bridge that needs to land as one breath. HangarX uses this for Clip 40.1 — five seconds is the wrong shape for the line, so the clip stretches as needed against a near-static image where generation risk is low.
- **Signature held shot.** A deliberate stillness as a thesis statement, usually at the end. HangarX Clip 41 is five seconds; the reflection mismatch only works if held for exactly the right interval. Held shots can also be longer than 15s if the image is stable enough to survive it.
- **Hard cut sting.** A 2–5 second beat used as punctuation, not a scene. Use sparingly — three of these in a row reads as a music video.
- **Coverage clip.** A B-roll or insert intentionally short because it carries a single piece of information you cut to and away from.

If you cannot write the reason on one line, you do not have one. Go back to 15 seconds.

## Clip-length trade-offs

| Length | Best for | Risk | Generation cost |
|---|---|---|---|
| 5s | Sting, insert, signature held shot, end beat | Feels like a GIF if used in sequence; no room for action arc | Cheapest |
| 10s | Single action with clean entry and exit | Easy to over-compress story; tempting to use as default | Cheap |
| **15s** | **One image, one motion, one beat of meaning** | **Just past the generation sweet spot — failed takes more common** | **Standard** |
| 30s | Sustained dialogue exchange, complex blocking | Coherence drift, identity drift, expensive iteration, often needs to be split anyway | Expensive |

The lesson buried in this table: there is no honest reason to default to 30s in a GenAI short film today. Two 15s clips with a hard cut between them will almost always cut better than one 30s clip pretending to be a continuous take. The hard cut is free narrative pressure.

## HangarX filled example

HangarX is 40 primary clips × 15 seconds, plus two ending refinement beats:

- **Clip 40.1** (5 seconds) — HELIX holds the coffee. The apartment continues making tiny anticipatory decisions before she requests them. A philosophical bridge VO carries across the held image. The clip is shorter than 15s because the image is intentionally static and the line is what is doing the work.
- **Clip 41** (5 seconds) — The reflection mismatch. One sip. One frame of discrepancy. Cut to black. A signature held shot. Longer would dilute the destabilization; shorter would not let it land.

Everything else holds the 15-second default. That includes Clip 24 (VALE's full ideological broadcast — yes, the whole "latency failure" doctrine fits in 15 seconds because the language was compressed to fit) and Clip 33 (the HELIX-VALE confrontation, where the two lines were tuned until they fit the box).

The compression in Clip 24 is the most instructive moment. The original draft of VALE's broadcast was twice as long. Forcing it to 15 seconds did not weaken it — it made it surgical. "We do not lack empathy. We lack synchronization." That line exists because the clip length demanded it.

## Checklist

- [ ] Default clip length is set to 15 seconds across the whole grid
- [ ] Every exception to 15 seconds has a one-line written reason
- [ ] No clip is longer than 30 seconds without a structural argument
- [ ] No three sub-10-second clips appear in a row outside an intentional montage
- [ ] The total clip count × 15 seconds is within 10% of the target runtime
- [ ] Each 15-second clip carries one image with one motion (not two)
- [ ] Dialogue-heavy clips have been read aloud against a 15-second timer
- [ ] Held shots and stings are budgeted, not accidental

## Common failure modes

- **Letting clips run long because the model "looks good at 24 seconds in this one case."** It does, until the next clip needs to inherit motion from it and the math breaks. Pick a unit and hold it.
- **Treating every clip as a held shot.** Three meditative stillnesses in a row is not a film. It is a screensaver.
- **Compressing dialogue to fit the clip and ending up with stilted exposition.** If the line will not fit, the line is wrong. Rewrite it shorter, or split across two clips with a cut on the beat.
- **Padding to fill the 15 seconds.** If the clip's image-motion-beat is done at 9 seconds, do not invent 6 seconds of drift. Cut earlier and let the next clip carry the inheritance.
- **Mixing units arbitrarily — some 12s, some 18s, some 22s.** Pick 15s as the spine. Earn every deviation with a note in the grid.
- **Forgetting the ending beats exist outside the count.** HangarX is "40 clips × 15s" but the film is 10 minutes 5 seconds because of 40.1 and 41. Budget for them up front.
