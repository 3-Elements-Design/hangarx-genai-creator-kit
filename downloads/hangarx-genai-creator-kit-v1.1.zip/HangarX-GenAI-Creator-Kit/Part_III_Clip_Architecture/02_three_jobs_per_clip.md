# The Three Jobs Per Clip

**Phase 4 · Design clip architecture**

## Why this matters

The single most useful sentence in this kit is the one this section is named after. Every clip must do three jobs: create atmosphere, deliver information, and hand off to the next clip. If any of the three is missing, the clip is not finished.

This rule is what separates a GenAI short film from a slideshow of beautiful generations set to music. Atmosphere alone produces drift. Information alone produces a textbook. Handoffs alone produce a trailer that promises a film that does not exist. You need all three on every shot. The early HangarX cuts had clips that did one job brilliantly and the other two not at all — gorgeous loft at dawn, no anomaly, no pressure into the next beat. Result: the audience admired the frame and then drifted off.

The rule is also a diagnostic. When a clip is not landing, do not rewrite from scratch. Ask which of the three jobs it is failing. The fix is usually surgical: an earlier anomaly, a sharper line, a sound tail that carries into the next shot. One fix per missing job.

## The framework

Every clip carries three loads simultaneously. Think of them as three lines on a checklist, not three separate scenes.

### Job 1 — Atmosphere

**What the clip feels like.** The mood, the world state, the emotional weather. This is what GenAI tools deliver best — palette, lighting, texture, camera grammar, ambient sound. Most filmmakers oversolve this and undersolve the other two.

Failure modes:
- The clip is "moody" but you cannot name the specific feeling in one word
- Two adjacent clips have the same atmosphere with no progression
- Atmosphere is doing the work that information should be doing — i.e., the audience is supposed to "feel" something is wrong but no actual fact has been revealed
- The atmosphere contradicts the world rules (sudden golden hour in a film that lives in dawn-blue)

### Job 2 — Information

**What the clip teaches the audience.** Something the viewer did not know before this clip and will need going forward. A character fact, a world fact, a system fact, a relationship shift, a new threat, a new question. One per clip, minimum. Two is fine. Zero is a failure.

This is the job GenAI films most often skip. They assume "atmosphere conveys information." It does not. Atmosphere conveys feeling. Information requires a discrete revealable thing — an anomaly on a screen, a line of dialogue, a prop, a glance, a door closing.

Failure modes:
- You cannot finish the sentence "in this clip, the audience learns that ____"
- The information is buried — the reveal is in the corner of the frame instead of the center
- The information arrives via voiceover only, with no visual partner
- The same information is being delivered by two clips in a row (cut one)

### Job 3 — Handoff

**What carries the audience into the next clip.** A question, a sound, a motion vector, an emotional pressure, an unresolved image. The handoff is the thing the next clip inherits. Without it, you do not have a film. You have an anthology of vignettes.

Handoff is the most often-forgotten job because it is the one that points outside the clip. Atmosphere and information feel like they live inside the shot. Handoff is the rope you tie to the next shot's hand.

Failure modes:
- The clip resolves cleanly — feels finished, like a short film of its own
- The audio tail is silent, with no motif carrying into the next clip
- The visual is closed (subject exits frame, light dims to black, action completes)
- The question raised in the clip is also answered in the clip
- The next clip has to reset the audience instead of pulling them through

## How to use it

For every clip on the grid, write three short phrases. Not paragraphs. Phrases.

```
Clip XX
- Atmosphere: [one word or one phrase — the feeling]
- Information: [in this clip the audience learns ____]
- Handoff: [what carries forward — question / sound / motion / pressure]
```

If you cannot fill all three in under 30 seconds, the clip is not designed yet. Do not write the prompt. Do not generate. Go back and finish the clip's job sheet first.

## HangarX filled example

**Clip 2 (0:15–0:30) — Berlin at dawn through floor-to-ceiling loft windows. HELIX at workstation. Ambient agent streams move around her before she acts.**

- **Atmosphere:** lonely noir dawn. The world from Clip 1 narrowing into a single private space. Cool blue exterior, warm amber interface spill, the loft as a watchtower over a city that has already surrendered.
- **Information:** HELIX exists. She is the kind of person who notices systems when they stop asking. The VO seeds this directly: "Most people only noticed AI when it helped them. HELIX noticed it when it stopped asking." We learn what she does, what she sees, and the specific quality of attention she brings.
- **Handoff:** the anomaly is about to appear on her screens. Ambient agent streams already moving before she acts is the visual seed for the synchronization reveal in Clip 3. The audio carries city hum from Clip 1 directly into the loft tone, so the cut is felt as a zoom, not a jump.

That is what the three-jobs sheet looks like when it works. Notice how each job is one phrase, and how the handoff specifically names what Clip 3 will receive. The early version of this clip had only the atmosphere line. That is why it played as a beautiful but inert mood board. Adding the information job (the VO line about HELIX's specific attention) and the handoff job (the agent streams pre-acting) is what made it part of a film.

**Clip 24 (5:45–6:00) — VALE's broadcast.**

- **Atmosphere:** persuasive apocalypse. Severe symmetry, glass-walled chamber, broadcast-clean voice, no villain theater.
- **Information:** VALE's ideology in one compressed paragraph — collapse is a latency problem, not a moral one. The audience learns why he could convince people, which is harder and more frightening than learning that he is wrong.
- **Handoff:** the broadcast continues into the world we cut to next. The authentication shimmer behind VALE seeds the reality-authentication thread. His doctrine is the pressure HELIX has to answer in subsequent clips — the handoff is intellectual, not just sonic.

## Checklist

- [ ] Every clip on the grid has all three jobs filled in
- [ ] Atmosphere job is one word or one short phrase, not a paragraph
- [ ] Information job completes the sentence "the audience learns that ____"
- [ ] Handoff job specifically names what the next clip inherits
- [ ] No two adjacent clips share the same atmosphere unless intentional
- [ ] No clip's information is redundant with the previous clip's
- [ ] No clip resolves cleanly without handoff (last clip excepted)
- [ ] Failed clips have been diagnosed against the three jobs before rewrite

## Common failure modes

- **Three-jobs sheet written after the prompt instead of before.** Reverse the order. Jobs first, prompt second. Otherwise the prompt writes the clip's purpose, which means the tool writes your film.
- **Atmosphere overloaded with adjectives, information vague.** "Cinematic moody noir loft with restrained amber and cyan and 35mm grain" is not three jobs. It is one job in a tuxedo. Cut the adjectives, add the missing two jobs.
- **Information delivered only by VO.** The audience should be able to identify the new fact with the sound off. If they cannot, the visual is not carrying its share.
- **Handoffs that are just "cut to next scene."** A cut is not a handoff. A handoff is an unresolved force — a sound motif, an unanswered question, a motion vector. Name it.
- **The same handoff used three clips in a row.** "BWEEE-OOP tail into next clip" is a fine handoff once. Used four times in five minutes, it becomes wallpaper.
- **Confusing handoff with cliffhanger.** Every clip does not need to end on a beat of suspense. The handoff can be tonal, sonic, or visual. It just needs to point outside the clip.
