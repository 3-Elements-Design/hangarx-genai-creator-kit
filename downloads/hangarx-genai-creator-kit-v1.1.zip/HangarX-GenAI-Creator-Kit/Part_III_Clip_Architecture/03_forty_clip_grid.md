# The Forty Clip Grid

**Phase 4 · Design clip architecture**

## Why this matters

The 40-clip grid is the single most important production artifact in this kit. It is not a script. It is not a shot list. It is the spreadsheet view of your entire film on one page, where every clip's purpose, atmosphere, information, handoff, and audio motif sit side by side. If something is going wrong with the pacing, you can see it before you have generated a frame.

Most GenAI shorts fail before they are made because no one ever looks at the whole film at once. There is a folder of prompts, a Notion page of character refs, a doc of dialogue, a separate doc of sound notes. The connections between clips live nowhere. The grid is what forces them to live somewhere. It is the artifact that turns "I have a story" into "I have a film I can build."

HangarX would not exist without the grid. The opening had to be rebuilt twice; the only reason that was possible was that the grid showed, at a glance, that clips 1–10 were doing too much atmosphere and not enough information. You cannot see that in a script. You can see it in the grid.

## What goes on the grid

Seven columns. Hold the line. Do not add columns until you can answer why.

| Column | What it holds | Why it is on the grid |
|---|---|---|
| **Clip #** | Integer or decimal (40.1, 41) | The atomic unit of the film |
| **Time** | mm:ss–mm:ss | Forces the math to work; surfaces runtime drift |
| **Purpose** | One sentence — why this clip exists | The clip's job in the film, distinct from its content |
| **Atmosphere** | One phrase — the mood / world state | Job 1 of the three jobs |
| **Information** | One phrase — what the audience learns | Job 2 of the three jobs |
| **Handoff** | One phrase — what carries into next clip | Job 3 of the three jobs |
| **Audio motif** | One phrase — recurring sound element | The connective tissue across cuts |

Optional eighth column for production-heavy projects: **Location / continuity tag** (which continuity pack the clip pulls from). For smaller films this can live in the per-clip breakdown card instead of on the grid.

That is it. The grid is a navigation surface. Detail lives in the per-clip breakdown (see file 04). Resist the urge to put dialogue, prompts, or camera notes on the grid. They will make it unreadable and you will stop using it, which is the worst thing that can happen to the most important artifact in the project.

## How to build it

1. **Start with the act structure.** Five acts is HangarX's structure (curiosity → descent → revelation → consequence → mismatch ending). Three or four acts is fine. The act breakdown determines roughly where major beats land — what clip number contains the inciting reveal, the midpoint, the climax, the ending pivot.

2. **Number the clips and time them out.** At 15 seconds default, 40 clips = 10 minutes. Most short films sit between 24 clips (6 minutes) and 60 clips (15 minutes). Write the time column second — it does the math for you and surfaces structural problems immediately.

3. **Fill Purpose for every clip first.** Not Atmosphere. Purpose. One sentence per clip: why does this clip exist in the film? If you cannot write Purpose without describing the visual, the clip does not yet have a story reason to exist.

4. **Fill the three jobs across all rows.** Do not work clip by clip. Work column by column. Filling Atmosphere across all 40 rows surfaces which acts are atmospherically homogenous. Filling Information across all rows surfaces gaps where nothing new is being learned for three clips in a row. Filling Handoff across all rows surfaces breaks in the chain.

5. **Add audio motifs last.** Audio is the glue. It is easier to map once the story spine is locked. Look for motifs that can recur — HangarX uses BWEEE-OOP, a coherence tone, a data whisper layer. Mark which clips carry which.

6. **Read the grid as a single document.** End to end. Out loud if you can. The grid should read like a one-page film. If it does not, fix the grid before you fix the prompts.

## The blank 40-row grid

Copy this table into your project doc. Fill the columns left to right, one column at a time across all rows, not row by row.

| Clip # | Time | Purpose | Atmosphere | Information | Handoff | Audio motif |
|---|---|---|---|---|---|---|
| 1 | 0:00–0:15 |  |  |  |  |  |
| 2 | 0:15–0:30 |  |  |  |  |  |
| 3 | 0:30–0:45 |  |  |  |  |  |
| 4 | 0:45–1:00 |  |  |  |  |  |
| 5 | 1:00–1:15 |  |  |  |  |  |
| 6 | 1:15–1:30 |  |  |  |  |  |
| 7 | 1:30–1:45 |  |  |  |  |  |
| 8 | 1:45–2:00 |  |  |  |  |  |
| 9 | 2:00–2:15 |  |  |  |  |  |
| 10 | 2:15–2:30 |  |  |  |  |  |
| 11 | 2:30–2:45 |  |  |  |  |  |
| 12 | 2:45–3:00 |  |  |  |  |  |
| 13 | 3:00–3:15 |  |  |  |  |  |
| 14 | 3:15–3:30 |  |  |  |  |  |
| 15 | 3:30–3:45 |  |  |  |  |  |
| 16 | 3:45–4:00 |  |  |  |  |  |
| 17 | 4:00–4:15 |  |  |  |  |  |
| 18 | 4:15–4:30 |  |  |  |  |  |
| 19 | 4:30–4:45 |  |  |  |  |  |
| 20 | 4:45–5:00 |  |  |  |  |  |
| 21 | 5:00–5:15 |  |  |  |  |  |
| 22 | 5:15–5:30 |  |  |  |  |  |
| 23 | 5:30–5:45 |  |  |  |  |  |
| 24 | 5:45–6:00 |  |  |  |  |  |
| 25 | 6:00–6:15 |  |  |  |  |  |
| 26 | 6:15–6:30 |  |  |  |  |  |
| 27 | 6:30–6:45 |  |  |  |  |  |
| 28 | 6:45–7:00 |  |  |  |  |  |
| 29 | 7:00–7:15 |  |  |  |  |  |
| 30 | 7:15–7:30 |  |  |  |  |  |
| 31 | 7:30–7:45 |  |  |  |  |  |
| 32 | 7:45–8:00 |  |  |  |  |  |
| 33 | 8:00–8:15 |  |  |  |  |  |
| 34 | 8:15–8:30 |  |  |  |  |  |
| 35 | 8:30–8:45 |  |  |  |  |  |
| 36 | 8:45–9:00 |  |  |  |  |  |
| 37 | 9:00–9:15 |  |  |  |  |  |
| 38 | 9:15–9:30 |  |  |  |  |  |
| 39 | 9:30–9:45 |  |  |  |  |  |
| 40 | 9:45–10:00 |  |  |  |  |  |
| 40.1 | bridge | optional philosophical/held beat |  |  |  |  |
| 41 | 10:00–10:05 | optional ending signature shot |  |  |  |  |

If your film is 24 clips, delete rows 25–40. If your film is 60 clips, add rows 41–60 and adjust the time column. Keep the structure.

## HangarX filled example

The full HangarX 40-clip grid is in **`examples_HangarX/III_clip_grid_filled.md`**. That file is the worked example for this template — every row filled, every column populated, with notes on which clips are anchored directly in the source script and which were extrapolated by working forward from the act structure and the existing nine anchor clips.

A short excerpt to show shape:

| Clip # | Time | Purpose | Atmosphere | Information | Handoff | Audio motif |
|---|---|---|---|---|---|---|
| 1 | 0:00–0:15 | Establish the delegated world | Delegated urban calm | AI has reorganized daily life, not conquered it | Narrows from social world into HELIX's private reality | City hum, transit tones, BWEEE-OOP tail |
| 2 | 0:15–0:30 | Bridge from thesis to protagonist POV | Lonely noir dawn | HELIX notices when systems stop asking | Anomaly is about to appear on her screens | City hum carried into loft tone |
| 3 | 0:30–0:45 | Convert unease into diagnosis | Investigative tension | Impossible synchronization across millions of agents | Hidden-layer reveal incoming | Coherence tone, synchronized clicks |
| 4 | 0:45–1:00 | Reveal hidden architecture | Forbidden system descent | Cortex exists under visible infrastructure | Leads to the impossible file | Low amber-gold hum |

Read the full grid in the examples file. It is the artifact you will refer to most often during production.

## Checklist

- [ ] Grid exists as a single readable document, not scattered across files
- [ ] Seven columns: Clip # / Time / Purpose / Atmosphere / Information / Handoff / Audio motif
- [ ] Every row's time math is consistent with the chosen clip length
- [ ] Purpose column filled for every clip before any other column
- [ ] No two adjacent clips share both Atmosphere and Information (one or the other can repeat, not both)
- [ ] Handoff column reads as a continuous chain top to bottom
- [ ] Audio motif column shows recurring elements, not unique sounds per clip
- [ ] Ending beats (40.1, 41 or equivalent) are on the grid even if outside the main count
- [ ] Grid has been read end to end as a single document at least once
- [ ] Grid is updated when clips are revised, not abandoned for the new draft

## Common failure modes

- **Building the grid after generating clips instead of before.** Now the grid is documentation, not a design tool. Build the grid first. Generate against it.
- **Letting columns sprawl.** Once "Dialogue," "Camera," "Prompt notes," and "Render status" appear as columns, the grid becomes a project tracker. The grid should be readable on one screen. Detail goes on the per-clip card.
- **Filling row by row.** Working clip 1 to clip 40 means clip 1 gets your best thinking and clip 40 gets your most exhausted. Work column by column instead — Purpose across all 40 first, then Atmosphere across all 40, and so on. The film stays consistent that way.
- **Treating the grid as fixed.** It is a living artifact. When you revise a clip, update the row. A grid that diverges from the cut is worse than no grid.
- **Hiding bad clips in the grid by writing Purpose as "transition" or "atmosphere."** Those are not purposes. They are excuses. If the clip's only purpose is to be a transition, it should not exist on its own row — fold it into the adjacent clip.
- **Skipping the audio motif column because "we will figure it out in post."** You will not. The motif column is where the film's sonic spine lives. Fill it during design or your audio pass will be a panic.
- **Drifting time column.** If the math stops working — clips don't sum to runtime — your structure is broken and you need to know now, not at the cut.
