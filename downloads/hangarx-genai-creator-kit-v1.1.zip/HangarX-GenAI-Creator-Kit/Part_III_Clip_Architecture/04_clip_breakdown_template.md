# Clip Breakdown Template

**Phase 4 · Design clip architecture**

## Why this matters

The grid tells you what the film is. The clip breakdown tells you what the shot is. One card per clip. This is the artifact you take into prompt-writing, generation, and audio — the page where everything about that fifteen seconds of film lives.

If the grid is the spreadsheet view, the breakdown is the storyboard cell. You need both. The grid prevents you from losing the film. The breakdown prevents you from losing the shot. Skipping the breakdown is the single fastest way to end up with a folder of beautiful generations that do not belong to the same film, because the person writing the prompt did not have the per-clip facts in front of them.

HangarX has a breakdown card for every clip. The card is what the prompt writer references when building the Seedance prompt. The card is what the audio designer references when choosing motifs. The card is what survives when a clip needs to be regenerated three weeks later and the original intent has gone fuzzy.

## The template

One card per clip. Keep each field tight. This is a working document, not a screenplay.

```markdown
# Clip [Number]

**Time:** [mm:ss–mm:ss]
**Location:** [Where in the world of the film]
**Subject:** [Who or what is the focus]
**Continuity pack:** [Which character / location pack governs this clip]

## Action
[What happens on screen. Past-tense or present-tense, one beat. Not a screenplay paragraph — one or two sentences describing the motion arc from frame-in to frame-out.]

## Cinematography
- Shot type: [wide / medium / close / OTS / insert]
- Camera movement: [static / push / pull / dolly / handheld / glide]
- Lens feel: [focal length and depth-of-field intent]
- Composition note: [framing rule or signature visual]

## Style & Ambience
- Palette: [from world guide — usually inherited]
- Lighting: [time of day, key sources, color temperature]
- Texture: [grain, haze, flare behavior]
- Realism level: [photoreal / stylized / abstract — usually inherited]

## Dialogue
- VO: [exact line, or "none"]
- Diegetic: [character: line, or "none"]
- Delivery note: [tone, pace, restraint level]

## Audio Design
- Ambient bed: [what the room or world sounds like]
- Foreground sound: [specific cues, motifs, impacts]
- Transition cue: [what audio carries into next clip]
- Silence note: [where silence sits in the clip]

## Three Jobs
- Atmosphere: [one phrase]
- Information: [one phrase — what the audience learns]
- Handoff: [one phrase — what carries forward]

## Production Notes
- Continuity risks: [drift risks specific to this clip]
- Key prop / UI: [specific visible objects that must be right]
- Iteration history: [if regenerated, what was changed and why]
```

That is the whole card. Two-thirds of a page when filled. Keep it that size. The discipline of fitting one clip on one page is the discipline that makes the card usable.

## How to use it

The card is a downstream artifact of the grid. The flow is:

1. Grid row exists and is locked.
2. Open a new breakdown card for the clip.
3. Copy the grid row's Purpose, Atmosphere, Information, Handoff, Audio motif fields into the card's matching fields.
4. Add the cinematography, style, dialogue, and production fields.
5. Use the card to write the Seedance and GPT Image prompts.
6. Use the card during audio pass.
7. Update the card whenever the clip is revised.

The card is also the QA artifact. If you cannot fill the Action field without ambiguity, the clip is not designed. If you cannot fill the Handoff field, the clip is orphaned. If the Continuity pack field is blank, you are about to generate something that drifts.

## HangarX filled example — Clip 2

```markdown
# Clip 2

**Time:** 0:15–0:30
**Location:** HELIX's Berlin industrial loft, floor-to-ceiling windows facing the city
**Subject:** HELIX at workstation, just before the anomaly registers
**Continuity pack:** HELIX hero pack + Berlin loft environment pack

## Action
HELIX sits at her workstation in dawn light, low-key amber and cyan interface spill across her face. Behind her, ambient agent streams visibly move in the apartment systems — calendar adjustments, climate shifts, lighting micro-corrections — before she has touched anything. She does not yet look up. The viewer notices the systems acting before she does.

## Cinematography
- Shot type: medium-wide, locked to HELIX with environmental depth
- Camera movement: very slow push, almost imperceptible
- Lens feel: 35mm, moderate depth-of-field, soft fall-off on background interface elements
- Composition note: HELIX in lower-third right; window light and ambient interface streams fill the rest of the frame

## Style & Ambience
- Palette: warm gold #C79A5A, cool cyan #2FAFC0, deep navy #0A0E1A, pale cream #FEF9E7
- Lighting: cool dawn through windows, low-key warm amber/cyan interface spill, no hard key on HELIX
- Texture: 35mm grain, medium haze, anamorphic horizontal flare streaks from interface light sources
- Realism level: documentary-real cinematic noir, grounded, no stylization

## Dialogue
- VO: "Most people only noticed AI when it helped them. HELIX noticed it when it stopped asking."
- Diegetic: none
- Delivery note: calm, intelligent, slightly ominous; restraint level high; pace measured; one breath per sentence with a small silence between

## Audio Design
- Ambient bed: city hum carried in from Clip 1, HVAC low resonance, faint room tone with barely perceptible interface presence
- Foreground sound: soft predictive UI ticks, climate-adjust hum, calendar resolve chime — all subliminal
- Transition cue: low coherence tone fades up under the last beat of VO, carrying into Clip 3's synchronized-clicks reveal
- Silence note: brief silence between VO sentences; let the room hum carry it

## Three Jobs
- Atmosphere: lonely noir dawn — global world from Clip 1 narrowed into one watchtower
- Information: HELIX exists; she is the kind of person who notices systems when they stop asking
- Handoff: anomaly about to appear on her screens; ambient systems pre-acting is the seed of the synchronization reveal

## Production Notes
- Continuity risks: HELIX face geometry (preserve from hero pack); hair must read as messy practical bun, not styled; MIT hoodie must be visible but not foregrounded
- Key prop / UI: workstation with translucent interface layers, ambient agent stream visualization, dawn-lit Berlin skyline beyond glass
- Iteration history: early version had only the atmosphere job; added VO and pre-acting systems on second pass to give the clip information and handoff
```

That is one clip card. Forty of these is the production package for a 10-minute GenAI short film. If that sounds like a lot, it is the work. There is no shortcut. The films that look effortless on YouTube have a stack of these behind them.

## Checklist

- [ ] One card per clip, one clip per page
- [ ] Every card has Action, Cinematography, Style & Ambience, Dialogue, Audio Design, Three Jobs, Production Notes
- [ ] Three Jobs fields match the grid row exactly (grid is source of truth)
- [ ] Continuity pack named explicitly — never "see character ref"
- [ ] Action field is one beat, not a paragraph of screenplay
- [ ] Cinematography fields are specific (focal length, movement, composition)
- [ ] Audio Design names a transition cue, not just an ambient bed
- [ ] Card is updated when clip is revised, with an entry in Iteration History

## Common failure modes

- **Skipping the card and writing the Seedance prompt directly.** The prompt is downstream of the card. Skipping the card means the prompt is reasoning from scratch, which means the next clip's prompt also reasons from scratch, which means continuity drifts.
- **Padding the Action field into a screenplay paragraph.** The card is not a screenplay. One beat per clip. If you need a paragraph to describe the action, you have two clips, not one.
- **Leaving Continuity pack blank.** This is how characters become other characters between clips. Name the pack. Reference its prompt base from the pack file, do not retype it.
- **Treating the card as write-once.** Cards must be updated when clips are revised. A card that disagrees with the cut is worse than no card.
- **Letting the card grow past one page.** If the card is two pages, half of it is noise. Trim until it fits.
- **Duplicating grid information instead of referencing it.** The card extends the grid. It does not restate it. If a field is identical to the grid row, fine — it is the source of truth. If you find yourself rewriting it differently in the card, one of the two is wrong.
- **Filling cards for "important" clips only.** The film is forty clips. All forty get cards. Skipping the "transition" clips is how the transitions become the weakest part of the film.
