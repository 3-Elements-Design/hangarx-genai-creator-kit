# Escalation Curves

**Phase 4 · Design clip architecture**

## Why this matters

Escalation is the thing that turns a clip grid into a film. Without it, you have a sequence — beats that happen one after another. With it, you have a story — each beat under more pressure than the one before.

GenAI shorts fail at escalation more than any other single thing. The visuals stay strong throughout. The atmosphere holds. And the audience drifts off at minute three because nothing has gotten worse, harder, or more strange in a measurable way. The film is technically still going. Emotionally it ended at minute one.

Escalation is not just an act-to-act phenomenon. It is also a clip-to-clip phenomenon. Within every act, individual clips need to rise and fall. The five-act HangarX structure works because the macro curve (curiosity → descent → revelation → consequence → mismatch) is supported by micro curves inside each act. Without the micro curves, even a well-shaped macro curve plays as flat.

## The macro curve

A film is a pressure graph. Tension goes up. Tension goes down. Then up further. Then up again. The peak sits roughly two-thirds of the way through. The end is not the highest point — it is the most settled point, after the peak has done its work.

For HangarX, the macro curve looks like this:

```
Tension
   ^
   |                           *
   |                         *   *
   |                       *       *  
   |                     *           * 
   |                   *               *  
   |                 *                   *  *  
   |               *                            *  
   |             *                                * *
   |     *  *  *                                       *  *
   |  *                                                       
   +-------------------------------------------------------> Clip
   1   5   10   15   20   25   30   35   40  40.1  41

      Act I       Act II       Act III     Act IV      Act V
      Curiosity   Descent      Revelation  Consequence Mismatch
      Clips 1-10  Clips 11-20  Clips 21-25 Clips 26-35 Clips 36-41
```

A few things to notice on the curve:

- **Act I rises slowly.** Curiosity, not panic. Mostly atmosphere with discrete information drops. The viewer is being seduced, not alarmed.
- **Act II is a steeper climb.** Pressure builds shot by shot. The mystery is no longer abstract.
- **Act III is the peak.** This is the shortest act on purpose. Revelation cannot be sustained — it has to detonate and then move on, or it loses force.
- **Act IV is a controlled fall.** Not relief — consequence. The peak has happened; now the world processes it.
- **Act V is the quiet horror.** Below Act II in raw tension, but above Act I because the audience now knows what they know. The settled point. The end.

The curve is not symmetrical. The peak sits past the midpoint. The ending is calmer than the climax but more unsettling than the opening. This shape is older than cinema — it is the shape of every story that lands.

## The HangarX five-act breakdown

### Act I — Curiosity (Clips 1–10)

Mostly atmosphere. Information arrives in small, precise drops. The thesis VO of Clip 1 sets the philosophical floor. Clip 2 narrows the world into HELIX's POV. Clips 3–4 deliver the anomaly and the hidden layer reveal — already a beat of escalation against the calm opening. Clips 5–9 unfold the descent into Cortex. Clip 10 introduces VALE as the antagonist who is already ahead of HELIX, which is itself a small spike of pressure before the act break.

Internal curve: low rise across 1–2, small spike at 3–4 (anomaly), slow climb 5–9, small spike at 10 (antagonist reveal).

### Act II — Descent (Clips 11–20)

Pressure builds. The mystery acquires moral weight. This is where the film commits to its darkest implications — that the hidden layer is not just hidden infrastructure but harvested intelligence. Crane's warning arrives. The archive horror lands. ECHO emerges as a guide. By Clip 20, the audience knows the stakes are not informational but ontological.

Internal curve: steady climb 11–14, large spike 15 (Crane's warning), brief settle 16–17, another climb 18–20 (the archive horror).

### Act III — Revelation (Clips 21–25)

The peak. The shortest act for a reason: revelation cannot be held. VALE's broadcast (Clip 24) is the ideological climax — the moment the antagonist becomes intellectually dangerous rather than just powerful. Clip 25 is the immediate aftermath, the moment the world realizes what is being offered. The pressure here is at maximum.

Internal curve: hard climb 21–23, peak at 24, immediate consequence 25.

### Act IV — Consequence (Clips 26–35)

The controlled fall. The peak has happened; now characters live with it. HELIX makes the choice to resist forced totality. There is conflict, action, and decision-making — but the tension is operational rather than existential. The audience knows what is at stake; the question is now what gets done about it. Clip 33 (the HELIX-VALE confrontation) is the highest point of this act but lower than Clip 24's peak.

Internal curve: steady operation 26–32, spike at 33, fall 34–35.

### Act V — Mismatch ending (Clips 36–41)

Quiet horror. The forced merge has been stopped. Victory has been achieved. The audience is preparing for catharsis. Instead, the film shows that the world chose easier on its own. Clip 39 reframes victory as voluntary dependence. Clip 40 personalizes it (the espresso machine). Clip 40.1 is the philosophical bridge VO. Clip 41 is the reflection mismatch — the final destabilization that says the world we are looking at may already be the corrected version of itself.

Internal curve: artificial calm 36–38, settled dread 39–40, philosophical landing 40.1, signature held shot 41. Below Act II tension in volume, above Act I in weight.

## Micro-curves inside acts

Even within a single act, every group of three to five clips should have its own small rise and fall. Five clips of unbroken climb reads as a panic attack. Five clips of unbroken atmosphere reads as a screensaver. The pattern that works is:

- Build (clip A → B → C raises pressure)
- Spike (clip D delivers a sharp beat)
- Settle (clip E gives a moment of breath before the next climb)

Then start again. The film is a series of these micro-curves stacked on top of the macro curve. If you flatten the micro-curves to make the macro climb feel cleaner, the film stops breathing and the audience leaves.

A simple rule of thumb: for every three clips that raise pressure, allow one clip of controlled settle. Settle does not mean nothing happens. It means the new information is allowed to land before the next push. The settle clip still does atmosphere, information, and handoff — it just does them in a register one notch lower than the surrounding clips.

## How to check escalation on the grid

Print the grid. Read it end to end. For each clip, mark its pressure level on a 1–5 scale. Then look at the column of numbers.

- A film that works will have numbers that climb, settle, climb again, peak around the two-thirds mark, fall in a controlled way, and end in a register that is lower than the peak but heavier than the opening.
- A film that does not work will have flat ranges (3, 3, 3, 3, 3 for a whole act), or sawtooth chaos (1, 5, 1, 5, 1), or a peak that arrives too early and leaves nowhere to go.

This pressure scan takes ten minutes. Do it before you generate. Do it again after revisions. It is the cheapest QA pass in the entire workflow.

## Checklist

- [ ] Macro curve identified — acts mapped to clip ranges
- [ ] Peak located past the midpoint, not at the end
- [ ] Each act has its own internal rise and fall
- [ ] No five-clip stretch is flat in pressure
- [ ] No five-clip stretch is unbroken climb
- [ ] Settle clips exist between push clips, roughly 1 in 4
- [ ] Ending act is heavier than opening act in weight, lower in raw volume
- [ ] Pressure scan (1–5 scale per clip) has been performed against the grid
- [ ] Climax act is the shortest, not the longest
- [ ] Each clip's three jobs support the act's curve, not work against it

## Common failure modes

- **Treating escalation as continuous climb.** Five acts of unbroken rise is unbearable to watch. The audience needs to breathe. Build settle clips into the grid intentionally.
- **Putting the climax at the end.** The peak is past the midpoint, not at the finish line. The end is the settled point after the peak. Films that climax on the last clip end abruptly and leave nothing to think about.
- **Letting Act I run long because the atmosphere is good.** If curiosity has not become descent by minute three, the audience has already left. HangarX is ten minutes; Act I is two and a half. Cut hard.
- **Holding the climax across multiple acts.** Once revelation has detonated, the film must move into consequence. Trying to sustain peak tension past one act produces the most common GenAI short film failure: a "climax" that lasts five minutes and means nothing.
- **Ignoring micro-curves because the macro curve "is fine."** A grid where the macro looks right but every three-clip stretch is flat will still feel slow. The audience experiences the micro. The macro is geometry on paper.
- **Forgetting the ending act is its own curve.** The mismatch ending of HangarX is not one beat — it is a controlled descent of its own (39 → 40 → 40.1 → 41). Ending acts need internal shape too, not just a final image.
- **Trusting visuals to carry escalation.** A more dramatic frame is not the same as more dramatic pressure. Escalation lives in information density and handoff weight, not in lens choices.
