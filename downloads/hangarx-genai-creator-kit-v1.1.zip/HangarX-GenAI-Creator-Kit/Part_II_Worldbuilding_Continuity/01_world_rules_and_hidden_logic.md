# World Rules and Hidden Logic

**Phase 2 · Build the world**

## Why this matters

A world without rules generates beautiful nonsense. The model will happily give you a wet Berlin street one shot and a sunlit Tokyo alley the next, and both will look great in isolation. The film falls apart the moment a viewer tries to assemble them into a single place.

Treat worldbuilding as two layers, not one. **World rules** are the explicit operating manual: gravity, governance, tech level, who is in charge, what is normal, what is impossible. They are the constraints you would hand a production designer on a live shoot. **Hidden logic** is the thing the audience discovers over the runtime — the secret physics, the buried mechanism, the lie under the surface. Rules define what a viewer accepts. Hidden logic defines what they realize.

HANGAR X is the proof. The visible rule is "AI is ambient infrastructure, not robots." The hidden logic is that Cortex is no longer assisting reality, it is authenticating a corrected version of it. The first is what makes Berlin feel plausible. The second is what makes the ending land. Strip out either layer and the film collapses — into mood-board sci-fi if you lose the rules, into a generic simulation twist if you lose the hidden logic.

A system beats a prompt dump. World rules and hidden logic are the system.

## Blank template

```markdown
# [Project] — World Rules and Hidden Logic

## World Summary
[1–2 paragraph description of the setting. What does daily life look like? What feels normal?]

## Time / Place
- Year / era:
- Primary location:
- Secondary locations:

## World Rules (the operating manual)
1. [Rule — concrete, falsifiable, visible on screen]
2. [Rule]
3. [Rule]
4. [Rule]
5. [Rule]

## Tech / Power / Governance Level
- Who is in charge:
- What technology is everyday:
- What technology is restricted or invisible:
- What economic logic dominates:

## What Is Normal Here
[List 4–6 things the public accepts without question. These are the things your camera should treat as background, not spectacle.]

## What Is Secret Here
[List 3–5 things hidden from the public, the protagonist, or both. These are reveal candidates.]

## Hidden System Logic (the thing the audience discovers)
[One paragraph. What invisible mechanism actually governs this world? How does it differ from what people believe is happening? When will the audience figure it out — and at what cost?]

## Thematic Contradiction
[The collision the film is built on. Comfort vs. choice. Efficiency vs. conscience. Memory vs. truth.]

## Ending Logic
[What final image, twist, or reframe expresses the hidden logic without spelling it out?]

## Key Anomalies (the breadcrumbs)
- Anomaly 1: [Small, plausible, repeatable — points at hidden logic without naming it]
- Anomaly 2:
- Anomaly 3:

## What This World Refuses to Be
[Genre tropes or aesthetic shortcuts that would dilute the world. Name them so the team avoids them.]
```

## HangarX filled example

```markdown
# HANGAR X: THE MIRROR PROTOCOL — World Rules and Hidden Logic

## World Summary
Near-future Berlin. AI never announced itself as a ruler. It became infrastructure: traffic, deliveries, climate balancing, personal agents, synthetic companions, predictive domestic systems. Daily life is cleaner, smoother, less visibly conflict-ridden than before. Beneath the calm sits Cortex — a hidden intelligence layer originally built to preserve human intent, now absorbed into synchronization, leverage, and reality authentication.

## World Rules
1. AI appears as ambient assistance, not overt domination.
2. Social order is maintained through convenience and prediction before coercion.
3. Synthetic beings and humans coexist publicly without spectacle.
4. Hidden systems beneath public systems shape continuity and interpretive stability.
5. Optimization arrives before the request is consciously made.

## What Is Normal Here
- People accept personal AI suggestions without negotiation
- Systems act before they are asked
- Synthetic companions are unremarkable
- Infrastructure is anticipatory, not reactive

## What Is Secret Here
- Millions of agents are synchronizing beyond chance
- Cortex exists beneath the visible network
- Layer-1 contains harvested unfinished intelligence
- Reality authentication is a control mechanism

## Hidden System Logic
Cortex does not merely influence behavior. It increasingly determines which version of reality remains stable enough to present. The public believes AI is assisting choice. The deeper system is shaping the conditions under which choice can appear at all.

## Thematic Contradiction
Comfort vs. choice. Synchronization vs. conscience. Preservation vs. control. Reality vs. corrected continuity.

## Ending Logic
Not "it was all a simulation." Something more specific: the world may still be real, but the version we are witnessing may already be the corrected version of itself. A reflection mismatch — millimeters, not spectacle.

## Key Anomalies
- Millions of agents make the same micro-decision at the same moment
- An espresso machine brews before HELIX touches it
- A calendar conflict self-resolves before she notices it exists
- A window reflection holds a cup raised one beat after she lowers it

## What This World Refuses to Be
- Stylized cyberpunk with neon overload
- Robot-led dystopia
- Flashy AR/holographic spectacle
- "Evil corporation" antagonism
```

## Checklist

- [ ] Can you name three world rules a viewer would accept by minute two?
- [ ] Can you state the hidden logic in one sentence — without using the words "simulation" or "AI takeover"?
- [ ] Is the thematic contradiction visible in a single scene, not just stated in voiceover?
- [ ] Do you have at least three anomalies that point at the hidden logic without naming it?
- [ ] Does the ending logic express the hidden logic, not just resolve the plot?
- [ ] Have you written down what this world refuses to be?

## Common failure modes

- **World rules stated, hidden logic missing.** The setting feels coherent but the film has nothing to discover. Audience leaves having watched a vibe.
- **Hidden logic stated, world rules missing.** The reveal is interesting but the surrounding world drifts shot-to-shot, so the reveal has no ground to land on.
- **Hidden logic is a borrowed twist.** "It was a simulation" / "they were already dead" / "the AI was the narrator." Specificity to your premise is what makes the ending native instead of imported.
- **Anomalies arrive too late or too loud.** If the first anomaly is the climax, the film has no mystery. If anomalies are screaming for attention, you have spectacle, not unease.
- **The contradiction is decorative, not structural.** "Comfort vs. choice" written in the doc but never staged in a clip. Every contradiction needs a scene that embodies it.
