# Visual and Audio Language

**Phase 2 · Build the world**

## Why this matters

If you cannot describe your film's look and sound in a paragraph, the model will improvise — and it will improvise differently on every generation. Visual and audio language is the second half of worldbuilding. Rules tell the model what the world *is*. Language tells it what the world *feels like* and how it should be photographed and scored.

This is the document that gets pasted, in compressed form, into every image and clip prompt. Palette hex codes. Texture words. Lens behavior. Lighting logic. Ambient bed. Recurring motifs. Without it, you will get a wet noir alley followed by a sunlit glass office followed by a neon arcade, and none of them will share a film. With it, every shot inherits the same DNA.

HANGAR X holds together visually because four colors do most of the work — warm gold `#C79A5A`, cool cyan `#2FAFC0`, deep navy `#0A0E1A`, pale cream `#FEF9E7` — and because the texture is locked at "photoreal cinematic noir, 35mm grain, anamorphic flare." The audio holds together because three motifs repeat across forty clips: a BWEEE-OOP notification cue, sparse autonomous city hum, and coherence tones that swell when Cortex is active. The model never sees the whole film. The language is how you make it feel like it did.

## Blank template

```markdown
# [Project] — Visual and Audio Language

## Visual Language

### Palette
- Primary: `#______` ([role / mood])
- Secondary: `#______` ([role / mood])
- Shadow: `#______`
- Highlight: `#______`
- Forbidden colors: [colors that break the world]

### Lighting Logic
- Default key:
- Time-of-day default:
- Interior treatment:
- Interface / screen spill behavior:
- What to avoid:

### Texture
- Realism level: [photoreal / stylized / hybrid]
- Grain / film stock reference:
- Atmosphere: [haze, moisture, dust, clarity]
- Surface treatment:

### Lensing
- Lens feel: [anamorphic, spherical, vintage, modern]
- Default focal length range:
- Depth of field default:
- Flare behavior:

### Camera Grammar
- Movement language by act:
  - Act I:
  - Act II:
  - Act III:
- Framing default: [wide, medium, close, OTS]
- Forbidden moves:

### Environmental Motifs
[Recurring visual elements that should appear across multiple clips — reflections, weather, signage, etc.]

## Audio Language

### Sonic Identity (one sentence)
[What the film sounds like in a single line.]

### Ambient Bed
- City / exterior:
- Interior:
- System / digital:
- Memory / dream / subjective:

### Recurring Motifs
- Motif 1: [name, when it appears, what it means]
- Motif 2:
- Motif 3:

### Interface / System Sounds
- Notification:
- Coherence / system-active cue:
- Failure / anomaly cue:

### Character Sound Signatures
- Protagonist:
- Antagonist:
- Guide / AI:
- System layer:

### Silence Strategy
[When does the film go silent? After reveals? Before turns? At the final cut?]

### Transition Rules
- What carries between clips:
- What hard-cuts:
- What drops to silence:
```

## HangarX filled example

```markdown
# HANGAR X: THE MIRROR PROTOCOL — Visual and Audio Language

## Visual Language

### Palette
- Warm gold `#C79A5A` (Cortex, ATLAS, intelligence, intimacy)
- Cool cyan `#2FAFC0` (interfaces, distance, system logic)
- Deep navy `#0A0E1A` (shadow, night, depth)
- Pale cream `#FEF9E7` (dawn, paper, skin highlight)
- Forbidden: saturated neon, magenta, primary red

### Lighting Logic
- Default: soft natural dawns, low-key interiors
- Restrained amber/cyan interface spill
- Avoid beauty-light glamorization on HELIX
- VALE always lit with severe architectural symmetry

### Texture
- Photoreal cinematic noir
- 35mm grain
- Medium haze
- Anamorphic flare streaks
- Wet pavement reflections as recurring surface

### Lensing
- Anamorphic feel
- Default 35–50mm; 85mm for VALE
- Shallow DOF on character work
- Subtle lens flare from warm sources

### Camera Grammar
- Early film: smooth glides
- Mid-film: investigative pushes
- Late film: tighter emotional restraint, almost imperceptible drift
- Forbidden: handheld shake, fast whip pans, drone spectacle

### Environmental Motifs
- Wet pavement reflections
- Peripheral UI floating in margins
- Calm systems acting before humans do
- Window reflections (load-bearing in the final shot)

## Audio Language

### Sonic Identity
A near-future city that has stopped raising its voice.

### Ambient Bed
- City: sparse hum, autonomous transit tones, distant HVAC
- Interior: room presence, subtle system resonance
- System: coherence harmonics, data whispers
- Memory: amber-gold structural resonance

### Recurring Motifs
- BWEEE-OOP — Cortex notification cue, appears whenever the system speaks to the user
- Coherence tones — swell when Cortex is active beneath the surface
- Data whispers — barely audible, signal Layer-1 proximity

### Interface / System Sounds
- Notification: BWEEE-OOP
- Coherence: harmonic stabilization
- Anomaly: subtle frequency shift, no alarm

### Character Sound Signatures
- HELIX: silence, breath, minimal Foley, room presence
- VALE: broadcast-clean clarity, minimal room coloration
- ECHO: warm harmonic stabilization
- ATLAS / CRANE: amber-gold structural resonance with emotional voice clarity

### Silence Strategy
Used after reveals, before major turns, and at the final cut. Silence is punctuation, not absence.

### Transition Rules
- City hum carries from social world into HELIX's loft early
- Coherence tones bridge anomaly clips
- Hard-cut to silence after ATLAS warning lines
- Final reflection mismatch cuts to black on silence
```

## Checklist

- [ ] Is the palette locked to 3–5 colors with hex codes?
- [ ] Have you named at least one forbidden color or texture?
- [ ] Can a prompt writer paste the texture line directly into a prompt?
- [ ] Does camera grammar shift across acts, or is it static?
- [ ] Are there 2–3 recurring sound motifs with named appearances?
- [ ] Is silence assigned a job, not treated as default?
- [ ] Do antagonist and protagonist have distinct sound signatures?

## Common failure modes

- **Palette stated, not enforced.** "Warm gold and cool cyan" written in the doc, but half the clips come back magenta and orange. Paste the hex codes into every prompt.
- **Texture words are too generic.** "Cinematic" is not a texture. "35mm grain, anamorphic flare, medium haze" is.
- **No forbidden list.** Without a "what this is not" line, the model defaults to its priors — usually neon cyberpunk or sunny tech-optimism.
- **Audio treated as decoration.** If your sound design starts at "add music in post," the film is built on visuals alone. Motifs and silence need to be designed before the first clip is rendered.
- **Camera grammar doesn't escalate.** If Act I and Act III move the same way, the film has no kinetic arc. Glides become pushes become near-stillness.
- **Antagonist sounds like the protagonist.** Sound signature is identity. VALE's broadcast-clean clarity is what makes him feel different from HELIX even before he speaks.
