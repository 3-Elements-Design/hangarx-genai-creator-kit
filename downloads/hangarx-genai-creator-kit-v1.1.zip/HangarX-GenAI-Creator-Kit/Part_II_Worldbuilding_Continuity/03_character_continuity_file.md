# Character Continuity File

**Phase 3 · Lock continuity**

## Why this matters

This is the single most important file in the kit. GenAI films do not fail because of bad prompts. They fail because the protagonist looks like four different women across forty clips, the antagonist's hair color drifts between scenes, and the AI guide reads as random VFX instead of a coherent presence.

A continuity pack is not a character description. It is a constraint document. It tells the model — and the prompt writer — exactly which features must survive every generation. Face geometry. Age read. Build. Wardrobe rules. How the character relates to light. What emotional range they live in. And then the single most-used artifact: the **Continuity Prompt Base Block** — a locked ~100-word identity description that gets pasted into every prompt, every time.

The more philosophical and restrained your film, the more catastrophic drift becomes. HANGAR X depended on HELIX always reading as the same woman, VALE always reading as the same ideology embodied, ECHO always feeling stabilizing rather than random VFX, and ATLAS/CRANE feeling emotionally specific. Without these packs, the film would have looked like disconnected concept art. With them, the model produced forty clips of a recognizable cast.

Build one per character. Lift the base block into every prompt. Treat the QC checklist as production, not cleanup.

## Blank template (one per character)

```markdown
# [Character Name] — Continuity Pack

## Narrative Role
[Protagonist / antagonist / guide / system intelligence / mentor]

## Identity Anchor
- Age:
- Gender / presentation:
- Heritage / background:
- Core emotional read:
- Key trait (one line):

## Face Geometry
- Face shape:
- Cheekbones / jaw:
- Eyes (color, shape, energy):
- Brow:
- Nose:
- Skin:
- Must remain consistent:
  - [Rule]
  - [Rule]
  - [Rule]

## Body / Build
- Height read:
- Build:
- Posture:
- Hair (color, length, style):
- Hands / gesture default:

## Wardrobe Rules
- Base look:
- Alternate look (deeper scenes):
- End-state look (final act):
- Forbidden styling:

## Performance Range
- Default emotional mode:
- Fear mode:
- Authority mode:
- Grief mode:
- Restraint note:

## Lighting Relationship
- Best lighting conditions:
- Signature color interaction:
- Lens / focal preference:
- Avoid:

## Environment Relationship
[How this character usually appears in space — framing defaults, where they sit, what they touch]

## Continuity Prompt Base Block
[A locked ~100-word identity description. This gets pasted into every prompt unchanged. See file 04 for the full base-block guide.]

## Scene Variants
- Variant A (early-film state):
- Variant B (mid-film, under pressure):
- Variant C (end-state):

## QC Checklist
- [ ] Does this still look like the same person?
- [ ] Is the age read consistent?
- [ ] Is wardrobe in-world for the scene?
- [ ] Is the performance tone correct for the beat?
- [ ] Is lighting consistent with the character's visual language?
- [ ] Did the base block actually get pasted into the prompt?
```

## HangarX filled example — HELIX

```markdown
# Kira "HELIX" Vasquez — Continuity Pack

## Narrative Role
Protagonist. Systems architect who notices the system when it stops asking.

## Identity Anchor
- Age: 32
- Heritage: Mixed Latina / Asian
- Core emotional read: brilliant, sleep-deprived, morally alert
- Key trait: notices systems when they stop asking

## Face Geometry
- Sharp cheekbones
- Tired intelligent eyes with subtle dark circles
- Lean facial structure
- Minimal makeup
- Must remain consistent:
  - Grounded and human even after post-merge changes
  - Same eye energy across rested and exhausted states
  - No glam beauty-light treatment

## Body / Build
- Lean, functional build
- Hair: dark, messy practical bun
- Hands: working hands, not decorative

## Wardrobe Rules
- Base: worn MIT hoodie, muted technical clothing
- Alternate: darker fitted utility layers for deeper system sequences
- End-state: same person, faint golden circuit-vein luminosity in eyes
- Avoid: overt cyberpunk armor, stylized fashion, glam techwear

## Performance Range
- Default: restrained focus
- Fear: contained, analytical
- Authority: calm, precise
- Grief: internalized
- Restraint note: HELIX rarely performs emotion outwardly. Pressure shows through stillness.

## Lighting Relationship
- Best: dawn natural light, soft amber/cyan spill, low-key workstation light
- Signature: warm amber interfaces against cool morning interiors
- Avoid: beauty-light glamorization

## Continuity Prompt Base Block
Photorealistic portrait of Kira "Helix" Vasquez, 32-year-old mixed Latina/Asian systems architect, sharp cheekbones, tired intelligent eyes, subtle dark circles, dark hair in a messy bun, minimal makeup, lean functional build, wearing a worn MIT hoodie and muted technical clothing. Documentary-real cinematic noir. Preserve consistent face geometry, age, posture, and exhausted-alert emotional tone across all images.
```

For the **full four-character set** (HELIX, VALE, ECHO, ATLAS / CRANE), see `examples_HangarX/II_continuity_pack_filled.md`. Those four packs are the gold-standard reference for what a production-ready continuity file looks like.

## Checklist

- [ ] One pack per named character (no shared docs)
- [ ] Continuity Prompt Base Block is ~100 words, copy-pastable
- [ ] Wardrobe has base / alternate / end-state — not just "what they wear"
- [ ] Performance range covers at least four emotional modes
- [ ] Lighting relationship includes an "avoid" line
- [ ] QC checklist is run after every batch of generations

## Common failure modes

- **No base block.** Prompt writers paraphrase the character each time, and the model gets a slightly different person every clip. Face drifts within an act.
- **Base block too long.** If it's 400 words, half of it gets ignored. Compress to the load-bearing identity features.
- **No "avoid" lines.** Without forbidden styling, the model defaults to its priors. Hoodies become combat gear. Suits become trench coats.
- **One pack for two characters.** "The team" or "the analysts" — a shared doc guarantees drift. One named character, one pack.
- **No end-state variant.** The protagonist changes over the film. If the pack only describes Act I, late-act prompts ad-lib.
- **QC treated as cleanup.** Continuity drift caught in edit is expensive to fix. Run the checklist after every generation pass, not at the end.
- **Antagonist underwritten.** A continuity pack should be as detailed for VALE as for HELIX. The villain drifts most when the team is bored.
