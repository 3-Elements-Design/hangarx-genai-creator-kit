# Continuity Prompt Base Blocks

**Phase 3 · Lock continuity**

## Why this matters

The Continuity Prompt Base Block is the most-reused asset in the entire production. It is a locked, ~100-word identity description that gets pasted into every image prompt and every clip prompt that features the character. Not paraphrased. Not edited per shot. Pasted.

This is what stops face drift. The model does not remember the previous generation. Every prompt is the first prompt it has ever seen. If you describe HELIX one way in clip 02 and a slightly different way in clip 17, you will get two different women. The base block solves this by giving the model the same identity vector every time, surrounded by per-shot variables (action, framing, environment, mood).

The format is opinionated for a reason. ~100 words is long enough to lock the face and short enough that the model doesn't drop features. Lead with the strongest identifiers — age, heritage, face geometry, hair — then close with the texture/realism marker. Per-shot context goes *around* the block, not inside it.

HANGAR X has four base blocks, one per character. They are reused across image stills, keyframes, and motion prompts. The film holds together because the same text describes the same face every time.

## The HELIX base block (worked example)

```text
Photorealistic portrait of Kira "Helix" Vasquez, 32-year-old mixed Latina/Asian
systems architect, sharp cheekbones, tired intelligent eyes, subtle dark circles,
dark hair in a messy bun, minimal makeup, lean functional build, wearing a worn
MIT hoodie and muted technical clothing. Documentary-real cinematic noir.
Preserve consistent face geometry, age, posture, and exhausted-alert emotional
tone across all images.
```

Anatomy of why it works:

- **Photorealistic portrait of [Name]** — anchors realism level and subject.
- **Age + heritage + role** — three vectors the model can lock to.
- **Four to six face features** — sharp cheekbones, tired eyes, dark circles, dark hair, minimal makeup. Specific but not exhaustive.
- **Build + wardrobe** — keeps body and clothing from drifting.
- **One texture line** — "documentary-real cinematic noir" puts the model in the right rendering mode.
- **Preserve clause** — explicit instruction to maintain identity across generations.

Around the block, you add per-shot context: framing, action, environment, lighting, mood. The block does not change. The surrounding prompt does.

## How to use the block in a prompt

```text
[CONTINUITY BASE BLOCK — pasted unchanged]

[Per-shot context:]
Scene: HELIX at her loft workstation at dawn, over-the-shoulder framing, soft
amber/cyan interface spill, slow push-in toward translucent UI layers.
Mood: investigative restraint, pressure rising.
Action: she leans forward as agent patterns resolve into a coordinated anomaly.
```

The block is the identity. Everything below it is the shot.

## Generic blank template

```text
Photorealistic portrait of [CHARACTER NAME], [AGE]-year-old
[HERITAGE / BACKGROUND] [ROLE / OCCUPATION], [FACE FEATURE 1],
[FACE FEATURE 2], [FACE FEATURE 3], [HAIR DESCRIPTION], [SKIN / MAKEUP NOTE],
[BUILD], wearing [BASE WARDROBE]. [TEXTURE / REALISM LINE].
Preserve consistent face geometry, age, posture, and [EMOTIONAL TONE] across
all images.
```

Fill in the bracketed slots. Keep it between 80 and 120 words. Read it out loud — if it sounds like a casting brief, it is the right length.

## Rules for writing a base block

1. **Lead with the strongest identifiers.** Age, heritage, role. The model uses these to anchor everything else.
2. **Pick 4–6 face features, not 12.** More features means more contradictions and more drift.
3. **Name the wardrobe, not the brand.** "Worn MIT hoodie and muted technical clothing" — not "Carhartt jacket and Acne jeans."
4. **One texture line, always.** "Documentary-real cinematic noir." "Photoreal sci-fi grounded." "35mm grain, anamorphic feel." Pick the line and reuse it.
5. **End with a preserve clause.** Explicit instruction to keep identity stable.
6. **Avoid adjectives that mean nothing.** "Beautiful," "striking," "cinematic" alone — none of these constrain the model. Use them only when paired with a concrete feature.
7. **Test the block before locking it.** Generate five stills using only the base block (no shot context). If all five read as the same person, the block is good. If they don't, edit the block, not the prompts.

## Variants

You can write one base block per character, or — for characters that change significantly over the film — write a base block + an end-state addendum.

**ATLAS / CRANE** is a good example. The base block describes the fused intelligence form. A small addendum line ("appears here as Crane hologram in human read" or "appears here as ATLAS amber-gold intelligence") goes in the per-shot context, not in the base block itself. The block stays stable. The form variant rides on top.

## Checklist

- [ ] Block is 80–120 words
- [ ] Leads with age + heritage + role
- [ ] 4–6 named face features, not more
- [ ] Wardrobe is described, not brand-named
- [ ] One texture / realism line
- [ ] Closes with a preserve clause
- [ ] Tested with five generations using block only
- [ ] Pasted unchanged into every prompt featuring this character

## Common failure modes

- **Paraphrasing the block per shot.** "Tired eyes" in one prompt becomes "exhausted gaze" in the next. The model treats these as different inputs. Paste, don't paraphrase.
- **Block grows over time.** Every drift gets a new sentence appended. Now the block is 300 words and the model drops half of it. Edit ruthlessly.
- **No texture line.** Without "documentary-real" or "photoreal cinematic noir," the model defaults to a stock portrait look. Texture is identity too.
- **Block used for AI / non-human characters that don't need photoreal anchoring.** ECHO needs a base block but its texture line is different — "abstract but humanoid, grounded cinematic realism." Match the realism marker to the character type.
- **Block written once and never tested.** If you didn't generate five stills before locking it, you don't know whether it works. Test before you commit forty clips to it.
