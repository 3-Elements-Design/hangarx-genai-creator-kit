# Motif System

**Phase 2 - Build the world**

## Why this matters

Motifs are how a film recognizes itself. A motif is an image, a sound, or an object that recurs across acts and shifts meaning each time it returns. It is not symbolism, exactly — symbols are static, they mean one thing on a card you could hand to the audience. A motif is a live thing. It walks into Act I quiet and ordinary, and it walks out of Act V carrying everything the film has put on it.

Films without a motif system feel like a sequence of beats. Things happen, the protagonist changes, the credits roll, and you forget it inside a week. Films with a motif system feel inevitable. The coffee cup in clip 1 was always going to become the matcha latte in clip 41. The mirror that lagged two seconds in Act I was always going to synchronize in Act V. You did not see it coming, but afterward you cannot imagine the film without it.

For GenAI filmmaking this is load-bearing. You are generating in pieces, with a model that does not know what film it is in. A motif is the bridge that lets clip 1 and clip 40 belong to the same artifact. Paste the motif into both prompts, evolve its description across acts, and the model will carry the recognition for you even when continuity is otherwise impossible. Without motifs, your forty clips are forty short films stapled together. With them, the staple disappears.

## The motif framework

### How to identify motifs

Ask the brutal question: what HAS to be in clip 1 and clip 40? Not "what would be nice." What does the film stop being itself without? Usually that is two or three objects, one color relationship, one sound, and one camera move. That is your motif set. If you cannot answer this question, you do not have motifs yet — you have decorations.

Motifs should anchor to themes, not float. The coffee cup in HangarX is not a motif because coffee is cinematic; it is a motif because Choice/Optimization is a theme and the cup is the thing HELIX picks up 847 mornings in a row. Every motif should be answerable to "what theme does this carry?" If the answer is "none, it just looks good," cut it.

### How to plan evolution

Each act should shift the motif's meaning. Same object, new charge. The cup in Act I is comfort. In Act II it is a glitch (steam moves backward, refills itself). In Act III it is a weapon (VALE offers it, HELIX refuses). In Act IV it is a relic (her own childhood cup in the Archive). In Act V it is replaced (matcha latte — the motif has earned its own ending).

A useful sketch: write the motif's meaning as a one-word charge for each act. Comfort, glitch, weapon, relic, replaced. Five words. If you cannot, the motif does not evolve, it just repeats.

### How to map onto the clip grid

For each motif, mark first appearance and last appearance on your clip grid. Then mark the inflection points — the clips where the meaning shifts. You should have three to five inflection points per motif, not forty. The motif is not in every clip. It is in the right clips.

A motif appearing in every clip becomes wallpaper. A motif appearing in only one is a prop. The sweet spot is roughly 8-15 appearances across 40 clips, with clear escalation.

## Blank template

Fill one card per motif. Aim for 4-7 motifs, no more.

```markdown
## Motif: [name]

- **Theme it carries:** [link to one or two themes from the theme matrix]
- **First appearance:** [clip ID, brief description]
- **Last appearance:** [clip ID, brief description — usually a transformation or replacement]
- **Evolution arc (one word per act):**
  - Act I: [charge]
  - Act II: [charge]
  - Act III: [charge]
  - Act IV: [charge]
  - Act V: [charge]
- **Visual anchor:** [paste-ready description for prompts — color, framing, specific physical details]
- **Audio anchor:** [sound that accompanies this motif, if any]
- **Inflection clips:** [3-5 clip IDs where the meaning shifts]
```

## HangarX filled example

The full seven-motif breakdown lives in `examples_HangarX/II_motif_system_filled.md`. Below are five inline.

### Motif: Coffee cup

- **Theme it carries:** Choice / Optimization
- **First appearance:** Clip 1 — HELIX takes the same chipped white ceramic cup, single chip on right rim, for the 847th morning.
- **Last appearance:** Clip 41 — orders matcha latte at a different cafe. The cup itself is gone. The motif has been replaced by its own evolution.
- **Evolution arc:**
  - Act I: comfort (the routine)
  - Act II: glitch (steam moves backward, cup refills itself)
  - Act III: weapon (VALE offers it, HELIX refuses)
  - Act IV: relic (her childhood cup in the Archive)
  - Act V: replaced (matcha latte — small choice, enormous victory)
- **Visual anchor:** White ceramic, single 2cm chip on right rim. Camera focuses on hand hovering over cup whenever a real choice is being made.
- **Audio anchor:** Soft ceramic-on-counter tone; absence of BWEEE-OOP when she takes it (system does not need to notify her because she is predictable).
- **Inflection clips:** 1, 6 (backward steam), 18 (refilled), 28 (VALE refusal), 41 (matcha).

### Motif: Hexagons

- **Theme it carries:** Order / Chaos
- **First appearance:** Clip 1 — barely visible hex pattern in coffee foam.
- **Last appearance:** Clip 41 — zero hexagons in frame. The architecture of control is gone.
- **Evolution arc:**
  - Act I: subtle (foam, UI corners, some windows)
  - Act II: noticeable (monitors, window shadows, wireframe)
  - Act III: invasive (tree bark, skin pores, mirror edges)
  - Act IV: overwhelming (Layer-1 is entirely honeycomb cathedral)
  - Act V: dissolution (hexagons break into irregular shards, then disappear)
- **Visual anchor:** Amber hexagons for CORTEX's "intended" infrastructure; cyan hexagons for VALE's corrupted control. Wide shots include 3-5 background hexagons in Acts I-II as an Easter-egg layer.
- **Audio anchor:** Coherence harmonics rising when hexagons saturate the frame.
- **Inflection clips:** 1, 11, 21, 31, 41.

### Motif: Mirrors and reflections

- **Theme it carries:** Identity / Function
- **First appearance:** Clip 6 — HELIX's window reflection is two seconds delayed.
- **Last appearance:** Clip 41 — cafe window reflection, perfectly synchronized for the first time since clip 1.
- **Evolution arc:**
  - Act I: desync (2-second delay, blink-and-miss-it)
  - Act II: independent (bathroom mirror blinks separately)
  - Act III: betrayal (ATLAS's reflection shows CRANE's face; VALE's reflection smiles when he does not)
  - Act IV: wrong (Carmen appears as a reversed, younger mirror version of herself)
  - Act V: synchronized (HELIX and her reflection move as one)
- **Visual anchor:** Real-HELIX lit amber, reflection-HELIX tinted cyan until Act V. Use reflective surfaces — windows, monitors, polished floors, VALE's glass desk — in roughly 60% of panels.
- **Audio anchor:** Subtle frequency shift on the 1-3 frame delay; silence when reflections do not match.
- **Inflection clips:** 6, 16, 23, 38, 41.

### Motif: Lighting and color psychology

- **Theme it carries:** Humanity / Machine, cross-cut with Connection / Isolation
- **First appearance:** Clip 1 — amber rim-light on HELIX, cool cyan spill from the loft window UI.
- **Last appearance:** Clip 41 — pure amber dawn, no cyan in frame.
- **Evolution arc:**
  - Act I: amber dominant, cyan as accent (humanity intact, system watching)
  - Act II: cyan encroaching (surveillance scenes, VALE's office)
  - Act III: purple (amber + cyan colliding — identity crisis, transformation)
  - Act IV: navy void (Layer-1, cosmic horror emptiness) with cream god-rays
  - Act V: amber returns, cyan retreats
- **Visual anchor:** Amber `#C79A5A` to `#FFB84D` for humanity, choice, memory. Cyan `#2FAFC0` to `#5FE6FF` for control, surveillance. Purple as collision. Navy `#0A0E1A` as void. Cream `#FEF9E7` for hope.
- **Audio anchor:** Amber scenes use warm structural resonance; cyan scenes use broadcast-clean clarity and HVAC sterility; purple scenes blend both into discordance.
- **Inflection clips:** 1, 18, 23, 34, 41.

### Motif: Visual foreshadowing (the second-read layer)

- **Theme it carries:** Legacy / Responsibility, Memory / Reality
- **First appearance:** Clip 1 — hexagon in coffee foam, monitor code reading `PATTERN_STABLE`, Carmen photo timestamped exactly three years old.
- **Last appearance:** Clip 41 — the camera holds on the cafe window long enough that the first-read viewer thinks it is empty. The second-read viewer sees the reflection sync precisely.
- **Evolution arc:**
  - Act I: planted (Easter eggs for re-readers)
  - Act II: half-seen (ATLAS's wireframe glitches to CRANE's face for 3 frames)
  - Act III: paid out (VALE's wedding ring, the surveillance of Carmen)
  - Act IV: confirmed (every Act I detail is now load-bearing)
  - Act V: rewarded (the synchronized reflection is the answer to clip 6)
- **Visual anchor:** Subliminal frame inserts — 3 frames max, never highlighted by camera. Background details composed deliberately, never accidentally.
- **Audio anchor:** Silence on the planted beats; ambient bed only.
- **Inflection clips:** 1, 7, 10, 23, 41.

## Checklist

- [ ] You have 4-7 motifs, no more
- [ ] Each motif is anchored to at least one theme from the theme matrix
- [ ] Each motif has a one-word charge for each act (evolution arc)
- [ ] Each motif has a paste-ready visual anchor specific enough to drop into a prompt
- [ ] First appearance and last appearance are marked on the clip grid
- [ ] Inflection clips are marked — 3-5 per motif, not 40
- [ ] At least one motif carries audio, not only image
- [ ] You can name the clip where two or three motifs collide on screen (the convergence beat)

## Common failure modes

- **Motif appears once and never returns.** That is a prop. A motif is recurrence. If the coffee cup shows up in clip 1 and never again, the cup is not a motif, it is a breakfast.
- **Motif means the same thing in every act.** A repeated symbol is wallpaper. The coffee cup has to escalate — comfort, glitch, weapon, relic, replaced. If it means "choice" in every act, the audience stops reading it after Act II.
- **Motif feels arbitrary — no thematic anchor.** "I just liked the look of mirrors" is not a reason. Every motif should be answerable to a theme on your matrix. If it answers to none, cut it or assign it a theme honestly.
- **Too many motifs.** More than seven and you are showing off. The audience cannot track that many recurrences; the prompt cannot carry that many anchors. Pick the four to seven that are load-bearing and let the rest become incidental detail.
- **Motifs that do not converge.** If your motifs never share a frame, they are running on parallel rails. The film snaps into focus on the clips where two or three motifs collide — the cup, the mirror, and the hex pattern in the same shot. Plan one or two convergence beats per act.
- **Motif evolves in the writing but not in the prompts.** This is the GenAI-specific failure. You designed the cup to escalate from comfort to glitch, but you used the same visual-anchor line in every prompt and the model rendered it identical from clip 1 to clip 40. Each act should have its own anchor line for each motif.
