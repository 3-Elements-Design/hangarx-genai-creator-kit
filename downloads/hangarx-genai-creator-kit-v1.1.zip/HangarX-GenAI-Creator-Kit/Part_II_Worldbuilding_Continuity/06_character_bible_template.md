# Character Bible

**Phase 3 · Lock continuity · Narrative depth layer**

## Why this matters

The visual continuity pack (file 03) tells the machine what your character looks like. The character bible tells you who they are. Without the bible underneath, your prompts will keep producing the same body in increasingly hollow scenes. Models can lock a face. Models cannot lock a wound. That part is your job.

A continuity pack lives in the prompt window. A character bible lives in the writer-director's head. The pack constrains pixels; the bible constrains decisions — what this character would and would not say, what they would notice in a room before anyone else does, what they would refuse even when refusing costs them everything. When a scene reads as flat in dailies, it is almost always because the bible underneath it is thin. The model rendered a body and the writing failed to give that body a reason to be there.

Build one bible per named character. Keep it short and load-bearing. The goal is not a Wikipedia entry; the goal is a reference card you can re-read in three minutes before writing a scene and walk away knowing what this character would do next. If the bible is doing its job, every section in it should cost the character something later in the film.

## The framework

A character bible covers seven sections. Each one is a brief paragraph plus a blank field. Resist the urge to expand. Density beats length.

1. **Backstory** — four life phases (childhood, adolescence, young adult, present). Four to six sentences per phase. You are not writing the novel that precedes the film. You are isolating the moments that explain why this character will behave the way they behave in Act III.

2. **Psychological profile** — five fields: Want (conscious goal), Need (unconscious truth), Fatal Flaw (the trait that protects them and traps them, same trait), Fear (what they would never admit out loud), Wound (the specific moment the flaw was forged). The Wound is the load-bearing one. If you cannot name the Wound concretely — a place, a year, a person — the rest of the profile will float.

3. **Relationship matrix** — every character they meet on screen, plus their relationship to: themselves, the antagonist, technology, work, the world. Keep each entry to one or two sentences. Track how each relationship shifts across the arc, not just what it is at the start.

4. **5-act arc** — five beats: where they start, where they are forced to choose, what they lose, what they keep, where they end. Map roughly to the film's act structure. The "forced to choose" beat is the one most often skipped. An arc is not a sequence of events that happen to a character. An arc is a sequence of choices the character could have refused and didn't.

5. **Dialogue voice** — three to five specific tics, sentence-shape preferences, vocabulary range. Then two or three example lines. If you cannot hear the voice when you read the lines back, the voice is not specified enough yet. Generic voice is the single most common bible failure.

6. **Body language evolution** — how posture, gaze, and breathing change from Act I to Act V as the psychology shifts. The body is where the arc becomes visible to the audience before the dialogue catches up. If your character ends in the same posture they started in, the arc is not on screen.

7. **Wardrobe logic** — cross-references the visual continuity pack but adds the why. The pack says what they wear. The bible says why this character wears it, what the garment is doing for them psychologically, and what changes when the garment changes. Wardrobe with no narrative anchor is costume; wardrobe with narrative anchor is character.

## Blank template (one per character)

```markdown
# [Character Name] — Character Bible

## Core Identity
- Full name:
- Role in story:
- Age:
- One-line essence:

## 1. Backstory
**Childhood (ages 0-12):**
[4-6 sentences. Family, place, formative conditions.]

**Adolescence (12-18):**
[4-6 sentences. The break, the lesson, the early shape of the flaw.]

**Young adult (18-late twenties):**
[4-6 sentences. Education, work, the path that led to who they are now.]

**Present (story start):**
[4-6 sentences. What their life looks like when the film opens. The specific pressure already on them.]

## 2. Psychological Profile
- **Want (conscious):**
- **Need (unconscious):**
- **Fatal Flaw:**
- **Deepest Fear:**
- **Wound (the moment the flaw was forged):**
- **Defense mechanism:**

## 3. Relationship Matrix
- To themselves:
- To the antagonist:
- To technology:
- To work:
- To the world:
- To [named character A]:
- To [named character B]:
- To [named character C]:

(Note how each shifts across the arc — not just where it starts.)

## 4. 5-Act Arc
- **Act I — start:**
- **Act II — forced to choose:**
- **Act III — what they lose:**
- **Act IV — what they keep:**
- **Act V — end:**

## 5. Dialogue Voice
- Sentence shape:
- Vocabulary range:
- Tics / verbal habits:
- When defensive:
- When vulnerable:

**Example lines:**
> "[Line in default mode]"
> "[Line under pressure]"
> "[Line at emotional breakthrough]"

## 6. Body Language Evolution
- **Act I:**
- **Act II:**
- **Act III:**
- **Act IV:**
- **Act V:**

## 7. Wardrobe Logic
- Base garment and why:
- What it protects them from:
- When it changes, and what the change means:
- Final-act state:
```

## HangarX worked excerpt — HELIX

The full three bibles for HELIX, VALE, and ATLAS live in `examples_HangarX/II_character_bibles_filled.md`. Here is HELIX's psychological profile and Act arc in the template format, as a calibration sample.

```markdown
# Kira "HELIX" Vasquez — Character Bible (excerpt)

## 2. Psychological Profile
- **Want (conscious):** Expose CORTEX and tear it down.
- **Need (unconscious):** Learn to trust someone before her grandmother's memory is gone.
- **Fatal Flaw:** Self-reliance taken to the point of self-destruction. "I don't need anyone" is also "I won't let anyone in."
- **Deepest Fear:** Not death. Predictability. Becoming the system she hates.
- **Wound:** Age 8. Her parents die in an autonomous-vehicle crash — system optimization error, predicted route, wrong outcome. She survives in the back seat. The lesson she takes from it: the system chose wrong, and trusting it costs you everything.
- **Defense mechanism:** Intellectual detachment. Treats emotional problems like code to debug.

## 4. 5-Act Arc
- **Act I — start:** Isolated. Works alone in a spartan Berlin loft. Tells herself she prefers it.
- **Act II — forced to choose:** Lets Atlas in. First crack in armor. Begins to rely on him emotionally before she has a word for it.
- **Act III — what she loses:** Discovers Atlas is Crane. The trust she just risked turns into the wound she always feared. Goes into Layer-1 alone and almost dies.
- **Act IV — what she keeps:** Her grandmother's voice in her head, even after she has to leave the archived fragment behind. The capacity to make a choice the system did not predict.
- **Act V — end:** Destroys CORTEX. Orders a different coffee. Small choice. Enormous victory.
```

The same compression applies to the other six sections. If a section runs longer than this excerpt, it is probably padded.

## Checklist

- [ ] One bible per named character, no shared docs
- [ ] Backstory has four life phases, each four to six sentences
- [ ] Wound is a concrete moment — place, year, person — not a vague theme
- [ ] Fatal Flaw is the same trait that protects and traps them
- [ ] Want and Need are different (and pull against each other)
- [ ] Relationship matrix tracks shift, not just status
- [ ] 5-act arc names the forced choice, not just the events around it
- [ ] Dialogue voice produces example lines you can hear
- [ ] Lines under pressure read differently from lines at rest
- [ ] Body language changes visibly from Act I to Act V
- [ ] Wardrobe logic explains why, not just what
- [ ] Final-act wardrobe state differs from opening state
- [ ] Bible is short enough to re-read in three minutes
- [ ] Every section costs the character something later in the film

## Common failure modes

- **Bible reads like a Wikipedia page.** Even-toned facts, no contradictions, no friction. A real character has things they believe that they cannot defend, things they want that disgust them, things they fear that they would never name out loud. If your bible has no internal contradiction, you have written a profile, not a person.
- **Psychology has no Wound.** Want, Need, Flaw, and Fear all written as personality traits with no origin. Without the Wound, the flaw is style. With the Wound, the flaw is structure.
- **Arc has no choice.** "Then this happened, then this happened, then this happened." Events are not arc. The arc is the moment the character could have walked away and didn't. Name that moment in Act II or Act IV. If you cannot name it, you do not have an arc yet.
- **Voice is generic.** Every character sounds like the writer. Test: cover the speaker tags in a scene and read the lines. If you cannot tell who is talking, the voices are not specified enough yet.
- **Wardrobe is purely visual.** "She wears a hoodie." Fine — why? What does the hoodie do for her psychologically? What happens the first time she is in a scene without it? If you cannot answer those questions, the wardrobe is costume, not character.
- **Backstory is a novel.** Six pages of childhood, three sentences of present-day. The bible is for the film you are making, not the prequel you are not. Trim ruthlessly. Keep only what loads into a later scene.
- **Relationship matrix is static.** Listed once at the start, never revisited. The whole point of the matrix is to track shift. If Helix's relationship to Atlas in Act I is the same as in Act V, the film has no second act.
