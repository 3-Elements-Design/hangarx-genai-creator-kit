# Image Prompts (GPT Image)

**Phase 5 · Write model-specific prompts**

## Why this matters

Image prompts are how you lock the look of the film before motion enters the picture. Every continuity portrait, hero still, and environment keyframe you generate becomes a downstream reference — a thing later prompts and later humans grade against. If your image prompts are vague, faces drift, wardrobes mutate, and lighting language fractures across the cut. If they are precise, you spend the rest of the production reinforcing decisions you already made instead of relitigating them.

The single biggest mistake creators make at this stage is writing image prompts as wishlists. "A futuristic woman in a futuristic city, cinematic, 8k, masterpiece" generates nothing the film can use twice. A working image prompt is a structured description with named identity anchors, a specific environment, a stated lighting condition, and an explicit realism level. It reads less like a poem and more like a production memo to a DP and a wardrobe lead.

Use this section for portraits, keyframes, environment plates, and any still that another prompt — image or video — will key off. The goal is not the most beautiful single frame. The goal is a frame the rest of the production can reproduce.

## The prompt skeleton

```
Create a [realism level] [shot type] of [subject with identity anchor],
in [environment with named architectural / lighting features].
[Lighting condition] from [direction], [palette anchors], [camera/lens feel].
The mood is [emotional read], [tone descriptor], [restraint note].
[Style anchor — genre + reference grammar, not adjectives].
[Continuity block — what must remain stable from prior generations].
Avoid [plain-language exclusions].
```

The skeleton has seven slots. Each earns its keep.

## Field-by-field guidance

**Subject + identity anchor.** Name the character. Give age, build, key facial features, hair, wardrobe — the same anchor used in every other prompt. This is not where you describe mood. This is where you describe a person who must look the same in shot 7 and shot 34. Write: *"Kira 'HELIX' Vasquez, 32, mixed Latina/Asian, sharp cheekbones, tired intelligent eyes, dark hair in a messy practical bun, worn MIT hoodie."* Don't write: *"a beautiful young woman in tech clothes."*

**Environment.** Specific architecture, specific surfaces, specific time of day. "Berlin loft" is a starting point; "near-future Berlin loft with floor-to-ceiling windows, dark concrete walls, restrained amber and cyan interface spill" is a working prompt.

**Lighting.** State the source (window, practical, interface spill), the direction, and the intensity. "Soft dawn window light from camera-left" is usable. "Cinematic lighting" is not.

**Lens / camera.** 35mm, 50mm, 85mm — pick one. State distance (medium shot, three-quarter portrait). Anamorphic flare yes/no. This is the field most creators skip; it's also the one that does the most to make outputs feel like they came from the same camera package.

**Style.** Anchor to a genre grammar plus a real-world reference, not a stack of adjectives. *"Photoreal cinematic noir, Blade Runner 2049 realism with painterly restraint"* gives the model something to triangulate. *"Cinematic, beautiful, epic, 8k"* gives it nothing.

**Composition.** Where is the subject in frame, what is in the foreground, what is in the background. Negative space matters. If you want the character isolated against architecture, say so.

**Continuity block.** A short paragraph that names what must remain stable: face geometry, age read, wardrobe rules, palette, realism level. This is the field that distinguishes a one-off render from a production asset.

**Negative prompt / exclusions.** Plain language, not a comma-soup. Write *"avoid stylized cyberpunk exaggeration, glamour lighting, fantasy styling, overt VFX spectacle"* — phrases the model can actually parse. Long negative-token strings tend to under-perform; specific natural-language exclusions tend to hold.

## HangarX worked example

**Prompt name:** HELIX Hero Continuity

```
Create a photorealistic cinematic portrait of Kira "HELIX" Vasquez,
a 32-year-old mixed Latina/Asian systems architect with sharp cheekbones,
tired intelligent eyes, subtle dark circles, dark hair in a messy practical bun,
minimal makeup, and a lean functional build. She wears a worn MIT hoodie
over muted technical clothing.

Place her in a near-future Berlin loft with restrained amber and cyan
interface spill, soft dawn window light from camera-left, dark concrete
surfaces, and floor-to-ceiling windows. Three-quarter portrait, 50mm
realism, shallow depth of field, anamorphic horizontal flare.

The mood is brilliant, exhausted, isolated, and alert. Documentary-real
cinematic noir, grounded and plausible, never stylized.

Continuity: preserve face geometry and age consistency, same hair structure,
same wardrobe logic. Avoid glamour lighting, stylized cyberpunk exaggeration,
fantasy styling.
```

**Prompt name:** Reflection Mismatch Final Frame

```
Create a photorealistic cinematic interior frame of HELIX holding a coffee
cup before the apartment window in soft morning light. The corrected city
beyond the glass is calm, immaculate, and frictionless.

Preserve HELIX continuity exactly: same face, same age read, same hair,
worn MIT hoodie over muted technical clothing.

Capture the moment just as she lowers the cup, but in the window reflection
the cup remains raised for one extra beat — a minute continuity mismatch
rather than a glitch effect. Soft desaturated morning tones, subtle unease,
50–85mm realism.

Avoid hard glitch graphics, overt VFX spectacle, doubled-image artifacts.
The image should feel plausible until the discrepancy registers.
```

## On negative prompts

Negative prompts are not a junk drawer. They work when they describe a real failure mode you have actually seen the model produce. "Avoid plastic skin texture" earns its place if the model has been giving you plastic skin. "Avoid bad anatomy" is noise — it doesn't tell the model anything specific.

Three negative-prompt rules:
- one failure per phrase
- plain language, not token soup
- specific to this prompt, not boilerplate copy-pasted across every render

## On the continuity block

The continuity block is what makes an image prompt part of a film instead of a portfolio piece. It is short, it names anchors, and it appears in every prompt for that character or environment. Treat it as a paste-in. If the anchor changes, change it everywhere — don't let one prompt drift.

For HangarX, the HELIX continuity block lives in `Part_II_Worldbuilding_Continuity/02_character_continuity.md` and gets pasted verbatim into every prompt where HELIX appears.

## Failure patterns

- Adjective stacking ("cinematic, beautiful, epic, masterpiece, 8k, ultra-detailed") in place of structure
- Identity anchors that change between prompts — age 32 in one, "young woman" in another
- Lighting described as a vibe ("moody") instead of a source ("window light from camera-left, late dusk")
- Negative prompts copy-pasted across every render without thinking about which failures actually apply
- Continuity block omitted, leading to face drift across the production
- Asking for "8k" or "ultra-HD" — these are not real signals to current image models

## Checklist

- [ ] Subject named with full identity anchor
- [ ] Environment has at least three specific architectural / surface details
- [ ] Lighting names a source, direction, and intensity
- [ ] Lens / camera distance stated explicitly
- [ ] Style anchored to a genre + real reference, not adjective soup
- [ ] Continuity block pasted in verbatim from character pack
- [ ] Negative prompt addresses a real failure mode, not boilerplate
- [ ] Prompt is reproducible — another generator could re-run it and get something usable
