# Video Prompts (Seedance)

**Phase 5 · Write model-specific prompts**

## Why this matters

A video prompt is not a longer image prompt. It is a shot brief. Image prompts describe a frame; video prompts describe a frame, the motion through it, the sound underneath it, and how it hands off to the next clip. The difference is the difference between a still and a scene.

Seedance is the engine used here, but the structure is portable to Veo, Kling, Runway, and Sora. The discipline that matters is field separation: cinematography, subject, action/transition, context, style/ambiance, dialogue, audio design, duration, aspect ratio. When you collapse those into one long sentence you get plausible motion that doesn't bridge to anything. When you keep them separate you get clips that cut together.

Short clips work better than long ones — not because the model can't sustain motion, but because the unit of storytelling at this stage is the 15-second beat. Every second past 15 is a second where the model is improvising story decisions you should be making.

## The prompt skeleton

```
CLIP [number]

[Cinematography]: [Camera movement, framing, lens feel, shot progression]
[Subject]: [Who or what is the focus]
[Action / Transition]: [What changes, how this clip bridges from the previous one]
[Context]: [Location, world state, environmental conditions]
[Style & Ambiance]: [Visual tone, realism level, palette anchors]
[Dialogue]: [VO, dialogue, or "No dialogue"]
[Audio Design]: [Ambient bed, motifs, transitions, silence, impacts]
[Duration]: [Length — typically 5 or 15 seconds]
[Aspect Ratio]: [Format]
```

Nine slots. Treat them as required fields, not suggestions. A clip prompt missing any of these is doing less work than it could.

## Field-by-field guidance

**Cinematography.** Specific camera language. *"Slow push-in"*, *"rack focus"*, *"handheld follow"*, *"static lock"*. Name the lens or the feel: 35mm, 85mm portrait logic, anamorphic. The cinematography field is where you tell the model what kind of camera operator it is.

**Subject.** Who or what owns the frame. Not the action — the noun. If the subject is a character, paste the continuity anchor. If the subject is an environment, name the architectural focus.

**Action / Transition.** The most load-bearing field. Describe what *changes* during the 15 seconds, not what is present. "HELIX leans in" is action. "HELIX is at her workstation" is staging — that goes in subject. Use this field to encode the motion-specific beat the clip exists for. *"HELIX lowers the cup; in the window reflection the cup remains raised for one extra beat."* That sentence is the entire clip.

**Context.** World state. Where in the film are we, what's the time of day, what's the weather, what is the room doing. Context anchors the clip in the story; it's how you keep Clip 3 from looking like Clip 30.

**Style & Ambiance.** Genre grammar + palette anchors + realism level. Borrow vocabulary from the world bible. *"Photoreal cinematic noir, amber and cyan contrast under low natural dawn"* is usable. *"Cool vibes"* is not.

**Dialogue.** Include the exact line, the speaker, and a delivery note in parentheses. *"VO (female, calm, slightly ominous)"*. Or write *"No dialogue."* and mean it.

**Audio Design.** This field is where most prompts go thin. It should name the ambient bed, the one or two foreground sounds, any motifs that carry from the previous clip, and the silence strategy. *"Sparse city hum, synchronized clicks, low coherence tone, slight hush before next reveal."*

**Duration.** Default to 15 seconds. Use 5 for held moments, micro-beats, or the final frame.

**Aspect Ratio.** 16:9 cinematic for the master. Note vertical reformatting needs separately — don't ask the model to do two things at once.

## On motion-specific phrasing

The Seedance prompt earns its rent in the Action/Transition field. Write motion the way an editor describes a shot in a cutting room.

- **Imperative + named beat:** *"HELIX lowers the cup; in the window reflection the cup remains raised for one extra beat before the cut."*
- **Anchor + drift:** *"Hold on HELIX. Let tiny environmental adjustments play in-frame: transit estimate update, subtle light-warm shift, calendar conflict self-resolving."*
- **Pressure + release:** *"VALE delivers the line. Slow symmetrical push-in. Land on stillness."*

Avoid abstractions ("the scene is tense", "the energy builds"). The model can't render an abstraction. It can render a push-in.

## On clip length

Default to 15 seconds. Break to multiple shorter prompts when:

- the beat has two distinct motions (action + reaction)
- the camera changes operator mid-clip (gimbal → handheld)
- the lighting changes within the beat
- the audio mix needs a hard cut

A 15-second clip with one camera move and one named action beat is the sweet spot. Two named actions in one clip is a sign you have two clips.

## HangarX worked examples

### CLIP 3 — The anomaly resolves

```
CLIP 3

[Cinematography]: Continue from Clip 2 with a rack-focus over HELIX's
shoulder into her workstation. Slow push toward translucent interface
layers. End with HELIX reflected in the glass as the pattern resolves.

[Subject]: HELIX at workstation; ATLAS emerging as amber-gold intelligence
within the interface.

[Action / Transition]: Ambient agent streams condense into a synchronized
anomaly: millions of agents make the same micro-decision. HELIX leans in.
ATLAS appears with calm certainty.

[Context]: Berlin industrial loft at dawn, dark concrete walls,
floor-to-ceiling windows, restrained near-future UI.

[Style & Ambiance]: Investigative, precise, photoreal cinematic noir,
amber and cyan contrast under low natural dawn.

[Dialogue]: HELIX: "Why are they all choosing the same path?"
ATLAS: "This isn't a bug. It's coordination."

[Audio Design]: Sparse city hum, HVAC resonance, synchronized clicks,
low coherence tone, slight hush before next reveal.

[Duration]: 15 seconds
[Aspect Ratio]: 16:9 cinematic
```

### CLIP 41 — The reflection mismatch

```
CLIP 41

[Cinematography]: Hold on HELIX in the apartment after the end of Clip 40.1.
Soft morning light, corrected city beyond glass. Almost imperceptible slow
push-in. Let the shot feel complete for one beat too long.

[Subject]: HELIX alone, holding the coffee, standing before the window.

[Action / Transition]: HELIX lowers the cup after a sip. In the window
reflection, the cup remains raised for one extra beat before the cut, as
if the reflection belongs to a slightly different version of the moment.
Cut to black immediately after the mismatch registers.

[Context]: Berlin apartment, perfect city beyond glass, no overt glitching,
no explanatory text, no hard VFX event.

[Style & Ambiance]: Photoreal cinematic noir, immaculate realism, soft
desaturated morning tones, continuity slipping by millimeters.

[Dialogue]: No dialogue.

[Audio Design]: One faint residual Cortex tone or distant BWEEE-OOP,
almost subliminal. Then absolute silence.

[Duration]: 5 seconds
[Aspect Ratio]: 16:9 cinematic
```

## Failure patterns

- Action and Subject collapsed into one field, so the model loses track of who is doing what
- Audio Design left blank or written as "ambient sound" — the model defaults to muzak
- Dialogue without a delivery note, leading to generic line readings
- Asking for 30+ second clips when the beat is a 5-second moment
- Two camera moves in one clip prompt — pan AND push AND rack focus
- Style field that contradicts the world bible (asking for "stylized cyberpunk" when the film is photoreal noir)
- Continuity anchor missing from Subject — the character drifts between Clip 3 and Clip 30

## Checklist

- [ ] All nine fields filled
- [ ] Cinematography names one camera move, not three
- [ ] Subject includes the continuity anchor for the character
- [ ] Action field describes a *change*, not a state
- [ ] Audio Design names a bed, a foreground sound, and a silence strategy
- [ ] Dialogue includes speaker, line, and delivery note
- [ ] Duration matches the beat (5s for held moments, 15s default)
- [ ] Style anchors to the world bible, not generic adjectives
