# Voice Prompts (ElevenLabs / Resemble / Eleven Multilingual)

**Phase 5 · Write model-specific prompts**

## Why this matters

Voice is where most GenAI films break first and worst. The image holds, the motion holds, and then a flat, evenly-paced narrator reads the line and the entire scene collapses into ad copy. Audiences forgive a lot of visual irregularity. They forgive almost no vocal flatness, because they spend their whole lives listening to humans and they know what a human voice does when a human is tired, lying, afraid, or thinking.

A voice prompt is a casting decision plus a line reading. Casting names the voice — age, gender, accent, timbre, pace. Line reading names the emotional state for *this specific line*, the breath direction, the mic distance, the room tone. You cast once and re-cast rarely; you direct every line.

The discipline is to write voice direction the way a director gives notes to an actor in a booth: short, physical, specific. Not "say it sadly" — "say it like you've been awake for thirty hours and you're not surprised."

## The prompt skeleton

```
VOICE CAST
- Character:
- Age:
- Gender / presentation:
- Accent:
- Timbre:
- Default pace:
- Default emotional baseline:
- Reference voice (if any):

LINE
"[The exact line, with inline direction markers]"

DIRECTION
- Emotional state: [one phrase]
- Pace: [slow / measured / brisk / clipped]
- Volume: [whisper / intimate / conversational / projected]
- Breath: [where breaths fall, audible or not]
- Mic distance: [close / medium / room]
- Room tone: [dry / loft reverb / chamber / outdoor]
- Restraint: [over-act / land flat / hold back]

NOTES
[Any character-specific delivery rules from the continuity pack]
```

Cast block stays stable across the film. Direction block changes per line.

## Field-by-field guidance

**Voice cast.** Lock the character voice once, in the continuity pack, and paste it into every line prompt. Reference voices are the most reliable tool you have — a 6-second clip of the timbre you want will outperform any amount of adjective stacking. Age, accent, and timbre are non-negotiable. Pace and emotional baseline can drift between scenes; cast fields should not.

**The line, with inline direction.** Inline markers tell the engine where to breathe, where to slow down, where to drop a word. Use a small, consistent vocabulary:

- `[BREATH]` — audible in-breath
- `[BEAT]` — short pause, no breath
- `[PAUSE]` — longer pause (~1 second)
- `[WHISPER]` — the next phrase drops to whisper
- `[CLIPPED]` — the next phrase is bitten off
- `[SOFT]` — the next phrase softens
- `...` — trailing off

Example: *"That layer [BEAT] shouldn't exist."*

**Emotional state.** One phrase, not a paragraph. "Tired but alert." "Sorrowful certainty." "Broadcast-clean." If you can't compress the state to a phrase, you don't know the state yet.

**Pace and volume.** Separate fields. A line can be slow and loud (Vale doctrine) or fast and quiet (HELIX whispering to ATLAS). Don't conflate them.

**Breath direction.** This is the field that separates a synthesized voice from a performance. Audible breaths before stressed words. Silent breaths between phrases. A whispered line with no breath sounds artificial; a whispered line with one held breath at the start sounds alive.

**Mic distance.** Close mic = intimacy, room mic = scale. For voiceover, default close. For diegetic dialogue, match the camera distance.

**Room tone.** Match the visual environment. HELIX's loft has soft loft reverb; Vale's broadcast chamber is broadcast-clean dry; CRANE's archive has destabilized spatial resonance. Voice that sits in the wrong room kills the cut.

**Restraint.** The most important field for emotional lines. Under-direction beats over-direction. "Land flat" produces more menace than "say it sinisterly."

## HangarX worked examples

### HELIX — interior monologue, Clip 02

```
VOICE CAST
- Character: Kira "HELIX" Vasquez
- Age: 32
- Gender / presentation: female
- Accent: neutral North American with faint Berlin inflection
- Timbre: warm-low, slight rasp from fatigue
- Default pace: measured, thinking-out-loud
- Default emotional baseline: brilliant, exhausted, alert
- Reference voice: [6s clip — HELIX_baseline_v3.wav]

LINE
"Most people only noticed AI when it helped them. [BEAT]
HELIX noticed it [SOFT] when it stopped asking."

DIRECTION
- Emotional state: tired-alert, observational
- Pace: slow, almost talking to herself
- Volume: intimate, just above whisper
- Breath: audible in-breath before "HELIX"; silent between phrases
- Mic distance: close
- Room tone: soft loft reverb, dawn quiet
- Restraint: hold back — this is the inside of her head, not a speech

NOTES
HELIX never sells a line. She lands flat and lets the audience do the work.
No upspeak. No emphatic stress on "noticed."
```

### VALE — broadcast doctrine, Clip 24

```
VOICE CAST
- Character: Marcus Vale
- Age: 50
- Gender / presentation: male
- Accent: cultivated transatlantic
- Timbre: resonant, controlled, statesman
- Default pace: measured, weight on every clause
- Default emotional baseline: sorrowful certainty
- Reference voice: [6s clip — VALE_broadcast_v2.wav]

LINE
"This is not a moral failure. [BEAT]
It is a latency failure. [PAUSE]
Climate, conflict, and markets now move faster than human deliberation.
[BEAT] We do not lack empathy. [SOFT] We lack synchronization."

DIRECTION
- Emotional state: humane, reasonable, terrifyingly calm
- Pace: measured, statesman cadence, weight on "latency" and "synchronization"
- Volume: conversational-projected, not raised
- Breath: held in-breath before "latency failure" — the word carries
- Mic distance: close, broadcast-mic intimacy
- Room tone: broadcast-clean, minimal coloration
- Restraint: extreme — Vale never raises his voice; the seduction is the calm

NOTES
Never read as villain. Vale believes every word. If the take sounds like
a politician selling something, it's wrong. He sounds like a doctor
explaining a diagnosis.
```

### ECHO — guide intelligence, mid-film

```
VOICE CAST
- Character: ECHO
- Age: androgynous, early-twenties face logic
- Gender / presentation: androgynous, slight female lean
- Accent: placeless, gently warm
- Timbre: synthesized-but-warm, harmonic stabilization in the low end
- Default pace: slow, certain, present-tense
- Default emotional baseline: serene, stabilizing
- Reference voice: [6s clip — ECHO_emergence_v1.wav]

LINE
"You are not the only one who noticed. [PAUSE]
You are the one who didn't look away."

DIRECTION
- Emotional state: warm, anchoring, no urgency
- Pace: slow — let each clause settle
- Volume: intimate, almost interior
- Breath: no audible breaths — ECHO is breath-less by design, but warm
- Mic distance: close, slight harmonic doubling at the edges
- Room tone: subtle harmonic bed, no real-room reverb
- Restraint: extreme — ECHO never persuades, only reports

NOTES
ECHO sounds like a voice you'd trust at 3am. The synthesized quality
should be felt at the edges, not the center. If it reads as "AI voice
trope," it's wrong.
```

## On inline direction markers

Pick a small vocabulary and use it consistently. Five markers is enough. Twenty is a mess. The markers should encode physical behavior the engine can render, not emotional states it has to interpret.

Good markers: `[BREATH]`, `[BEAT]`, `[PAUSE]`, `[WHISPER]`, `[CLIPPED]`, `[SOFT]`, `...`

Skip markers: `[SADLY]`, `[ANGRILY]`, `[MEANINGFULLY]`. Emotional state belongs in the Direction block, not inline.

## Failure patterns

- Voice cast described in adjectives only ("warm and trustworthy") with no reference clip
- Direction written as a vibe ("say it dramatically") instead of physical behavior
- Inline markers used inconsistently — `[PAUSE]` in one prompt, `(pause)` in another, ellipsis in a third
- Mic distance not matched to camera distance — close-mic VO over a wide shot reads wrong
- Room tone left to the engine, which usually picks the wrong reverb
- Same delivery across every line — no scene-by-scene direction
- Over-direction: stacking five emotional notes when one would do

## Checklist

- [ ] Voice cast locked once and pasted from continuity pack
- [ ] Reference voice clip attached or cited
- [ ] Line includes inline direction markers from the agreed vocabulary
- [ ] Emotional state compressed to one phrase
- [ ] Pace and volume are separate fields
- [ ] Breath direction stated explicitly
- [ ] Mic distance matches the visual framing
- [ ] Room tone matches the visual environment
- [ ] Restraint note added — most lines under-direct rather than over-direct
