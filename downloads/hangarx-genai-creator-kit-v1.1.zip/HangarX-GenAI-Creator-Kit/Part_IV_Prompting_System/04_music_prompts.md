# Music Prompts (Suno / Udio / AIVA)

**Phase 5 · Write model-specific prompts**

## Why this matters

A music prompt for a film is not a song prompt. A song prompt asks for a finished, structured, listenable piece of music with a beginning, middle, and end. A film music brief asks for a bed — a piece of music written *to picture* that hits specific moments and gets out of the way between them. The first produces a track you'd put on a playlist. The second produces a cue you'd put under a scene.

The mistake most creators make is asking Suno or Udio for a "cinematic AI-thriller song" and editing the result down to fit. That works once, accidentally. The reliable approach is to write a cue brief: tempo, key, instrumentation, emotional arc, cue points, duration. The cue points are the load-bearing field. Music writes to picture, not the other way around.

Done right, the score is the thing audiences don't notice — until they do, because a single piano note lands on a cut and the room goes still. Done wrong, the score is the thing audiences resent, because it's underlining moments the image was already carrying.

## The prompt skeleton

```
CUE [name / number]

PURPOSE
[What this cue does in the film, in one sentence]

DURATION
[Total length and the picture window it covers]

TEMPO + KEY
[BPM and key, or "rubato" if no fixed tempo]

INSTRUMENTATION
[Named instruments / textures. Be specific.]

EMOTIONAL ARC
[Start state → mid state → end state. One arc per cue.]

CUE POINTS
- [HH:MM:SS] — [picture event] — [musical response]
- [HH:MM:SS] — [picture event] — [musical response]

DYNAMICS
[Where the cue is loud, where it's quiet, where it drops out]

REFERENCE
[One real cue or composer — not "epic trailer music"]

EXCLUSIONS
[What this cue must not do]
```

## Field-by-field guidance

**Purpose.** One sentence on what the cue does dramatically. Not "scary music for the reveal." Try: *"Land the anomaly reveal without telegraphing it — the music should arrive only after HELIX leans in."*

**Duration.** Total seconds, plus the picture window. *"22 seconds, covering Clip 03 + first 7 seconds of Clip 04."* This forces you to think about where the cue starts and ends in relation to cuts.

**Tempo + key.** Pick numbers. *"~60 BPM, A minor"* is a working brief; *"slow and dark"* is not. Use "rubato" only when you genuinely mean no fixed tempo (rare for cues under :30).

**Instrumentation.** Name 2–4 elements. Soft synth pads + sub bass + sparse piano notes is a working bed. "Orchestral" is not — orchestral is a budget, not an instruction.

**Emotional arc.** Start → mid → end. One arc per cue. If your cue has three arcs, you have three cues. *"Suspended unease → tightening dread → suspended unease."*

**Cue points.** The most important field, and the one Suno-style prompts most often skip. List the specific picture events the music must respond to, with timecodes. *"00:15 — HELIX leans in — drop the sub bass for one beat."* This is how you stop the score from competing with the cut.

**Dynamics.** Where the cue sits in the mix. A cue that's loud throughout is a cue that's fighting dialogue. Most film cues are quiet 80% of the time and loud for the moments they own.

**Reference.** One specific cue or composer the engine can triangulate against. *"Jóhann Jóhannsson, Sicario — the desert cue."* Not *"like a Hans Zimmer score."*

**Exclusions.** What the cue must *not* do. *"No drums. No build to a drop. No melodic resolution."* The exclusions are how you stop Suno from defaulting to a song shape.

## On cue-point thinking

The shift from song-writer to film-composer is the shift from *track* to *cue*. A track has its own structure. A cue has the *scene's* structure.

When you write a cue brief:

1. Lay out the picture window in seconds
2. Mark the cuts and the named beats (line endings, action moments, looks)
3. Decide which beats the music answers to and which it ignores
4. Write the cue *around* those beats

Most cues need 3–5 cue points. Fewer than 3 and the music is wallpaper. More than 5 and the music is fighting the picture.

## On stems vs. full mixes

Always request stems if the engine supports it. Even when it doesn't, ask for the cue without drums, then layer drums separately. The single biggest gain in mixing GenAI score with dialogue is being able to duck the bed and leave the texture under VO.

Minimum stems to ask for, when available:
- pad / texture bed
- bass element
- melodic element
- percussion (if any)

If the engine returns only a stereo mix, request alternates: *"Same cue, no drums."* *"Same cue, pad only."* This gives you the working layers without remixing.

## On length and looping

Suno-class engines default to song-length output (2:30+). For film cues, generate longer than needed and edit down — but write the brief to a specific window, not a song length. The output will overshoot. That's fine; you trim from the head and tail.

For ambient beds that need to extend under long dialogue scenes, brief shorter cues (~30s) designed to loop. Name the loop point. *"Designed to loop at 00:24, no melodic resolution before the loop."*

## HangarX worked examples

### CUE 02 — Dawn-noir bed (HELIX in the apartment)

```
CUE 02 — Dawn-noir bed

PURPOSE
Sit under HELIX's introduction. Establish solitude and intelligence
without telegraphing thriller. The music is the inside of her head.

DURATION
~15 seconds, covering Clip 02. Designed to extend under Clip 03 opening.

TEMPO + KEY
~58 BPM, D minor, no time signature pulse — feels suspended.

INSTRUMENTATION
- Low synth pad (warm, slight detune)
- Sub bass (felt, not heard)
- One distant piano note every 4–6 seconds, no melody
- Faint room-tone texture (not instrumental, atmospheric)

EMOTIONAL ARC
Quiet observation → faint forward pull → unresolved.

CUE POINTS
- 00:00 — VO begins — pad already present, do not enter
- 00:08 — "stopped asking" — single piano note on the word "asking"
- 00:13 — last second of clip — pad thins, sub bass holds

DYNAMICS
Pad at -18dB under VO. Piano notes peak -12dB. No swells.

REFERENCE
Jóhann Jóhannsson, Arrival — "Heptapod B" opening.

EXCLUSIONS
No drums. No melodic phrase. No build. No resolution to major.
Nothing that signals "thriller score."
```

### CUE 19 — Revelation build (Act III)

```
CUE 19 — The hidden layer

PURPOSE
Carry HELIX through the revelation that Cortex was built on harvested
consciousness. The cue must escalate without resolving.

DURATION
~28 seconds, covering Clip 09 + bridge into Clip 10.

TEMPO + KEY
~72 BPM emerging from rubato, A minor.

INSTRUMENTATION
- Layered synth pads (cold, harmonically coherent)
- Sub bass with slow upward drift
- Choral texture (wordless, ethical weight)
- One sustained cello note, entering at the cue point

EMOTIONAL ARC
Suspended dread → moral recognition → harden, do not release.

CUE POINTS
- 00:00 — Clip 09 opens on archive — pad and sub already running
- 00:11 — CRANE: "They weren't uploaded" — choral texture enters
- 00:17 — CRANE: "They were harvested" — cello note lands; everything
  else drops out except sub bass
- 00:20 — silence, sub bass only, three seconds
- 00:23 — bridge into Clip 10 — pad returns one octave lower

DYNAMICS
Build under dialogue but never cover it. The cello note at 00:17 is
the loudest moment. After that, drop to almost nothing.

REFERENCE
Mica Levi, Under the Skin — the "Lipstick to Void" cue.

EXCLUSIONS
No drums. No tonal resolution. No relief. The cue must end colder
than it started.
```

### CUE 40 — The mismatched ending

```
CUE 40 — Over-resolved warmth

PURPOSE
Underscore the final apartment beat. The horror of this cue is that
it sounds *right* — warm, harmonically clean, gently major — and lands
wrong because the picture is showing surveillance disguised as comfort.

DURATION
~20 seconds, covering Clip 40 through end of Clip 40.1.

TEMPO + KEY
~62 BPM, F major (deliberately the wrong key for what's happening).

INSTRUMENTATION
- Soft piano (clean, no detune)
- Warm string pad (consonant, no tension intervals)
- Faint UI tone (BWEEE-OOP motif, harmonized into the key)

EMOTIONAL ARC
Domestic warmth → settled warmth → too-settled warmth.

CUE POINTS
- 00:00 — espresso machine starts — piano enters, gentle phrase
- 00:06 — Cortex notification appears — BWEEE-OOP motif folds into
  the harmony, not against it
- 00:12 — HELIX dismisses notification — piano completes the phrase
- 00:18 — VO begins — pad holds, piano fades; pad must feel comfortable

DYNAMICS
Soft throughout. The cue should be the most pleasant music in the film.
That is the point.

REFERENCE
Cliff Martinez, Solaris — the "First Sleep" cue, but warmer.

EXCLUSIONS
No minor-key shading. No dissonance. No "this is wrong" musical
signaling. The wrongness is the absence of wrongness.
```

## Failure patterns

- Briefs written as song descriptions ("a dark cinematic AI thriller song with rising tension")
- No cue points — the music ignores the cuts
- Instrumentation described as "orchestral" or "epic" instead of named instruments
- Reference field left blank or filled with "Hans Zimmer / Trent Reznor / cinematic"
- Tempo given as "slow" instead of a BPM
- Emotional arc with three changes in 15 seconds
- Asking for stems the engine doesn't return, then editing the full mix and apologizing for it
- Score that telegraphs the moment the image was already carrying

## Checklist

- [ ] Purpose is one sentence and dramatic, not descriptive
- [ ] Duration includes the picture window, not just total seconds
- [ ] Tempo is a number; key is named
- [ ] Instrumentation names 2–4 specific elements
- [ ] Emotional arc has start, mid, end — one arc only
- [ ] Cue points list 3–5 timestamped picture events
- [ ] Dynamics specify where the cue is loud and where it gets out of the way
- [ ] Reference is one specific cue or composer, not a genre
- [ ] Exclusions name what the cue must not do
- [ ] Stems requested if the engine supports them
