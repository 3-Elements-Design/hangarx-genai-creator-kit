# Same Beat, Different Engine

**Phase 5 · Write model-specific prompts**

## Why this matters

The unit of GenAI filmmaking is not the prompt. It is the *coordinated quartet*: an image prompt, a video prompt, a voice prompt, and a music brief, all aimed at the same beat, each doing the part of the job only it can do.

If you write only video prompts, your beat has motion but no anchor frame, no performance, and a default score. If you write only image prompts, you have a beautiful keyframe and no scene. If you write all four but they aim at slightly different intents, you get four professional-looking artifacts that don't add up to a beat — the image is melancholy, the score is propulsive, the voice is wry, the motion is anxious, and the audience reads the dissonance as failure.

This file takes one specific HangarX beat and shows how it translates into four model-specific prompts that *cohere*. Read it as a worked example, not a template. The beat is the most thematically loaded moment in the film: HELIX in her apartment, the coffee-cup reflection mismatch.

## The beat

**Location:** HELIX's Berlin apartment, six months after the events of the film.
**Picture:** HELIX stands at the floor-to-ceiling window, holding a coffee cup. The corrected city beyond the glass is calm and immaculate. She lowers the cup after a sip. In the window reflection, the cup remains raised for one extra beat.
**Sound:** Almost nothing. A residual Cortex tone. Then silence.
**Dramatic function:** Destabilize the audience's confidence in whether they have been watching reality or an authenticated version of it. The film's thesis lands not as a line but as a millimeter of continuity drift.

What follows is the same beat, written four times for four engines.

---

## 1. Image prompt — GPT Image

**Use:** Generate the keyframe. This is the still that the video prompt will key off, and the reference the colorist will grade against.

```
Create a photorealistic cinematic interior frame of Kira "HELIX" Vasquez —
32, mixed Latina/Asian, sharp cheekbones, tired intelligent eyes, dark
hair in a messy practical bun, worn MIT hoodie over muted technical
clothing — holding a coffee cup before the apartment window in soft
morning light.

The corrected city beyond the glass is calm, immaculate, frictionless:
clean infrastructure, gentle traffic, no friction visible. Three-quarter
back-angle on HELIX so the window reflection is partially visible. 50mm
realism, shallow depth of field on HELIX, the city softly defocused
beyond.

Soft desaturated morning tones, pale gold and faint cyan, subtle
volumetric atmosphere, 35mm grain. Documentary-real cinematic noir.

Continuity: preserve HELIX face geometry, age read, hair structure,
wardrobe. Preserve the Berlin apartment architecture established in
Clip 02.

Avoid hard glitch graphics, doubled-image artifacts, overt VFX
spectacle, glamour lighting, stylized cyberpunk exaggeration.
The image must feel plausible.
```

**Why this engine, for this part of the beat:** The keyframe needs to be exact and reproducible. Image models are still the most controllable for fine-grained continuity — face geometry, wardrobe, architectural detail. You want the reflection mismatch to be subtle enough that it reads only on close inspection; that means the rest of the frame has to be locked. Start with the still. Everything downstream — the video motion prompt, the colorist's reference, the marketing thumbnail — will key off this image. If the still drifts, everything drifts.

---

## 2. Video prompt — Seedance

**Use:** Generate the 5-second motion clip that carries the mismatch.

```
CLIP 41

[Cinematography]: Hold on HELIX in the apartment after the end of Clip 40.1.
Soft morning light, corrected city beyond glass. Almost imperceptible
slow push-in. Let the shot feel complete for one beat too long.

[Subject]: HELIX alone, holding the coffee, standing before the window.
Three-quarter back angle so the window reflection is visible.

[Action / Transition]: HELIX lowers the cup after a sip. In the window
reflection, the cup remains raised for one extra beat before the cut,
as if the reflection belongs to a slightly different version of the
moment. Cut to black immediately after the mismatch registers.

[Context]: Berlin apartment, perfect city beyond glass, no overt
glitching, no explanatory text, no hard VFX event.

[Style & Ambiance]: Photoreal cinematic noir, immaculate realism,
soft desaturated morning tones, continuity slipping by millimeters,
subtle but destabilizing.

[Dialogue]: No dialogue.

[Audio Design]: One faint residual Cortex tone or distant BWEEE-OOP,
almost subliminal. Then absolute silence.

[Duration]: 5 seconds
[Aspect Ratio]: 16:9 cinematic
```

**Why this engine, for this part of the beat:** The mismatch is a motion event. It exists across time, not in a single frame. A still can imply the mismatch through composition, but only motion can deliver the exact beat — the half-second lag, the asynchrony between the body and the reflection. This is also why the clip is 5 seconds, not 15. The beat is a single named motion. Anything longer dilutes it; anything shorter doesn't give the audience time to register the discrepancy.

---

## 3. Voice prompt — ElevenLabs

**Use:** Generate HELIX's interior monologue — the philosophical bridge VO from Clip 40.1, which sits *just before* the reflection mismatch and frames it.

```
VOICE CAST
- Character: Kira "HELIX" Vasquez
- Age: 32
- Gender / presentation: female
- Accent: neutral North American with faint Berlin inflection
- Timbre: warm-low, slight rasp from fatigue
- Default pace: measured, thinking-out-loud
- Default emotional baseline: brilliant, exhausted, alert
- Reference voice: [6s clip — HELIX_baseline_v3.wav]

LINE
"We thought it would arrive like a warning. [BEAT]
Instead, [SOFT] it arrived like warmth. [PAUSE]
A door already open. [BEAT]
A room already waiting. [BEAT]
A thought already finished before it became our own. [PAUSE]
And little by little, [SOFT] the distance between being guided
and being gone [BEAT] became too small to name."

DIRECTION
- Emotional state: quiet philosophical recognition, no dread, no relief
- Pace: very slow, ruminative, no urgency
- Volume: intimate, just above whisper
- Breath: audible in-breath before "Instead" and before "And little by
  little"; otherwise silent
- Mic distance: close, almost interior
- Room tone: dry, no apartment reverb — this is happening inside her
- Restraint: extreme. Land flat. Do not perform philosophical weight.

NOTES
This is the last line HELIX speaks in the film. It must sound like
someone naming a thing they have already accepted. No defiance. No
melancholy. Just clarity.
```

**Why this engine, for this part of the beat:** The line is the philosophical thesis of the film, but it has to land as a thought rather than a speech. That requires performance, not synthesis-by-default. ElevenLabs (or similar) with a locked reference voice, inline pacing markers, and explicit restraint direction is what turns a written line into a performed line. Note that the voice prompt is for the *bridge into* the mismatch beat, not the mismatch itself — Clip 41 is silent. The voice does its work *before* the silence, so that the silence has something to land against.

---

## 4. Music brief — Suno

**Use:** Generate the dawn-noir bed that runs under Clip 40 + 40.1 and falls away just before Clip 41.

```
CUE 40 — Over-resolved warmth

PURPOSE
Underscore the final apartment sequence. The horror of this cue is
that it sounds *right* — warm, harmonically clean, gently major — and
lands wrong because the picture is showing surveillance disguised as
comfort. The cue must drop out completely before the reflection mismatch.

DURATION
~20 seconds, covering Clip 40 through end of Clip 40.1. Drops to silence
at the start of Clip 41.

TEMPO + KEY
~62 BPM, F major (deliberately the wrong key for what's happening).

INSTRUMENTATION
- Soft piano (clean, no detune)
- Warm string pad (consonant, no tension intervals)
- Faint UI tone (BWEEE-OOP motif, harmonized into the key)

EMOTIONAL ARC
Domestic warmth → settled warmth → too-settled warmth → silence.

CUE POINTS
- 00:00 — espresso machine starts — piano enters, gentle phrase
- 00:06 — Cortex notification appears — BWEEE-OOP motif folds into
  the harmony
- 00:12 — HELIX dismisses notification — piano completes the phrase
- 00:18 — VO begins — pad holds, piano fades
- 00:20 — VO ends, cut to Clip 41 — cue drops to silence

DYNAMICS
Soft throughout. The cue should be the most pleasant music in the film.
That is the point. The drop to silence at 00:20 is total.

REFERENCE
Cliff Martinez, Solaris — the "First Sleep" cue, but warmer.

EXCLUSIONS
No minor-key shading. No dissonance. No "this is wrong" musical
signaling. The wrongness is the absence of wrongness. No fade — the
cue ends on a held chord, then silence.
```

**Why this engine, for this part of the beat:** The score is what makes the beat unsettling. The image is calm. The motion is calm. The voice is calm. If the score *also* sounds calm and pleasant, the audience is given a coherent emotional surface — and the mismatch in the reflection lands as a violation of that surface, not as one more dark signal among many. Suno (or Udio) can deliver this kind of harmonically clean, song-shaped warmth more easily than it can deliver thriller-scoring tropes. Use the engine where its defaults work *for* the scene instead of against it.

---

## How the four collaborate

The reflection mismatch beat does not work as any single prompt. The still, on its own, is a melancholy domestic frame. The motion clip, without sound, reads as a minor visual glitch. The voiceover, without picture, is an aphorism. The score, in isolation, is a pleasant piano piece.

The beat works because the four engines are aimed at the same dramatic intent — *make the surface so coherent that the millimeter of drift is what breaks the audience* — and each one contributes a part of the surface only it can build. The image fixes the geometry. The motion delivers the asynchrony. The voice gives the thesis a body. The score makes the room feel safe.

The unit of GenAI filmmaking is not the prompt. It is the coordinated quartet. Plan beats this way, prompt this way, and the production stops being a stack of generated assets and becomes a film.
