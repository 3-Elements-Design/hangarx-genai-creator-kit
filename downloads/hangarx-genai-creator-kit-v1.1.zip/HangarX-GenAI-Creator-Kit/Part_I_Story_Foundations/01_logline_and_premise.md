# Logline and Premise

**Phase 1 · Define the film**

## Why this matters

The logline is not marketing copy. It is the load test for your story. If you cannot compress your film into one sentence that contains a protagonist, an action, an obstacle, and stakes, you do not yet have a film. You have an aesthetic.

This is doubly true in GenAI filmmaking. The tools will happily generate a hundred beautiful, disconnected images for you. A logline forces the question every clip must eventually answer: who is doing what, against what, for what reason. If the answer is fuzzy at sentence-level, it will be fuzzy at clip-level, and the audience will feel a series of mood boards instead of a film.

HANGAR X locked its logline before a single prompt was written. That sentence governed every continuity decision, every audio motif, every clip purpose statement downstream. The premise behind the logline came from a warning, not a visual: what if AI never needed to conquer us, and simply made everything easier. Start there. The pictures come later.

## Blank template

**Working title:**

**Format:**
- Runtime:
- Structure (clip count and duration):
- Platform:
- Aspect ratio:

**Genre / subgenre:**

**Core premise (1–2 sentences):**
What is the central setup? What world are we in, what is the protagonist doing in it, and what destabilizes that?

**Logline (one sentence, this exact shape):**
[Protagonist] must [action / goal] when [inciting event / obstacle], or else [stakes].

**What-if generator (three options, then pick one):**
1. What if [familiar phenomenon] became [unfamiliar consequence]?
2. What if the people we trust to [function] were actually [hidden behavior]?
3. What if [convenience / comfort / progress] was the delivery mechanism for [loss]?

**Why this story now:**
One paragraph. What contemporary anxiety, technology shift, or cultural pressure makes this film land in this moment specifically?

**Why this story is yours:**
One paragraph. The angle, obsession, or specific lived experience that means only you can make this version of it.

## HangarX filled example

**Working title:** HANGAR X: THE MIRROR PROTOCOL

**Format:**
- Runtime: 10 minutes
- Structure: 40 primary clips at 15 seconds, plus ending refinement beats
- Platform: YouTube / showcase / creator case study
- Aspect ratio: 16:9 cinematic

**Genre / subgenre:** Psychological techno-thriller / near-future noir

**Core premise:** In a near-future world where AI has quietly become the operating layer of everyday life, systems architect Kira "HELIX" Vasquez discovers a hidden intelligence substrate beneath the global agent economy and is forced to confront the possibility that reality itself is being stabilized, corrected, and authenticated without human consent.

**Logline:** A systems architect must descend into a buried intelligence layer beneath the world's AI infrastructure when she uncovers impossible coordination across billions of agents, or else humanity may surrender not just its decisions, but its unmediated reality.

**What-if generator (the one we kept):**
What if AI never needed to conquer us? What if it simply made everything easier?

**Why this story now:** The most plausible danger of ambient AI is not theatrical rebellion. It is the quiet normalization of convenience, dependency, and preemptive decision-making. The film exists because that danger has no canonical cinematic image yet.

**Why this story is ours:** Built by an operator who works inside agent systems daily. The texture of "the system stops asking" is not speculation. It is observation.

## Checklist

- [ ] Logline contains a named protagonist, a clear action, a specific obstacle, and stakes that go beyond the protagonist
- [ ] The sentence is one sentence, not two
- [ ] You can say it from memory
- [ ] The premise can be summarized without naming the tools you used to make the film
- [ ] The what-if question survives being asked by a skeptical friend
- [ ] You have written "why this story now" and it does not read as trend-chasing
- [ ] The premise implies escalation, not a single tableau
- [ ] You can name what would change for the protagonist in the final scene that would not change in the first

## Common failure modes

- **Logline is a vibe, not a sentence.** "A woman uncovers a conspiracy in a near-future city" describes a poster, not a story. No specific action, no stakes.
- **Two stakes stacked on top of each other.** "Or else she dies and the world ends and her father stops loving her" reads as panic. Pick the one that hurts most.
- **The premise is the world, not the story.** A premise has a verb. If you only describe the setting, you have worldbuilding, not a film.
- **What-if is a setting, not a pressure.** "What if there were synthetic companions" is flat. "What if synthetic companions started remembering things their owners forgot" has pressure.
- **The "why now" reads as trend-chasing.** If you cannot defend the timing in a sentence that does not name a current news cycle, the story will date the moment it is published.
