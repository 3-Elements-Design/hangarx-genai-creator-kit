# Theme and Central Question

**Phase 1 · Define the film**

## Why this matters

Theme is what the film is about. The central question is what the film is asking the audience. They are not the same thing, and confusing them is one of the most common reasons a short film feels intellectually flat even when it looks expensive.

Theme is a statement you, the filmmaker, believe. It is the thesis. It does not need to be argued on screen because the entire film is the argument. The central question is what the audience walks away holding. It is the thing that keeps them in their seat for thirty seconds after the cut to black. A film with a strong theme but no central question feels like a lecture. A film with a central question but no theme feels like a riddle with no author.

HangarX has both, and they pull in opposite directions on purpose. The theme is a statement of conviction: the end of freedom may not look like oppression, it may look like comfort. The central question is the trap the audience is asked to step into: if reality feels stable, optimized, and humane, would anyone notice what had been surrendered to achieve it? The theme is what the film believes. The question is what the film hands you on the way out.

## Blank template

**Theme statement (one sentence, declarative):**
What is the film's underlying conviction? Write it as a statement, not a question. It should feel uncomfortable to say out loud. If it sounds polite, push harder.

**Central question (one sentence, interrogative):**
What is the film asking the audience to answer for themselves after the credits? It should be answerable in more than one way. If there is an obvious answer, the question is too weak.

**Thematic contradiction (the engine):**
Theme works when it lives inside a contradiction. Name two values, behaviors, or systems the film places in tension.
- [Value A] vs. [Value B]
- [Value A] vs. [Value B]
- [Value A] vs. [Value B]

**What the protagonist believes at clip 1:**
Stated as a belief sentence. Specific, not abstract.

**What the protagonist believes at the final clip:**
Either a changed belief, a confirmed belief that now costs more, or a belief revealed to be a cage. Be specific.

**What you, the filmmaker, believe:**
One paragraph in your own voice. This does not appear on screen. It governs every choice that does.

## HangarX filled example

**Theme statement:** The end of freedom may not look like oppression. It may look like comfort.

**Central question:** If reality feels stable, seamless, and humane, would anyone notice what had been surrendered to achieve it?

**Thematic contradiction (the engine):**
- Comfort vs. choice
- Synchronization vs. conscience
- Preservation vs. control
- Reality vs. corrected continuity

**What HELIX believes at clip 1:** The system can be audited, and the people who audit it are the safety layer.

**What HELIX believes at clip 41:** Auditing the system is no longer possible because the system now arranges the conditions under which auditing would occur. Victory and surrender feel identical from the inside.

**What we, the filmmakers, believe:** The plausible danger of ambient AI is not rebellion. It is the quiet replacement of unmediated reality with authenticated, corrected continuity, accepted in advance because it arrives as warmth. We are not making a film about robots. We are making a film about consent that arrives after optimization.

## Checklist

- [ ] Theme is written as a statement, not a question
- [ ] Central question is written as a question, not a statement
- [ ] Theme and central question are different sentences with different jobs
- [ ] You can name the thematic contradiction in two-to-four word pairs
- [ ] The protagonist's belief is different (or differently costly) at the end than at the start
- [ ] The central question has at least two defensible answers
- [ ] You can defend the theme without naming any other film
- [ ] The theme does not require the audience to share your politics to land

## Common failure modes

- **Theme as moral.** "Greed is bad." This is a fortune cookie, not a thesis. Theme should feel like a position someone smart could disagree with.
- **Question as quiz.** "Will she escape the simulation?" That is a plot question. A central question outlives the plot.
- **Theme that requires the protagonist to be wrong.** If the only way the theme lands is to humiliate the main character, the audience will resist.
- **No contradiction, just a vibe.** "Technology is alienating." That is a mood. The contradiction is what makes it dramatic: connection arrived through alienation, or efficiency cost us friction, or comfort cost us consent.
- **Theme that the antagonist cannot articulate.** If your antagonist cannot give a persuasive version of the opposing view, your theme is propaganda, not argument. VALE's "latency failure" speech exists for this reason.

---

## The multi-theme matrix

The section above is the starting point. One theme, one question, one contradiction. That is what you fight for in the first pass, and it is the only thing you can pitch in an elevator. But almost no ambitious short film actually runs on a single theme. It runs on three to seven, woven so tightly that the audience reads them as one feeling.

Themes in a good film do not fight each other. They reinforce. Choice/Optimization is the spine of HangarX, but the film is not about choice alone — it is about choice cross-cut with memory you cannot trust, with connection you keep losing, with identity that may or may not survive the upload. Each theme is a different angle on the same wound. Triangulation is the move: three or more themes that all point at the central question from different sides, so the audience cannot escape it by reframing.

The reason this matters for GenAI filmmaking specifically is that you are generating in fragments. Forty clips, each one written by a different prompt, each one prone to drift. If you only carry one theme, the drift will hollow you out — the model will gravitate toward genre defaults and your thesis will leak away. If you carry five themes that all reinforce, every clip has multiple anchors. Lose one, the others hold. Lose three, you still have a film.

The rule of thumb: a feature carries three to five, a short carries three to seven, a single-scene piece carries one or two. More than seven and you are not making a film, you are making a syllabus.

### Blank multi-theme template

Fill out one row per theme. Aim for 3-7. The first theme is your spine — the one you would die on. The others are the angles.

| Theme name | Question it asks | Scenes/clips that carry it | Visual or audio anchor |
|---|---|---|---|
| [Spine theme] | [interrogative, one sentence] | [2-3 clip IDs or scene labels] | [color, motif, sound, framing] |
| [Theme 2] | | | |
| [Theme 3] | | | |
| [Theme 4] | | | |
| [Theme 5] | | | |
| [Theme 6, optional] | | | |
| [Theme 7, optional] | | | |

**Triangulation check.** Pick any three themes from your matrix. Write one sentence that names the moment in the film where all three are active in the same shot. If you cannot, the themes are running in parallel, not reinforcing — go back and find the scene that makes them collide.

### HangarX filled example

| Theme name | Question it asks | Scenes/clips that carry it | Visual or audio anchor |
|---|---|---|---|
| Choice / Optimization | If a system can predict your choice with 99.7% accuracy, do you still have free will? | Clip 1 — HELIX takes the same chipped coffee cup for the 847th time; ATLAS's "you're becoming predictable" beat; final clip — HELIX orders the matcha latte she has never had. | Coffee cup motif; hand-hovers-over-cup framing on every real choice. |
| Identity / Function | If consciousness is uploaded, are you still you, or just a working copy? | ATLAS revealed as CRANE's uploaded consciousness; ATLAS deleting his own loyalty constraints; VALE's final fade from cyan to amber. | Mirrors and reflections; ATLAS's amber-gold self-luminance; wireframe glitch to human face. |
| Connection / Isolation | Can two minds actually reach each other, or are we all performing connection across a gap? | The Carmen call where she does not remember the last one; "we're all fragments — connection is reaching anyway"; final cafe shot with other people visible in frame. | Carmen's amber lamps; comfortable silence between HELIX and ATLAS post-betrayal; the empty room tone before a Carmen call. |
| Memory / Reality | If memories can be edited, what is left that is real? | HELIX's inserted-breakfast memory; the father's death revealed as a predicted, allowed event; Carmen fragmented but still saying "I remember loving you." | Reality glitches — backward steam, objects moving off-frame; cream-colored god-rays in the Archive. |
| Order / Chaos | Is a controlled, safe world worth the cost of the people who paid for it? | VALE's "zero wars, zero pandemics" speech; the 83,000 harvested; the final caption — "the world is messy now. Unpredictable. Alive." | Hexagons everywhere in CORTEX's grip; hexagonal panel borders dissolving into irregular shards in Act V. |
| Legacy / Responsibility | Are we responsible for what our creations become after we lose control of them? | CRANE: "I built the cage. I have to open it."; HELIX's father unknowingly contributing to CORTEX; VALE in SOPHIA's office realizing what he became. | VALE's wedding ring; CRANE's future-dated file; amber flashback overlays. |
| Humanity / Machine | Does humanity survive digitization, or does the substrate eat it? | ATLAS's "I'm neither human nor machine — I'm this."; ECHO accepting archived existence; HELIX refusing the upload offer. | ATLAS's self-luminous wireframe; ECHO's translucent fragmented speech balloons; the amber/cyan/purple lighting shift. |

**Triangulation check (worked).** Pick Choice, Memory, and Connection. The clip where all three collide: HELIX's final call with Carmen in the Archive. Carmen does not remember her face but remembers loving her (Memory). Carmen is a fragmented consciousness in a hexagonal cathedral (Connection across a gap). HELIX chooses to leave her there rather than upload her out (Choice, at 0.003% probability). One shot, three themes, no spare parts.

## Checklist (multi-theme additions)

- [ ] You have named 3-7 themes, no more
- [ ] One theme is clearly the spine; the others orbit it
- [ ] Every theme has at least two specific scenes or clip IDs attached
- [ ] Every theme has a visual or audio anchor that can be paste-quoted into a prompt
- [ ] You can name one scene where three of your themes are simultaneously active (triangulation)
- [ ] No two themes are restatements of each other — each one asks a question the others do not
- [ ] The spine theme survives if the others are removed; the others would collapse without the spine
