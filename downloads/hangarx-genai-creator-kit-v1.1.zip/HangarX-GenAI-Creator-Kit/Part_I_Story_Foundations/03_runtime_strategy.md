# Runtime Strategy

**Phase 1 · Define the film**

## Why this matters

Runtime is a structural decision, not a length. Choosing 10 minutes versus 22 minutes versus 3 minutes is not about how much story you have. It is about how much pressure per minute the story can hold, what distribution windows exist for that pressure, and what your tools can sustain before they start to drift.

GenAI tools work in bursts. Sora, Seedance, Veo, Runway, all of them produce their best work in short generative windows. Quality holds for seconds, not minutes. Continuity holds for clips, not sequences. If you fight that grain, you will spend your budget on cleanup. If you design for it, your runtime becomes a series of high-density units that compound. HangarX is 40 clips at 15 seconds because that is the unit GenAI rewards, multiplied by the smallest count that can carry a full thesis-to-payoff arc at festival-friendly length.

The other half of runtime strategy is the audience. Attention budgets are not abstract. A YouTube viewer is one swipe from leaving. A festival programmer is one minute from your inbox. A trailer audience expects a punch. Pick the runtime that matches the distribution window you are actually targeting, not the one you wish you were targeting.

## Blank template

**Target distribution window:**
Where will this film actually be watched first? YouTube. Festival shorts block. Internal pitch. Social platform. Be specific. "Online" is not a window.

**Target runtime:**
Pick a number in minutes. Defend it in one sentence against the next size up and the next size down.

**Tool capability per clip:**
What is the longest single generation your primary motion tool produces reliably? Multiply that by the count of clips you can actually produce, prompt, and continuity-check at the quality bar you have set.

**Story pressure per minute (the budget):**
List the major reveals, escalations, or turns your story requires. Divide your runtime by that count. If the answer is less than one minute per turn, you need more runtime or fewer turns. If the answer is more than two minutes per turn, you will lose the audience.

**Clip architecture:**
- Clip duration:
- Clip count:
- Acts (number and break points):
- Bridge / refinement beats:

**Festival eligibility check:**
Most festival shorts categories cap at 15, 20, or 30 minutes. If you are over 10 minutes, you are competing against half-hour films. If you are under 5, you are competing against music videos. Where do you land?

## HangarX filled example

**Target distribution window:** YouTube primary, with festival shorts and creator-kit showcase as secondary. The film also functions as the proof-of-concept attached to a downloadable workflow.

**Target runtime:** 10 minutes. Defended against 22 minutes because GenAI continuity at that length would consume the whole budget on drift cleanup. Defended against 3 minutes because the thesis (delegated world to hidden layer to ideological conflict to corrected reality) needs four conceptual turns, and four turns cannot land in 180 seconds without becoming a trailer.

**Tool capability per clip:** 15 seconds is the sweet spot for cinematic motion generation at the realism bar HangarX requires. Longer clips drift on faces and environments. Shorter clips fragment the story rhythm. Forty clips is the largest count we can actually prompt, generate, continuity-check, and audio-pass at the quality required.

**Story pressure per minute (the budget):**
- 10 minutes
- Roughly nine major beats (thesis, anomaly, hidden layer, archive horror, antagonist ideology, descent, confrontation, victory, corrected-reality dread)
- Approximately one beat per minute, with the final two beats compressed into the last 90 seconds for impact

**Clip architecture:**
- Clip duration: 15 seconds primary, with two 5-second refinement beats (40.1, 41)
- Clip count: 40 primary + 2 refinement = 42 units
- Acts: 3 acts. Break 1 at the hidden-layer reveal (~clip 4). Break 2 at the ideological confrontation (~clip 33)
- Bridge / refinement beats: Clip 40.1 added late to carry philosophical VO into the final image. Clip 41 reduced to 5 seconds because the reflection mismatch lands faster than 15 seconds would allow

**Festival eligibility check:** 10 minutes places HangarX comfortably inside short-film categories at most festivals. It is long enough to be taken seriously as a film, short enough to fit programming blocks, and short enough to retain online attention without sacrificing thesis.

## Runtime comparison table

| Runtime | Typical use | Beats it holds | Distribution window | Tool grain | Risk |
|---|---|---|---|---|---|
| 3-min vignette | Trailer, mood piece, social hook, single-image meditation | 1–2 turns. One discovery, no resolution required | Social, top-of-funnel, ads, portfolio teaser | Excellent. Each clip can be hand-tuned | Cannot hold a thesis. Reads as a tone reel if not designed for compression |
| 5–7 min short | Festival pre-roll, proof of concept, vertical-format premium | 3–5 turns. Inciting event, descent, payoff | Festival shorts blocks, YouTube, creator showcase | Strong. Continuity is manageable at 20–28 clips | Pacing must be tight. No room for atmosphere clips that do not also reveal |
| 10-min short | Festival shorts main category, YouTube prestige, case study film | 6–9 turns. Full three-act with thematic landing | Festival, YouTube, portfolio, downloadable kit anchor | Workable at 40 clips. Requires a continuity system | Drift accumulates. Without continuity packs, faces and worlds slip by minute 6 |
| 15-min short | Festival eligibility ceiling for most "short" categories | 8–12 turns. Subplot capacity | Festival circuit, streaming shorts | Difficult. Continuity demands a real pipeline | Production cost roughly doubles for diminishing narrative return |
| 22-min episode | TV pilot, streaming episode format | 12–18 turns. Multiple characters, B-plot | Streaming, pitch packages | Currently a stretch for solo GenAI workflows | Drift, audio production, and pacing all compound. Most projects collapse here |

## Checklist

- [ ] Runtime is defended in one sentence against the next size up and the next size down
- [ ] Distribution window is named specifically, not as "online"
- [ ] Clip count and clip duration are both fixed numbers, not ranges
- [ ] Story-pressure-per-minute count gives roughly one major beat per 60–90 seconds
- [ ] Tool capability has been tested, not assumed (you have generated at least one clip at your target duration and quality)
- [ ] Festival eligibility is confirmed if festival is a target
- [ ] Refinement / bridge beats are budgeted before they are needed, not added in panic

## Common failure modes

- **Runtime ambition exceeds tool grain.** Targeting 22 minutes with a tool that drifts after 15 seconds means most of the work is cleanup, not storytelling.
- **Beats per minute too sparse.** A 10-minute film with three beats is a meditation. That can work, but only if you committed to a meditation, not if you arrived there by accident.
- **No refinement beat budget.** The most important clip in HangarX (40.1) did not exist in the first plan. Leave room for late discoveries to add a beat.
- **Designing for festival without checking the rules.** A 16-minute short is in a different category than a 14-minute short at most festivals. Two minutes can disqualify a project.
- **Confusing short with simple.** A short does not have less story. It has the same story moving faster. Pace is the constraint, not narrative ambition.
