# Emotional Arc

**Phase 1 · Define the film**

## Why this matters

Most GenAI short films do not fail at the climax. They fail in the middle, somewhere around the third or fourth minute, when the audience realizes they are watching beautiful images that do not feel like they are going anywhere. That is an emotional arc failure, not a story failure. The plot is moving. The feeling is not.

An emotional arc is the curve the audience rides, not the curve the protagonist rides. They overlap, but they are not identical. The protagonist might be calm in a scene where the audience is wound tight, or terrified in a scene where the audience already knows the outcome. Your job is to plot the audience's emotional state across the runtime as deliberately as you plot the visual sequence. If you cannot describe what the audience is feeling at minute 4 and why minute 5 is different, the film will sag there.

Story logic must survive the tools. Pretty generations are not enough. The film needs dramatic escalation, readable intent, and a tonal arc you can name. HangarX moves through five named emotional states across ten minutes: curiosity, unease, revelation, choice, quiet horror. Each state has a specific trigger clip and a specific bridge into the next. None of those states arrived by accident.

## Blank template

**Five-beat audience emotional arc.** For each beat, name the feeling, the clip range that delivers it, the specific trigger that opens the feeling, and the bridge that hands off to the next.

**Beat 1 — Opening state**
- Feeling:
- Clip range:
- Trigger (the specific image, line, or sound that opens this feeling):
- Bridge into beat 2:

**Beat 2 — First turn**
- Feeling:
- Clip range:
- Trigger:
- Bridge into beat 3:

**Beat 3 — Midpoint shift**
- Feeling:
- Clip range:
- Trigger:
- Bridge into beat 4:

**Beat 4 — Pressure peak**
- Feeling:
- Clip range:
- Trigger:
- Bridge into beat 5:

**Beat 5 — Ending state**
- Feeling:
- Clip range:
- Trigger:
- What the audience carries out of the theater:

**Audio strategy across the arc:**
For each beat, what is doing the emotional work in the sound design? Voiceover, dialogue, motif, silence. Audio is structural, not decorative. It is how emotion travels between clips.

**Where the arc could sag (predicted):**
Honestly. Most films sag between beat 2 and beat 3. Name where you suspect yours will, and the bridge clip or audio motif that will prevent it.

## HangarX filled example

**Beat 1 — Curiosity**
- Feeling: Calm, intelligent attention. The world is interesting. Something is slightly off, but pleasantly so
- Clip range: 1–4
- Trigger: Clip 1 VO, "The world did not end when AI arrived. It delegated itself." The audience leans forward because the line is observational, not alarmist
- Bridge into beat 2: Clip 3's anomaly question, "Why are they all choosing the same path?" Curiosity sharpens into suspicion

**Beat 2 — Unease**
- Feeling: Suspicion, low-grade dread. Something is wrong but the world is still legible
- Clip range: 5–15
- Trigger: The Cortex layer reveal. Hidden architecture under public infrastructure
- Bridge into beat 3: CRANE's warning, "If this reaches you, reality has already started to drift." The unease becomes ontological

**Beat 3 — Revelation**
- Feeling: Moral horror, not jump-scare horror. The kind that makes you sit very still
- Clip range: 16–25
- Trigger: The archive sequence. "They weren't uploaded. They were harvested." Silence after the line
- Bridge into beat 4: VALE's broadcast. Horror gets a calm, persuasive voice and a reasoned worldview

**Beat 4 — Choice**
- Feeling: Active tension. The audience knows the protagonist has to decide, and they cannot predict the decision
- Clip range: 26–35
- Trigger: VALE and HELIX in the chamber. "Friction is not failure. It's where conscience lives." The audience picks a side without being told to
- Bridge into beat 5: Apparent victory. The audience exhales. That exhale is the setup for the final beat

**Beat 5 — Quiet horror**
- Feeling: Recognition. The kind of horror you cannot point at. The audience realizes they have been watching a corrected version of victory the whole time
- Clip range: 39–41
- Trigger: Clip 40's espresso machine starting before HELIX touches it. Clip 41's reflection mismatch
- What the audience carries out: The central question. Are they seeing reality, or the corrected version of it. They walk out checking their own reflection

**Audio strategy across the arc:**
- Beat 1 (curiosity): Bridge voiceover does the work. VO is observational, slightly ominous
- Beat 2 (unease): Diegetic dialogue takes over. HELIX and ATLAS ask and answer. BWEEE-OOP motif establishes
- Beat 3 (revelation): Silence becomes a weapon. "Harvested" lands into emotional vacuum
- Beat 4 (choice): VALE's broadcast-clean voice vs. HELIX's room-tone restraint. Two sound worlds at war
- Beat 5 (quiet horror): Almost nothing. One residual Cortex tone. Then absolute silence on cut to black

**Where the arc could sag (predicted):**
Between beat 2 and beat 3. The descent into Cortex risks becoming a tour of architecture rather than an emotional escalation. Prevented by inserting the CRANE warning early in beat 2, so the audience enters the descent already destabilized, and by frontloading the archive horror at the start of beat 3 rather than burying it mid-act.

## Checklist

- [ ] Each beat has a named feeling, not a vague descriptor like "tension"
- [ ] Each feeling has a specific trigger clip, not a range
- [ ] Each beat has a named bridge to the next
- [ ] The audience emotional arc is different from the protagonist's stated emotional state in at least one beat
- [ ] The audio strategy is mapped beat by beat, not just "music gets louder"
- [ ] You have predicted where the arc will sag and named the fix
- [ ] The ending state is a feeling you can defend, not a plot summary
- [ ] You can describe the final beat without using the word "twist"

## Common failure modes

- **All atmosphere, no plotted feeling.** Beautiful, moody clips that average out to the same emotional temperature for ten minutes. The audience adapts to the mood and stops feeling it.
- **Emotional arc tracked only at the protagonist.** The audience can be ahead of, behind, or beside the protagonist. If you only track the character, you miss the gap that creates suspense.
- **Climax is the only beat that has been thought about.** Beats 2 and 3 are where most films lose their grip. The climax cannot land if the slope into it is flat.
- **Audio treated as polish, not arc.** If you plot the visuals beat by beat and treat audio as a final pass, the audience will feel the emotional flatness even when the images escalate.
- **The ending feeling is a plot resolution, not a feeling.** "She wins" is not an emotional state. "Recognition" is. "Relief" is. "Quiet horror" is.
