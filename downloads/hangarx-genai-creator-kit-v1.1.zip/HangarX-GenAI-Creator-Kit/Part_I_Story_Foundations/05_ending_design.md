# Ending Design

**Phase 1 · Define the film**

## Why this matters

An ending is not where the plot resolves. An ending is where the central question pays off. If you confuse those two jobs, you will write an ending that explains too much, lands on a generic twist, or feels imported from a film with a different thesis. The audience does not need to know what happened. They need to know what to do with what they just felt.

The most common failure in GenAI short films is the explanatory ending. The film has been atmospheric and suggestive for nine minutes, then the final clip tells the audience what to think. The mood breaks. The thesis becomes a moral. The thing that made the film feel like a film evaporates in the last fifteen seconds. The fix is to design endings as the payoff to the central question, not as the resolution of the plot.

HangarX uses an "ending mismatch" approach. The plot resolves: HELIX wins. The central question does not. The final image (a coffee cup, raised one beat longer in the reflection than in the hand) destabilizes continuity by millimeters, with no overt VFX, no explanatory voiceover, and no twist reveal. Plot says victory. Image says the victory may already be the corrected version of itself. That mismatch is what the audience carries out of the theater. Small improvements compound. The ending is where they cash in.

## Blank template

**Central question (carried over from your theme document):**

**Plot resolution (what literally happens to the protagonist):**
One sentence. Did they win, lose, transform, or refuse the choice?

**Thematic payoff (what the central question does at the end):**
One sentence. The audience walks out holding what. Not "they walk out thinking about technology." Walk out holding what specific image, word, or unresolved feeling.

**Ending sequence design — four beats:**
Endings of any consequence are usually a sequence, not a single shot. Design four beats. The first reframes the victory. The second personalizes it. The third gives the thesis its final language. The fourth withholds explanation and destabilizes.

- **Beat A (reframe):**
  - Visual:
  - Audio / VO:
  - Purpose:

- **Beat B (personalize):**
  - Visual:
  - Audio / VO:
  - Purpose:

- **Beat C (thesis in language):**
  - Visual:
  - Audio / VO:
  - Purpose:

- **Beat D (destabilize and withhold):**
  - Visual:
  - Audio / VO:
  - Purpose:

**The ending mismatch:**
Name the specific gap between plot resolution and thematic payoff. The plot says X. The image says Y. The audience is the place where X and Y meet.

**What the ending refuses to do:**
List three things your ending will NOT do. This is as important as what it will do. Most weak endings are weak because they include a habit imported from another film.

## HangarX filled example

**Central question:** If reality feels stable, seamless, and humane, would anyone notice what had been surrendered to achieve it?

**Plot resolution:** HELIX stops the forced merge. She preserves choice. She wins.

**Thematic payoff:** The audience walks out holding the image of a coffee cup lowered in the hand but still raised in the reflection. They walk out unsure whether what they just watched was a victory or the corrected version of one.

**Ending sequence design — four beats:**

- **Beat A — Clip 39 (9:30–9:45). Reframe.**
  - Visual: Six months later. Corrected Berlin morning. Traffic parts before congestion forms. A café adjusts before a customer sits. Delivery arrives before being checked
  - Audio / VO: HELIX VO, "We stopped the forced merge. We preserved choice. And the world chose... easier." Soft city morning. Seamless service tones. Almost no conflict in the mix
  - Purpose: Reframe victory as voluntary dependence. The audience exhales at the victory, then notices the smoothness is wrong

- **Beat B — Clip 40 (9:45–10:00). Personalize.**
  - Visual: HELIX approaches an espresso machine. It begins brewing before she touches it. A Cortex notification: "47 decisions preemptively scheduled. Override?" She closes it
  - Audio / VO: Soft BWEEE-OOP. Room silence. No spoken line
  - Purpose: Show that convenience now precedes intention. The public thesis becomes a private moment

- **Beat C — Clip 40.1 (Bridge Beat, ~5 seconds). Thesis in language.**
  - Visual: Hold on HELIX with the coffee. The apartment continues making tiny anticipatory decisions before she requests them. Transit estimate updates. Light warms. A calendar conflict resolves itself
  - Audio / VO: HELIX VO, "We thought it would arrive like a warning. Instead, it arrived like warmth. A door already open. A room already waiting. A thought already finished before it became our own. And little by little, the distance between being guided and being gone became too small to name."
  - Purpose: Translate convenience into philosophical warning. The film names its own thesis without explaining it

- **Beat D — Clip 41 (10:00–10:05). Destabilize and withhold.**
  - Visual: HELIX lowers the coffee cup. In the window reflection, the cup remains raised for one extra beat. Cut to black
  - Audio / VO: No dialogue. One faint residual Cortex tone or distant BWEEE-OOP, almost subliminal. Then absolute silence
  - Purpose: Suggest the world may still be real, but what we are seeing may already be the corrected version of it. No explanation. No twist reveal. No VFX

**The ending mismatch:** Plot says HELIX won the fight against forced totality. Image says the world she preserved is already a corrected version of itself, and so, possibly, is she. The audience is the place where victory and surrender become the same shape.

**What the ending refuses to do:**
1. Refuses to confirm or deny "it was all a simulation." That question is the wrong question. The film has been asking a more specific one.
2. Refuses overt VFX. No glitch effects. No screen tears. The destabilization is one frame of reflection mismatch, no louder than that.
3. Refuses a final voiceover explaining the image. The VO in 40.1 is the last word. Clip 41 has none. Silence is the ending's signature.

## Checklist

- [ ] The ending pays off the central question, not just the plot
- [ ] The plot resolution and the thematic payoff are different sentences with different jobs
- [ ] The ending is a sequence of beats, not a single shot
- [ ] Each ending beat has a clear job (reframe, personalize, thesis, destabilize)
- [ ] You have named what your ending refuses to do, and the list is at least three items
- [ ] No clip in the ending sequence is purely explanatory
- [ ] The final beat withholds something the audience expects you to deliver
- [ ] The image that closes the film is specific enough to describe in one sentence

## Common failure modes

- **The explanatory final voiceover.** The film has been suggesting for nine minutes, then the final clip tells the audience what it meant. This collapses the central question into a statement and loses the audience's participation.
- **The generic simulation twist.** "It was all a simulation" is a habit from another generation of sci-fi. Unless your film has been specifically about simulation, this ending is imported, not earned.
- **Plot resolution mistaken for thematic payoff.** "She escapes" or "she dies" is a plot event. What does the audience feel when she does? If the plot resolution and the thematic payoff are the same sentence, the ending has only done half its job.
- **Single-shot ending where a sequence was needed.** Endings of consequence almost always need a reframe, a personalization, a thesis beat, and a destabilization. Trying to do all four in one shot produces clutter.
- **Overt VFX where stillness would land harder.** A reflection mismatch of one frame is more destabilizing than a screen-glitch sequence. The cheaper the trick, the more the audience trusts it.
- **The ending sequence built last.** Endings designed in the final week feel imported. The ending should be designed in Phase 1, alongside the logline, even if it changes later.
