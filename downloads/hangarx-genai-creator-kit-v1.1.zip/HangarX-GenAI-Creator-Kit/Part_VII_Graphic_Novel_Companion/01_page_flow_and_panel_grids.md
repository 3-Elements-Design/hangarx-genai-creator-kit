# Page Flow and Panel Grids

**Phase 4–7 · Adapted for comics**

## Why this matters

A graphic novel page is the comics equivalent of a clip. It is the smallest unit of dramatic delivery the reader experiences as one event. If you treat the page like a poster — beautiful, decorative, undirected — you will produce 41 attractive images that do not read as a story. If you treat the page like a clip — three jobs to do, an atmosphere, an information payload, a handoff to the next page — you will produce a graphic novel that does what the film does, in a different grammar.

The page is also where the reader's eye is choreographed. Panel grids are not aesthetic choices. They are pacing decisions. A 1-panel splash takes a reader ten seconds. A 9-panel grid takes a reader thirty. That is real time, allocated by the page layout, and the reader will resent you if the time you have asked for does not match the weight of the moment. Wasting a splash on a transitional beat reads as inflation. Crowding a revelation into a 6-panel grid reads as failure to feel it.

The HangarX graphic novel uses the same clip-grid logic as the short film. Each of the 41 pages has a purpose, an atmosphere, an information payload, and a handoff. The panel count and layout were chosen per page to deliver those four jobs at the right pace. Page 12 is one panel because the wireframe-consciousness descent had to land as a single emotional event. Page 23 is five panels because the Three Paths beat needs to feel like decision pressure, not revelation — three options, a reaction, a hand reaching for one. The grid is the pacing engine.

## The framework

### The page-as-clip mapping

Every clip in the short film answers four questions:
- Purpose: what dramatic job does this unit do
- Atmosphere: what does it feel like
- Information: what does the audience now know that they did not before
- Handoff: how does this clip set up the next one

Every page in the graphic novel answers the same four questions. Page numbers replace timecodes. Panel layout replaces clip duration. The page-turn replaces the cut. Otherwise the discipline is identical. If you have a 40-clip grid, you can build a 41-page grid by the same method.

### The five panel-grid types

**1-panel splash.** One image fills the page. Reader spends ten seconds. Use for: existential rupture, scale shift, the emotional center of an act. Cost: every splash you spend devalues the next one. HangarX uses three: Page 1 (cover), Page 12 (wireframe descent), Page 36 (the merge cascade).

**3-panel vertical.** Three stacked horizontal panels. Reads top-to-bottom in a single beat. Use for: dialogue at moments of moral weight, slow reveals, the held two-shot. The 3-panel grid is the page that feels most like a film cut. HangarX Page 33 (the final two-shot before VALE leaves the chamber) is a 3-panel.

**4-panel (2×2).** Two rows of two. The default cinematic page. Reads in a square pattern. Use for: standard narrative progression, action followed by reaction. The neutral grid. Reach for it when the page does not call for something else.

**6-panel (3×2 dense).** Three rows of two. Compressed time. Reads as quick succession. Use for: investigative sequences, montage, escalation, dialogue volleys. The 6-panel is the workhorse of pages where information density matters more than image dwell. HangarX Pages 5–7 (the loft anomaly discovery) are 6-panels because the reader needs to absorb a system being decoded.

**9-panel (Watchmen grid).** Three by three. Rigorously paced. Use sparingly. The 9-panel grid imposes a metronome on the reader. It is the right tool for surveillance pages, broken-time sequences, and moments where the rhythm itself is the meaning. Overused, it becomes a tic. HangarX uses one 9-panel on Page 38 (Vale surveilling the city) — and only there.

### When to pick which grid

Match the grid to the dramatic weight of the page, not to your aesthetic preference. The heuristic is: how much time does the reader owe this moment.

- Existential rupture or scale shift: 1-panel splash
- A held conversation that needs gravity: 3-panel vertical
- Standard narrative progression: 4-panel 2×2
- Information density, escalation, dialogue volleys: 6-panel 3×2
- Surveillance, broken time, metronomic dread: 9-panel

If you cannot defend why a page is not a 4-panel, it should be a 4-panel. The 4-panel is the default. Departures from the default earn their keep or get reset.

### The per-page template

For every page in the book, write this:

```markdown
### Page [#]

**Act:** [I / II / III / IV / V]
**Panel count and layout:** [e.g., 6-panel 3×2 dense]
**Purpose:** [what dramatic job this page does]
**Atmosphere:** [what it feels like — palette, lighting, scale]
**Information:** [what the reader now knows]
**Handoff:** [how this page sets up the next page-turn]
**Page-turn rule:** [does this page end on a hook, a reveal, a contradiction, a held image]
**Audio reference:** [the film clip this page corresponds to, if any]
```

That block is your unit of work. Fill out 41 of them. The result is a page grid that reads the way the film cuts.

### Page-turn discipline

Right-hand pages should end on something the reader cannot resist turning past. Left-hand pages can rest. This is the comics equivalent of the act-break in film. Right-hand-page hooks:

- A named threat
- A revealed layer
- A contradiction
- A line that reframes the page before it

If a right-hand page resolves cleanly into the next page without tension, you have wasted the page-turn. The reader will keep reading anyway, but they will not feel pulled.

## HangarX worked example

The HangarX graphic novel is 41 pages. The page-flow grid for all 41 pages is in `examples_HangarX/VII_graphic_novel_filled.md`. Two pages are worth showing here as examples of how the grid choice carries the dramatic weight.

**Page 12 — The Descent.** 1-panel splash. ACT II opens here. HELIX appears as a wireframe consciousness suspended in Layer-1 dust and broken geometry — the moment the body is gone and only intent remains. The caption: *"I used to think the hardest part was letting go."* One image, full page. Reader spends ten seconds. The 1-panel choice is load-bearing — any other grid would have asked the reader to move past this beat too quickly, and the entire act depends on the weight of this image landing.

**Page 23 — Three Paths, Three Futures, One Choice.** 5-panel layout. ACT III's central decision page. Three horizontal panels stacked at the top of the page show the three possible futures — preservation, synchronization, refusal. Below them, a wide panel of HELIX's face, holding the decision. At the page's bottom, a tight panel of her hand reaching toward one of the three. The reader's eye traces the same path HELIX's does: option, option, option, reaction, commitment. Five panels because the dramatic shape of the moment is five beats. A splash would have collapsed the decision into spectacle. A 4-panel would have flattened the reaction. The grid is the choreography.

Full breakdowns of both pages, with image-prompt structure and caption text, live in `examples_HangarX/VII_graphic_novel_filled.md`.

## Checklist

- [ ] Every page has a filled page-template block (purpose, atmosphere, information, handoff)
- [ ] Splash pages number three or fewer across the book
- [ ] Right-hand pages end on a hook, reveal, contradiction, or reframing line
- [ ] No page exists only to look good — each one passes the three-jobs test
- [ ] The grid choice on each page is defensible against "why is this not a 4-panel"
- [ ] The 9-panel grid is used at most once in the book
- [ ] Pages corresponding to film clips are cross-referenced to the clip number
- [ ] Act breaks fall on right-hand pages, not left-hand pages

## Common failure modes

- **Splash inflation.** Every "important" page becomes a splash. By page 20, splashes mean nothing. Reserve splashes for the three or four moments the rest of the book bends toward.
- **Default grid drift.** Every page is a 4-panel because the writer never asked what each page needed. The book reads as flat. Pacing is choreography; choose deliberately.
- **9-panel for atmosphere.** The 9-panel is a metronome, not a mood. Using it for ambience instead of for rhythmic dread turns the page into a wallpaper sample.
- **Right-hand pages resolving cleanly.** If the reader can stop at a right-hand page, they will. Hook every page-turn, or accept that you are inviting the reader to put the book down.
- **No clip cross-reference.** If your film and graphic novel share continuity packs, the page grid should know which film clips it parallels. Without cross-references, the two mediums drift in worldbuilding even when they should not.
- **Designing pages before writing the page grid.** Same failure mode as designing clips before writing the clip grid. The page is the unit; the grid is the contract.
