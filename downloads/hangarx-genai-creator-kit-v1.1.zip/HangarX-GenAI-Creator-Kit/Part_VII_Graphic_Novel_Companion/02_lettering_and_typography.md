# Lettering and Typography

**Phase 4–7 · Adapted for comics**

## Why this matters

Lettering is the part of a graphic novel that most readers do not consciously notice and that most amateur graphic novels get catastrophically wrong. Bad lettering makes a beautiful page unreadable. Good lettering disappears. Great lettering is part of the worldbuilding — the typography itself tells the reader what kind of voice is speaking, what kind of system is interrupting, and which sentences carry the thesis.

In a GenAI-driven comic, lettering is also the seam where the generated image meets the human hand. Image models do not reliably generate text. Captions, balloons, and SFX get composited in after. That seam is where the book either snaps into a coherent design system or reveals itself as a stack of pretty pictures with text dropped on top. The discipline is to design the type system before the first page is generated, and to leave deliberate negative space in every panel for the text that will arrive later.

HangarX uses a tight type system: one display face for emotion and caption (Cormorant Garamond), one body face for dialogue clarity (Inter), and one monospaced face for UI and diegetic system text (JetBrains Mono). Three faces. No more. Every page in the book obeys that hierarchy. The discipline is not aesthetic preference. It is the same discipline that makes the visual continuity hold across 41 pages.

## The framework

### The three voice channels

Every text element on a comics page is in one of three voice channels.

**Caption boxes.** The narrator's voice, the protagonist's interior monologue, or the omniscient thesis line. Captions exist outside the diegetic space. They are layered on top of the panel, usually in a colored box or against a held cream field. Use them for: time and place shifts, thesis statements, interior monologue, reflective end-of-act beats. Do not use them for narration that could have been dialogue. If a character can say it, do not let a caption say it.

**Speech bubbles.** Diegetic spoken dialogue, in the world. The shape of the bubble carries information: a standard oval for spoken speech, a jagged border for shouted or distorted speech, a dashed border for whispered or comm-channel speech, a squared or geometric border for AI/system speech. Bubbles always have a tail pointing to the speaker. If the tail is ambiguous, the panel is broken.

**Interior monologue boxes.** A subset of captions, but tied to a specific character's POV. These are the protagonist's private thoughts. Differentiate them from omniscient captions by color (cream-on-navy interior thoughts, vs. navy-on-cream captions, for example) and by tail or tag (e.g., a small "HELIX:" tag, or a dotted line back to the character's head).

The line that separates these three channels is what makes a page legible. If captions, bubbles, and interior monologue look the same, the reader does not know who is speaking, and the page collapses into noise.

### Sound effects

SFX are the fourth channel but they live closer to drawing than to typography. They should feel hand-placed, weighted to the action, and restrained. HangarX SFX vocabulary (locked):

- **BWEEE-OOP** — the Cortex notification cue. Soft, elegant. Set in display caps, low weight.
- **HUMMMMM** — system resonance, ambient. Long extended letters, low contrast against the panel.
- **KRRRSH** — physical impact, system fracture. Bold, sharp serifs.
- **TCHK** — hardware contact, small mechanical events. Tight, condensed.
- **VRMM** — neural rig engagement. Medium weight.
- **THRUM** — the merge wave, Page 30. Heavy, structural.

The discipline: no superhero-loud SFX. No "POW," no "BOOM." HangarX is a quiet film translated into a quiet comic. The SFX are restrained because the world is restrained. A loud SFX in HangarX would read as tonally broken.

### Diegetic UI typography

This is the part of comics typography that most projects skip and that HangarX makes a load-bearing worldbuilding element. The Cortex system speaks on-page through UI overlays:

- "PROTOCOL STATUS: MIRROR SYNC 73.2%"
- "MEMORY FRAGMENT CORRUPTED"
- "47 DECISIONS PREEMPTIVELY SCHEDULED. OVERRIDE?"
- "AUTHENTICATING CONTINUITY..."

These are not captions and not speech. They are the world's interface speaking on the page. Set them in monospace (JetBrains Mono), in cyan `#2FAFC0` against navy backgrounds. They appear in the margins of panels, in floating UI windows within scenes, or layered over backgrounds. Treat them as a fourth character. They have their own typographic identity.

### Font choice rules

Pick three faces. One display, one body, one mono. No more.

- **Display face.** For captions, chapter titles, the thesis lines. Use a serif with character — something that feels editorial, not screen-generic. HangarX uses Cormorant Garamond. Other workable choices: Playfair Display, Source Serif, Crimson Pro. Avoid anything that screams "fantasy" or "branding."
- **Body face.** For dialogue inside speech bubbles. Use a sans-serif designed for legibility at small sizes. Most comic lettering uses a slightly hand-drawn sans. HangarX uses Inter for its clarity and neutrality. Other options: Lato, Source Sans, the various CC fonts (CC Wild Words, CC Astro City) if you want a traditional comics look. Be consistent.
- **Mono face.** For UI text and any in-world data. Use a designer monospace, not Courier. HangarX uses JetBrains Mono. Other options: IBM Plex Mono, Fira Code.

If you find yourself reaching for a fourth face, you are adding a voice the book does not need. Subtract instead.

### Caption density per panel

Hard rule: no more than ~30 words per caption. If you have more than 30 words to say, you need another panel.

Captions are the slowest text on the page. The reader stops the eye to read them. A 60-word caption stops the reader for too long, breaks the rhythm of the panel, and reveals that the writer did not have a visual to carry the information. If the caption has to do all the work, the page failed before lettering arrived.

Corollary: most pages should have one or two captions, not five. If every panel has a caption, the book is being narrated, not drawn.

## HangarX worked example

HangarX page 40.1 (the philosophical landing, mirrored from the film's bridge beat) is the densest caption page in the book. Even there, the caption is fragmented across two panels, not stacked into one:

**Panel 1 caption (Cormorant Garamond, ~22 words):**
*"We thought it would arrive like a warning. Instead, it arrived like warmth. A door already open."*

**Panel 2 caption (Cormorant Garamond, ~16 words):**
*"A room already waiting. A thought already finished before it became our own."*

That is 38 words across two panels, never more than 22 in one. The reader spends the right amount of time on each line. The thesis lands because the type is paced.

The same page uses one UI overlay (JetBrains Mono, cyan on navy): `MIRROR SYNC 99.4%` in the corner of the second panel. The body face does not appear on this page — there is no spoken dialogue. Three channels, two of them used, the third deliberately silent.

Full type-system reference (with face sizes, colors, hex codes, and bubble-shape rules) lives in `examples_HangarX/VII_graphic_novel_filled.md`.

## Checklist

- [ ] Three faces locked: one display, one body, one mono
- [ ] Caption box style is distinct from interior monologue box style
- [ ] Bubble shape rules cover spoken, shouted, whispered, AI/system speech
- [ ] SFX vocabulary is locked to a restrained set (no superhero loudness)
- [ ] Diegetic UI text uses the mono face and is treated as a fourth voice
- [ ] No caption exceeds ~30 words
- [ ] No page has more captions than panels
- [ ] Negative space in panel composition has been reserved for text placement before image generation

## Common failure modes

- **Five fonts on one page.** The book reads as a typographic zoo. Subtract until you are at three.
- **Captions doing the work the image should do.** If a panel needs a 60-word caption to explain itself, the panel failed. Redraw, do not over-narrate.
- **Bubble shapes inconsistent.** AI speech sometimes square, sometimes oval. Lock the rule and hold it across every page.
- **SFX too loud.** "BOOM" in a quiet noir page reads as tonally borrowed from a different book. SFX vocabulary must match the film's sonic identity.
- **No negative space for text.** Pages are generated as full-bleed images, and the letterer has nowhere to place the caption. Plan the negative space at the image-prompt stage.
- **Diegetic UI text composited in afterward as decoration.** UI text is worldbuilding. If it does not say something specific about Cortex behavior, it should not be on the page.
- **Display face used for dialogue.** Serif dialogue reads as period drama. Save the serif for captions.
