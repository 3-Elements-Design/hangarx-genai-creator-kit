# Cross-Medium Continuity Pack

**Phase 4–7 · Adapted for comics**

## Why this matters

If you are producing a short film and a graphic novel from the same story world, the continuity packs you built for the film are not optional for the comic. They are the spine of the comic. Same face geometry. Same age. Same build. Same wardrobe rules. Same color associations. The reader who watches the film and then opens the book should immediately recognize the same person. If HELIX looks like a different woman in the graphic novel than she does in the film, you have not made a cross-medium project. You have made two unrelated assets that share a logo.

This is also the cheapest part of cross-medium work to get right. The continuity pack already exists. You wrote it for the film. The graphic novel does not require a new continuity pack. It requires a medium-specific addendum that names the small set of things that change between the two mediums — lighting, motion logic, color application — and locks everything else.

HangarX uses one source-of-truth continuity file (the same four-character pack built for the short film) plus a four-paragraph comics addendum. The addendum is short on purpose. The longer the addendum, the more drift between film and comic. The discipline is to constrain the differences, not to invent new identities for the comic.

## The framework

### What transfers verbatim from film to comic

The continuity pack you built in Part II carries the entire identity layer of every character. The following fields do not change across mediums:

- Age and age read
- Heritage and physical build
- Face geometry (cheekbones, jaw, eye shape, brow, nose, skin)
- Hair color, length, style
- Wardrobe rules (base, alternate, end-state)
- Forbidden styling
- Performance restraint notes
- Color signature (which palette colors the character lives inside)

If any of those fields would need to change between film and comic, you have a problem with the continuity pack, not with the comic. Fix the pack.

### What changes between mediums

Three things change. Lighting. Motion logic. Color application. Each one requires a specific addendum.

**Lighting.** Film uses photoreal lighting — diffused dawn, low-key interior, lens flare on practical sources. Comics use stylized chiaroscuro — high contrast, deep blacks, restrained highlight placement. The character's lighting relationship from the continuity pack translates, but the rendering changes. HELIX "best lit by dawn natural light" becomes, in the comic, "rendered in soft cream highlights against deep navy shadow, dawn as suggested rather than photographed."

**Motion logic.** Film implies motion across time — the camera moves, the subject moves, the cut delivers change. Comics imply motion in a single frame using:
- Speed lines or streak blur for fast motion
- Multiple positions of the same figure across the panel for sequential motion
- Implied force lines (architectural perspective bending toward the action)
- Vibration or duplicate-edge effects for tremor or system distortion

The continuity pack's "performance range" field is where this addendum lives. HELIX's restraint translates as fewer motion indicators around her body, not more. VALE's stillness becomes the absence of any speed effect — he is the figure in the panel who is never moving.

**Color application.** Film uses palette as ambient lighting (warm gold spill, cool cyan interface light, deep navy shadow). Comics use palette as graphic accent — flat color blocks, controlled contamination, deliberate restraint. The same color hex codes apply, but the application is different:
- Film: gold light spills across HELIX's face when Cortex is active
- Comic: gold appears as a flat tint behind her, or as a circuit-vein graphic accent at the eyes, or as a single gold panel-border on pages where Cortex is the dominant force

The discipline: same palette, different grammar. Locked hex codes from the film carry across.

### The cross-medium pack structure

For each character, the cross-medium pack has two parts.

**Part 1: The original continuity pack** (from Part II, unchanged). This is the source of truth. Do not modify.

**Part 2: The comics addendum** (a short paragraph per character covering only lighting, motion logic, and color application).

That is the entire structure. If you find yourself writing more than half a page of addendum per character, you are inventing a second character. Restrain.

### The base block carries

The Continuity Prompt Base Block (the locked ~100-word identity description pasted into every prompt) carries from film to comic with one modification: append a single line at the end naming the medium and the render grammar.

For HELIX, the film base block ends: *"Documentary-real cinematic noir. Preserve consistent face geometry, age, posture, and exhausted-alert emotional tone across all images."*

The comic addendum appends: *"Rendered as photoreal cinematic noir translated into illustrated sequential art — high contrast, deep blacks, restrained palette accent. Maintain identical face geometry and age read as the film continuity reference."*

Same identity. Different render. The append line is the entire difference.

## HangarX worked example

HELIX's cross-medium addendum, in full:

**Lighting addendum.** In the comic, HELIX is rendered in soft cream highlights (`#FEF9E7`) against deep navy (`#0A0E1A`) shadow. Restrained amber spill at the edges of her face when Cortex is active in the panel. No glamour highlight. The eye remains the brightest point on her face — same rule as the film. Dawn is suggested through restrained light placement, not painted in.

**Motion logic addendum.** HELIX moves rarely. When she does, render her motion with minimal indicators — a single trailing edge, or repositioned hands across two panels, never speed lines. Her restraint translates as graphic stillness. The reader should feel that she is the calmest figure on every page she appears on, even when the page is escalating.

**Color application addendum.** Cyan dominates her early pages. Gold begins contaminating her panels in ACT II — first as small accent in interface UI, then as edge-light at her eyes, then as faint circuit-vein graphic accent in ACT IV. In the wireframe-consciousness pages (12–15), HELIX is rendered in cyan only — `#2FAFC0` line work on navy field, no skin tones. That is the single biggest medium-specific decision in the book.

The full addendum set (HELIX wireframe state, VALE chiaroscuro, ECHO cyan-only treatment, ATLAS gold wireframe) lives in `examples_HangarX/VII_graphic_novel_filled.md`.

## Checklist

- [ ] Cross-medium pack uses the film continuity pack as the source of truth, not a rewrite
- [ ] Addendum per character is short — one paragraph each on lighting, motion logic, color application
- [ ] Continuity Prompt Base Block carries verbatim, with a single append line naming the comic render grammar
- [ ] Hex codes are identical across film and comic
- [ ] Forbidden styling list from the film applies to the comic without modification
- [ ] At least one character has a medium-specific visual state called out (e.g., HELIX wireframe in ACT II)
- [ ] If the comic introduces a new render grammar (chiaroscuro, line-only, color-block-only), it is named and constrained
- [ ] The reader who watches the film and then opens the comic recognizes every character within one page

## Common failure modes

- **Two parallel continuity packs.** The team writes a separate pack for the comic and a separate pack for the film. They drift within a week. One source of truth, with addenda.
- **Addendum bloat.** A four-page addendum is a rewrite. Constrain to one paragraph per character, scoped to lighting, motion logic, and color application.
- **Different palette hex codes across mediums.** Cyan is the same hex code in the film and the comic. Forty hex codes is forty drift opportunities. Lock them.
- **Photoreal rendering attempted in comics.** Trying to recreate the film's lighting in illustrated form produces uncanny mid-realism. Pick a graphic grammar (chiaroscuro, line-and-color-block, painted) and commit.
- **Motion grammar imported from superhero comics.** Speed lines on every action panel. HangarX's restraint does not survive that. Match the motion grammar to the film's kinetic restraint.
- **End-state variants not addended.** HELIX's faint golden circuit-vein luminosity in the final act needs a comic-specific render note. Otherwise the artist defaults to the base look across the entire book and the visual arc flattens.
- **No call-out for medium-specific visual states.** If the wireframe-consciousness pages are not flagged in the addendum, the artist will render HELIX in skin tones during Layer-1 sequences and the entire ACT II loses its grammar.
