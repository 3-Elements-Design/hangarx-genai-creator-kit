# Comics Prompt Pack

**Phase 4–7 · Adapted for comics**

## Why this matters

Image prompts for comics are not image prompts for film stills wearing a different hat. A film still is a single frame; the model can compose it freely, place the subject anywhere, fill the frame edge to edge. A comics page is a composed image with structural rules: panel borders, gutters, reading order, deliberate negative space for captions and balloons, and a style that must hold across 41 pages and not drift. If you write comics prompts the way you write film-still prompts, you will get beautiful images that cannot be lettered, cannot be sequenced, and cannot be recognized as part of the same book.

The prompt is where the medium-specific decisions get enforced. Reading order has to be called out so the model composes left-to-right, top-to-bottom. Negative space has to be reserved or the letterer has nowhere to place the caption. Panel borders and gutters have to be specified or the model produces a single full-bleed image that cannot be cut into a grid. Style coherence has to be locked at the prompt level or page 14 looks like a different book than page 4.

HangarX comics prompts follow a fixed structure. Same skeleton for every page. Continuity pack base block pasted in unchanged. Medium-specific render line appended. Reading order named. Negative space reserved. That structure is what makes 41 pages cohere.

## The framework

### How comics prompts differ from film prompts

Six fields change:

**Page composition.** Film prompt names a shot. Comics prompt names a page — panel count, panel layout, panel borders, gutter color and width. The page is the unit, not the shot.

**Reading order.** Film prompt assumes one image. Comics prompt must explicitly direct the model: "Compose the page so the reader's eye moves left to right, top to bottom across the panels." Without this, the model produces compositions that fight the reading order.

**Text placement.** Film prompt does not reserve space for captions. Comics prompt must reserve negative space — usually upper-left for caption boxes, lower-third for dialogue, restrained corners for SFX. State this explicitly.

**Style coherence.** Film prompt anchors style per shot. Comics prompt anchors style per book — the same style line appears in every prompt, unchanged, across all 41 pages.

**Render grammar.** Film prompt uses photoreal language ("documentary-real cinematic noir"). Comics prompt uses comics-rendering language ("photoreal cinematic noir translated into illustrated sequential art — high contrast, deep blacks, restrained palette accent").

**Continuity carry.** Film prompt pastes the continuity base block. Comics prompt pastes the same base block plus the medium-specific append line (see Part VII file 03).

### The HangarX comics prompt skeleton

```
[Page #] [Act, page-flow purpose]

[Panel count + layout: e.g., "6-panel 3x2 grid, thin black borders,
3px gutter, reading left to right top to bottom"]

[Style anchor — locked across all pages:
"Photoreal cinematic noir translated into illustrated sequential art.
High contrast chiaroscuro, deep blacks, restrained palette accent in
warm gold #C79A5A, cool cyan #2FAFC0, deep navy #0A0E1A, and pale cream
#FEF9E7. Editorial grain texture. No superhero stylization."]

[Subject continuity — paste continuity pack base block for any character
appearing on this page, plus the comic-render append line]

[Per-panel action — one sentence per panel, in reading order:
"Panel 1: [action]. Panel 2: [action]. Panel 3: [action]..."]

[Captions and balloons to leave space for — reserve negative space:
"Leave clean negative space in the upper-left of Panel 1 for a caption
box (~40% panel width). Reserve lower-right of Panel 4 for a speech
balloon (~25% panel area). No text generation — captions and balloons
will be composited in post."]

[Mood — one sentence: "Page mood: quiet horror, escalating, restrained."]

[Avoid — plain language exclusions:
"Avoid superhero stylization, neon palette drift, glamour lighting,
fantasy rendering, comic-book speed lines on this page."]
```

Eight slots. Each one earns its keep.

### Field-by-field guidance

**Page header.** Always include page number, act, and the one-sentence purpose from the page grid. This grounds the model — and reminds the prompt writer — what dramatic job this page does.

**Panel count and layout.** Be explicit. "6-panel 3×2 grid" is not enough. State border thickness, gutter color, gutter width, reading direction. The model will otherwise produce a full-bleed image that cannot be paginated.

**Style anchor.** Lock this line and paste it into every prompt without modification. The temptation to vary it page by page is the single biggest threat to style coherence. Resist.

**Subject continuity.** Paste the continuity pack base block unchanged. For HangarX, that means HELIX, VALE, ECHO, or ATLAS appears via the same ~100-word identity block on every prompt. Plus the one-line comic-render appendix (see Part VII file 03).

**Per-panel action.** One sentence per panel. State the action, the subject, the framing. Reading order is implicit in the order you write the sentences. "Panel 1: [action]. Panel 2: [action]." not "There are six panels showing various scenes."

**Captions and balloons.** Reserve negative space. Tell the model where text will go later. Tell the model not to generate text. This is the single most-skipped field and the one that produces the most rework.

**Mood.** One sentence. Matches the atmosphere line from the page grid.

**Avoid.** Plain language exclusions. "Avoid superhero stylization" works. Long negative-token strings do not. Be specific.

### Reading order — the load-bearing instruction

If you take one thing from this file, take this: state the reading order in every prompt. Image models do not default to comics reading order. They compose for balance, symmetry, or focal weight. The result is panels that fight the eye.

The fix is one sentence:

> "Compose the page so the reader's eye moves left to right, top to bottom across the panels. Panel 1 is upper-left. Panel [N] is lower-right."

Paste it into every prompt. It is one line. It saves entire pages.

### Negative space for text

Image models do not reliably generate text. Captions, dialogue, and SFX get composited in after generation. That means every panel needs negative space reserved at the prompt stage. State it:

- "Leave clean negative space in the upper-left of Panel 1 for a caption box (~40% panel width)."
- "Reserve lower-right of Panel 4 for a speech balloon (~25% panel area)."
- "No text generation — text will be composited in post."

The third line is critical. Without it, the model will generate gibberish text or fake captions that conflict with the lettering you will add later. State that you do not want text and where the text will live.

## HangarX worked example

**Page 12 splash prompt — The Descent (ACT II opening).**

```
PAGE 12 — ACT II opens. Purpose: deliver the wireframe-consciousness
descent as a single emotional event. The body is gone. Only intent remains.

Layout: 1-panel full-page splash. Thin black border, no gutters. Vertical
page orientation (US comic page ratio).

Style: Photoreal cinematic noir translated into illustrated sequential
art. High contrast chiaroscuro, deep blacks, restrained palette accent.
For this page only: cyan-dominant render. Background deep navy #0A0E1A
filling 80% of the page. Subject rendered as cyan #2FAFC0 wireframe line
work only — no skin tones, no warm light. Editorial grain texture.

Subject: HELIX (Kira "HELIX" Vasquez, 32-year-old mixed Latina/Asian
systems architect, sharp cheekbones, tired intelligent eyes, dark hair
in a messy practical bun). Continuity preserved from film reference.
For this page: rendered as a cyan wireframe consciousness suspended in
mid-fall, body partly translucent, geometry breaking apart at her edges.
Recognizable as HELIX through cheekbone structure and hair silhouette
even in wireframe state. Maintain identical face geometry to film
continuity reference.

Composition: HELIX centered vertically, falling/descending through a
field of broken Layer-1 architecture — colossal corrupted lattice
structures, hanging system ribs, dust motes catching faint amber
backlight. Sense of impossible depth below her. She is the brightest
point on the page; everything else recedes into navy.

Captions: Leave clean negative space in the lower third of the page for
a single caption box (~70% width, two lines of text). No text
generation — caption will be composited in post. Caption text (for
letterer's reference only, do not render): "I used to think the hardest
part was letting go."

Mood: existential rupture rendered as quiet. Awe, not spectacle.
Restrained. The reader should hold the page for ten seconds without
needing more.

Avoid: superhero stylization, glamour lighting, neon palette, fantasy
rendering, speed lines, text generation, multiple panels.
```

Full prompt-pack for selected HangarX pages (covers, ACT II opener, ACT III decision page, ACT IV chamber confrontation, ACT V epilogue) lives in `examples_HangarX/VII_graphic_novel_filled.md`.

## Checklist

- [ ] Every prompt follows the eight-slot skeleton in the same order
- [ ] Style anchor line is identical across all 41 prompts
- [ ] Continuity pack base block is pasted verbatim plus the comic-render append line
- [ ] Reading order sentence appears in every prompt
- [ ] Negative space for captions and balloons is reserved per panel
- [ ] "No text generation" line appears in every prompt
- [ ] Panel count, border thickness, gutter color, and gutter width are stated
- [ ] Avoid line names superhero stylization explicitly

## Common failure modes

- **Treating comics prompts as film-still prompts.** Output is a single image, beautifully composed, that cannot be paginated. Always state panel count, layout, gutters, and borders.
- **Skipping the reading-order instruction.** The model composes for balance, not for left-to-right flow. The reader's eye fights the page.
- **Letting the model generate text.** Captions, balloons, and SFX appear as gibberish or fake Latin. State "no text generation" in every prompt and reserve negative space.
- **Style line varying per page.** Page 4 says "noir." Page 14 says "graphic novel rendering." Page 24 says "stylized comic." The book reads as four books. Lock one style line and paste it unchanged.
- **Continuity base block paraphrased per prompt.** HELIX is a slightly different woman every page. Paste the same ~100-word block verbatim.
- **Negative space not reserved.** The image fills edge to edge with detail and the letterer has nowhere to place captions without covering important visual information.
- **Per-panel action written as a paragraph instead of one sentence per panel.** The model loses the panel structure. Write "Panel 1: ... Panel 2: ... Panel 3: ..." not "In this page we see HELIX entering the chamber, then VALE turning, then..."
