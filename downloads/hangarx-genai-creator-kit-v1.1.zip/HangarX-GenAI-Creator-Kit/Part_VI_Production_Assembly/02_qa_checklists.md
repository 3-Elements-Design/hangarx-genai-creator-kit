# QA Checklists

**Phase 7 · Iterate, assemble, publish**

## Why this matters

A checklist is a tool, not a ritual. The five checklists in this kit catch the failure modes that recur on every GenAI short film: undefined story, drifting continuity, sloppy prompts, slow pacing, broken delivery. Each one is a 40-to-80-item sweep designed to be run at a specific point in the workflow.

The point of running a checklist is not to feel productive. It is to catch the specific class of failure the checklist was designed for, before that failure becomes expensive to fix. Continuity drift caught at the still pass costs an hour. Continuity drift caught at picture lock costs a week of regeneration. Run the checklist when it is cheap.

The order matters. Each checklist assumes the previous ones have passed. Running pacing before continuity wastes time — you cannot judge pace from a cut where the character keeps morphing. Running delivery before pacing is worse — you will publish a slow film with perfect metadata.

## The five checklists

### Story development (`checklists/story_development.md`)

The premise sanity pass. Do you actually have a film, or do you have a mood board with a logline taped to it? Covers premise, protagonist, antagonist, escalation, ending design.

**Run when:** before any worldbuilding. Re-run if the story changes significantly mid-production.

### Continuity QC (`checklists/continuity_qc.md`)

Face, wardrobe, environment, palette, UI. The visual drift sweep. Catches the slow-creep problems that make a GenAI short look like four different films cut together.

**Run when:** after the still pass, before motion generation. Re-run after motion generation, before the cut.

### Prompt QC (`checklists/prompt_qc.md`)

Subject specificity, mood compression, continuity reinforcement, model fit. Catches prompts that look fine in a doc and fail in production.

**Run when:** before every generation batch. Especially before expensive batches.

### Pacing (`checklists/pacing.md`)

Three jobs per clip. Information density. Handoffs. Dead air. The cut-assessment sweep.

**Run when:** before picture lock. Twice if the cut is over five minutes.

### Final delivery (`checklists/final_delivery.md`)

Export settings, audio levels, on-screen text, captions, thumbnail, metadata, archive. The boring sweep that prevents the embarrassing problems.

**Run when:** before publish. Always. No exceptions.

## When to run which checklist

The order is the workflow:

```
Story development     →    before worldbuilding
        ↓
Continuity QC         →    after stills, before motion
        ↓
Prompt QC             →    before every generation batch
        ↓
[generation loop runs here]
        ↓
Continuity QC (again) →    after motion, before cut
        ↓
Pacing                →    before picture lock
        ↓
Final delivery        →    before publish
```

The two Continuity QC passes are not redundant. The first one catches problems in the stills, where regeneration is cheap. The second catches motion-specific drift — characters whose face is fine in a still but morphs across a clip, environments that look right at frame 1 but warp by frame 90.

The Prompt QC pass runs inside the generation loop, not before it. Run it each time you queue a batch. The five-minute checklist saves the hour of regeneration.

## How to actually use a checklist

A checklist that takes forty minutes will not get run. Each of the five is designed to be fast. The pattern:

1. **Open the checklist in a side window.** Do not transcribe items.
2. **Walk it top to bottom.** Tick what passes. Note what fails.
3. **Fix the failures before moving forward.** Do not "come back to it."
4. **If the same item fails three projects in a row, the workflow has a structural problem.** Address the root cause, not just the symptom.

If a checklist item does not apply to your project, mark it `n/a` and move on. Do not pretend it passed.

## HangarX filled example

The HANGAR X production ran the full set. Highlights from the completed reviews:

**Story development:** all items passed after the ending was redesigned in Phase 7. The "premise clear in one sentence" item failed twice early — the rewrites that produced "the end of freedom may not look like oppression. it may look like comfort" came out of that pressure.

**Continuity QC:** HELIX passed face consistency. ECHO failed early — too much spectacle, not enough restraint — and required a reduced-abstraction pass on the continuity pack before regeneration. ATLAS / CRANE needed identity-preservation prompts written specifically for the human-to-system transition.

**Prompt QC:** the ending sequence prompts initially used generic "glitch" language. The checklist flagged it. Rewriting the prompts with film-specific vocabulary ("a millimeter mismatch in the reflection") produced the final image.

**Pacing:** Act I failed the "every clip does atmosphere + information + handoff" item on three clips. All three were rewritten. The four before/after examples in `examples_HangarX/before_after_revisions.md` document the fixes.

**Final delivery:** standard sweep. Caught a 9:16 reframe issue where the title card cropped on Shorts. Fixed before publish.

The full filled checklists are documented in the case study. The point of including them here is that every one of these checklists caught something real. None of them were performative.

## Checklist

- [ ] Story development checklist run before worldbuilding
- [ ] Continuity QC run after stills, before motion
- [ ] Prompt QC run before every generation batch
- [ ] Continuity QC re-run after motion, before cut
- [ ] Pacing run before picture lock
- [ ] Final delivery run before publish
- [ ] Each checklist's failures fixed before moving forward, not deferred
- [ ] Repeat failures across multiple projects flagged for workflow review

## Common failure modes

- **Running a checklist after the work is done.** A checklist is a gate, not a postmortem. If you run it after the cut is locked, you are using it wrong.
- **Treating "mostly passed" as passed.** The point of the checklist is the failed items. Mostly passed means there are unfixed problems.
- **Skipping the second continuity pass.** Motion introduces failure modes that stills cannot show. The second pass is not optional.
- **Skipping pacing because the cut "feels right."** It does not. You are inside the project. Run the list anyway.
- **Treating the checklists as final-stage QA only.** Three of the five run mid-production. They save you from doing the same work twice.
- **Customizing the checklists per project until they stop catching anything.** The checklists are universal failure modes. If you find yourself removing items, you are probably removing the items that would have caught your project's actual problems.
