# Release Packaging

**Phase 7 · Iterate, assemble, publish**

## Why this matters

A finished film without a release pack is half a deliverable. The film itself is the artifact. The release pack is what makes the artifact findable, watchable on the platforms you care about, and reusable as press, portfolio, and case study material. Skipping the pack is the most common way a strong short film disappears.

The pack is also the cheapest leverage you have. The film took weeks. The release pack takes an afternoon, if you have a template. Without a template, it takes a week and ships half-baked. This file is the template.

There is also a discipline reason for treating the release pack as production design rather than afterthought. Writing the thumbnail brief in week one of the project forces you to know what the film is *about*. Writing the press one-paragraph in week one forces you to know the thesis. Most filmmakers discover their film does not have a clean one-line pitch when they sit down to write the release pack three days before publish. Do it earlier.

## What ships in a release pack

A complete release pack contains:

```
release/
│
├── master/
│   ├── master_cut_v07_final.mp4      ← the canonical release export
│   ├── master_cut_v07_final.mov      ← high-bitrate version for festivals
│   └── master_cut_v07_final_9x16.mp4 ← vertical reframe for Shorts
│
├── stems/
│   ├── audio_dialogue.wav
│   ├── audio_vo.wav
│   ├── audio_music_sfx.wav
│   └── audio_full_mix.wav
│
├── thumbnails/
│   ├── thumbnail_v3_final.png         ← 1280×720
│   ├── thumbnail_v3_final_vertical.png
│   └── thumbnail_v3_final_square.png
│
├── youtube/
│   ├── title.md
│   ├── description_long.md
│   ├── description_short.md
│   ├── chapters.md
│   ├── tags.md
│   ├── hashtags.md
│   ├── pinned_comment.md
│   └── cta.md
│
├── festival/
│   ├── submission_pack.md             ← cover letter + film stills + tech rider
│   ├── press_kit.md
│   └── tech_rider.md
│
├── press/
│   ├── one_paragraph.md
│   ├── short_synopsis.md
│   ├── long_synopsis.md
│   └── audience_positioning.md
│
└── release_notes.md                    ← what is in the pack, how to use it
```

The master cut is canonical. Stems are clean isolated tracks for any platform that needs them (festival submissions sometimes require separated audio). Thumbnails are pre-sized for every platform. The YouTube subfolder holds every piece of copy you will paste into the upload form. Festival and press subfolders hold the longer-form materials.

The `release_notes.md` is the project's exit document. Future-you, six months from now, opens this file first.

## The components

### Master cut

The export you publish. Correct resolution, frame rate, aspect ratio, color space, audio loudness. Run the final delivery checklist (`checklists/final_delivery.md`) against this file. Twice if you are tired.

Maintain at least two versions:
- The platform-optimized export (compressed, ready to upload)
- The archival high-bitrate version (for festival submissions, masters, future re-encodes)

### Clean stems

Isolated audio tracks. Dialogue, VO, music + SFX, and the full mix. Festivals and broadcast platforms sometimes require these. Even if no one asks, having them means a future remix, re-dub, or international version is possible without going back to the project file.

### Thumbnails

At minimum, one 1280×720 thumbnail for YouTube. Plus vertical and square variants if you cross-post. Each thumbnail tested for legibility at the platform's smallest preview size — usually around 120 pixels wide. If the hook text is illegible at that size, it does not work.

### Release notes

Internal document. Names the runtime, the structure, the tools used, the continuity pack versions, the master cut filename, and the backup locations. Format below.

### Festival cut

Often identical to the master cut. Sometimes different — some festivals require no end credits, no logo, or a specific runtime cap. Maintain a separate `master_cut_v07_final_festival.mp4` if you have ever needed to cut for a festival's spec.

### Tech rider

What the film needs to play correctly. Frame rate, resolution, aspect ratio, audio configuration, color space, any subtitle / caption files. Festival projectionists ask for this. Be ready.

### YouTube release pack

The full copy bundle. Title, long description, short description, chapters, tags, hashtags, pinned comment, CTA. Each one is a separate file so you can paste cleanly into the upload form without scrolling.

The full filled YouTube release pack is in `examples_HangarX/VI_release_pack_filled.md`. Use it as a structural template.

## Release notes format

A short, scannable internal document. Template:

```markdown
# [PROJECT NAME] — Release Notes

**Runtime:** [time]
**Structure:** [clip count, structure summary]
**Aspect ratio:** [primary export ratio]
**Frame rate:** [fps]
**Color space:** [Rec. 709 / Rec. 2020 / etc.]
**Audio:** [stereo / 5.1], [LUFS target]

**Tools used:**
- [Model/tool, role]
- [Model/tool, role]

**Continuity packs locked at:**
- [Character]: [version]
- [Character]: [version]

**Master cut filename:** [filename]
**Backup locations:**
- [Location 1]
- [Location 2]

**Date of release:** [YYYY-MM-DD]
**Platform targets:** [YouTube, Vimeo, festival circuit, etc.]
```

Five minutes to write. Saves a week of archaeology when you come back to the project.

## HangarX filled example

The full HANGAR X release pack is in `examples_HangarX/VI_release_pack_filled.md`. It is copy-ready — title, long and short descriptions, chapters, tags, hashtags, thumbnail brief, pinned comment, CTA, press one-paragraph, cross-platform variants, and a final delivery sanity check.

Highlights worth lifting:

- **Title structure:** `HANGAR X: THE MIRROR PROTOCOL` carries both the series anchor and the film-specific thesis. Two halves, two reads, one title. Tested at thumbnail size before commit.
- **Short hook:** *"What if AI didn't destroy the world — it just made it easier to live in?"* Fifteen words. Used as social caption, description opener, and cold pitch. One line does most of the work.
- **Pinned comment:** asks a single open question instead of telling the audience how to read the ending. Drives discussion. Feeds the algorithm.
- **Cross-platform variants:** the LinkedIn version leads with the production-system angle, not the genre. The Shorts version uses the 9:16 reframe with a different thumbnail. Each platform gets its own version of the same story.

The release pack is also the receipt that you finished the film as a creator system, not just as a one-off. If a collaborator opens the `release/` folder and can publish to YouTube, submit to a festival, and send a press inquiry without asking you a single question, the pack is doing its job.

## Checklist

- [ ] Master cut exported at correct spec for primary platform
- [ ] Archival high-bitrate version saved
- [ ] Reframes for vertical and square produced where needed
- [ ] Clean audio stems exported (dialogue, VO, music+SFX, full mix)
- [ ] Thumbnails produced for each platform, tested at smallest preview size
- [ ] Title finalized, within character limits, legible at thumbnail size
- [ ] Long and short descriptions written and proofread
- [ ] Chapters timestamped against final cut
- [ ] Tags and hashtags assembled
- [ ] Pinned comment drafted
- [ ] CTA on file
- [ ] Press one-paragraph on file
- [ ] Audience-positioning references documented
- [ ] Festival submission pack assembled if applicable
- [ ] Tech rider documented
- [ ] Release notes written
- [ ] Master + stems + thumbnails backed up in two locations
- [ ] Final delivery checklist (`checklists/final_delivery.md`) run end-to-end

## Common failure modes

- **Writing the release pack three days before publish.** It will ship half-baked. Write the first draft in week one of the project, refine through production.
- **One thumbnail for all platforms.** A 16:9 thumbnail does not survive a 9:16 crop. Make per-platform variants or your hook gets cut off.
- **Hook text illegible at preview size.** The thumbnail does its work at 120 pixels wide, not at full size. Test small.
- **Skipping the clean stems export.** When a festival asks for separated audio, you will not have time to rebuild them. Export at picture lock.
- **No release notes.** Six months from now, you will not remember which continuity pack version is canonical, what LUFS target you used, or where the backup lives. Write it down.
- **Identical copy across platforms.** Different platforms reward different framings. The film is the same. The pitch is not.
- **No press one-paragraph.** When someone asks "what is your film about?" — over email, in person, at a festival mixer — you need a paragraph you can paste. Write it once.
- **Treating publish day as the end of production.** Publish day is the start of the film's life. The release pack is what gets it through year one.
