# Audio as Structure

**Phase 6 · Add audio structure**

## Why this matters

Most GenAI shorts treat audio as a final pass: a music bed, a few sound effects, a VO laid over a finished cut. That sequencing produces films where the audio sits on top of the picture instead of holding it together. When the visuals are model-generated and the cuts are 15-second clip blocks, audio is often the only continuous element across the film. If it is added last, it cannot do structural work.

Audio should be scored to the clip grid before the final picture lock. Every clip handoff is an audio decision: what carries across the cut, what breaks against it, what holds. The audio designer is not decorating — they are bracing the cuts so the film reads as one piece instead of forty.

Silence is part of this. A silent beat after a sound-rich scene is not the absence of audio. It is an audio choice with the same weight as a cue, and it should be scored, marked on the timeline, and protected through QA the same way a music cue would be.

## The framework: four audio layers and the clip handoff

A GenAI short film has four audio layers operating in parallel. Each one has a different relationship to the clip grid.

**1. Motif cues** — Named, recurring sonic elements tied to themes, characters, or world states. These cross clip boundaries on purpose. A motif played in Clip 3 and recalled in Clip 40 is doing structural memory work. See `02_motif_library.md`.

**2. Room tone bed** — The continuous low-level audio fingerprint of a location. Every interior, every exterior, every system-space has its own bed. The bed runs underneath everything else and is the layer the audience never consciously hears — until it stops. See `03_room_tone_and_silence.md`.

**3. VO and dialogue** — The line-by-line performance layer. This is the layer most likely to be over-prompted and under-directed in GenAI films. See `04_vo_direction.md`.

**4. Score** — Music or score-like tonal beds. In a tight psychological piece, score is often the most expendable layer. HANGAR X uses almost no traditional score; the motif library and room tone beds do that work instead.

### How these layers interact with clip handoffs

For every cut between Clip N and Clip N+1, decide what each layer does:

| Layer | Carry across cut | Break at cut | Drop into silence |
|---|---|---|---|
| Motif cue | Common (creates flow) | Rare (jarring) | Use sparingly for punctuation |
| Room tone | Almost never (location change) | Common (new bed) | Used after revelation lines |
| VO | Possible (a single VO can bridge two clips) | Common | Always allowed |
| Score | Common (long arc) | Rare | Use for impact |

The rule of thumb: at least one layer should carry across most cuts, or the film fragments. At dramatic punctuation points, deliberately let *all* layers break.

## HangarX filled example: Clip 40 → Clip 41 silence

Clip 40 ends with HELIX's espresso machine starting before she touches it, a Cortex notification she dismisses, and a soft BWEEE-OOP. Clip 40.1 holds her in the same apartment under a philosophical VO. Clip 41 is the final beat: she lowers the cup, the reflection holds it raised one beat longer, cut to black.

The audio layering across this run:

- **Clip 40 outgoing tail:** soft BWEEE-OOP residual, low room tone bed.
- **Clip 40.1 incoming:** room tone bed continues (same apartment). BWEEE-OOP does NOT carry. VO begins clean against the room tone.
- **Clip 40.1 outgoing:** VO finishes. Room tone holds. A nearly subliminal predictive UI hush sits underneath but is dialed back to near-zero.
- **Clip 41 incoming:** one faint residual Cortex tone or distant BWEEE-OOP. Room tone is dialed almost out.
- **Clip 41 final beat:** absolute silence on cut to black.

That last cut is doing structural work. After 10 minutes of layered ambient infrastructure, the system noise stops. The audience has been listening to a corrected world the entire film without realizing the audio was the proof. Absolute silence on the final cut is the only moment in the film where the system is not present — and it lands as horror, not relief.

If silence on Clip 41 had been a soft fade or a music sting, the ending would feel like a sci-fi twist. As scored, it feels like the system briefly looked away, and then the screen went black.

## Checklist

- [ ] Audio decisions exist for every clip handoff (carry / break / silence)
- [ ] Each scene has an identified room tone bed
- [ ] Motif cues are named and tracked across the timeline
- [ ] Silent beats are scored on the timeline, not "no audio yet"
- [ ] At least one layer carries across most cuts (avoid total fragmentation)
- [ ] At least one moment in the film lets all layers break together
- [ ] VO and dialogue do not sit on top of the picture — they replace something or are replaced by something
- [ ] Final beat audio is explicitly designed, not a default

## Common failure modes

- Treating music as a substitute for structure. A score laid over a fragmented edit covers the seams without strengthening them.
- Adding sound effects per clip without thinking about handoffs. Each clip sounds fine, the film does not.
- "No audio" used as a placeholder. Either silence is a deliberate beat or it is missing work.
- Room tone changing every clip because each clip was sound-designed in isolation. The audience hears the cuts.
- VO recorded last and laid on top of a finished mix. The voice has no acoustic space to live in.
- A single layer (usually score) doing all the structural lifting because the other three were never built out.
- Motifs introduced once and never recalled. A motif used once is a sound effect.
