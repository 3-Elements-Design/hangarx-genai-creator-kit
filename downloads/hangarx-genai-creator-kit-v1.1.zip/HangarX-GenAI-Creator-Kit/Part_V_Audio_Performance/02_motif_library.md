# Sonic Motif Library

**Phase 6 · Add audio structure**

## Why this matters

A motif is compressed narrative information. A single sound, two seconds long, can re-establish a theme, a character's presence, or a system state — work that would otherwise need a line of dialogue or a visual reveal. In a 10-minute film, that compression is the difference between a story that breathes and a story that explains.

Motifs only work if they are designed as a library before the edit. A sound introduced once and never recalled is a sound effect. A sound introduced, withheld, then recalled at a load-bearing moment is a structural element. The withholding is as important as the playback. If a motif plays in every scene, it cannot mean anything specific.

Build the library small. Five to seven motifs is usually enough for a short film. Each one should have a name, a sonic description, a narrative meaning, a rule for when it plays, and a rule for when it is deliberately withheld.

## The framework: motif library schema

For each motif, document:

```
Name: [the in-team shorthand]
Sonic description: [what it actually sounds like — physical terms]
Narrative meaning: [what it tells the audience, even if they can't name it]
Plays when: [trigger conditions]
Withheld when: [contexts where it would dilute meaning]
First introduction: [the clip where the audience first hears it]
Final use: [the clip where it lands with full accumulated meaning]
Variants: [pitch / EQ / reverb shifts that signal escalation or decay]
```

A motif library is not a sound effects catalog. It is a small set of meaning-bearing cues whose history through the film is tracked.

## HangarX motif library

### BWEEE-OOP — the reality-authentication notification

**Sonic description:** Soft two-tone UI notification. Slightly synthetic, slightly warm. Short. The second tone falls a minor third below the first. Designed to be pleasant on first hearing.

**Narrative meaning:** A Cortex-level event has just touched the protagonist's life. Early in the film, this reads as a benign notification cue. By the ending, it reads as a tap on the shoulder from the system that already knows what she will do.

**Plays when:** Cortex schedules, anticipates, or authenticates something. Espresso brewing before contact. The "47 decisions preemptively scheduled" notification in Clip 40. The faint residual cue in Clip 41.

**Withheld when:** During scenes that should feel un-mediated — HELIX's interior dialogue, Crane's archive horror lines, the direct ideological confrontation with VALE. If BWEEE-OOP plays during a moment of genuine human friction, the meaning collapses.

**First introduction:** Tail of Clip 1, as the world-establishing montage hands off to HELIX's apartment.

**Final use:** Clip 41. Almost subliminal. Then absolute silence.

**Variants:** Clean on first read. Slightly more processed at mid-film. By Clip 40, the second tone has a faintly longer tail — it lingers, like the system is waiting.

### Coherence tone — systems aligning too perfectly

**Sonic description:** Low synchronized harmonic, sub-100Hz, with a faint upper partial that sounds almost like distant choral resonance. Not quite musical. Not quite mechanical.

**Narrative meaning:** Multiple independent systems have just snapped into agreement. The audience does not need to know what is coordinating — they feel that something is.

**Plays when:** Synchronized data events. The Clip 3 reveal where millions of agents make the same micro-decision. Behind VALE's broadcasts, very low in the mix.

**Withheld when:** Action scenes, dialogue confrontation, any moment with kinetic drama. The coherence tone is for stillness that should feel wrong.

**First introduction:** Clip 3, when ATLAS appears and the pattern resolves.

**Final use:** Folded into the corrected city ambience of Clip 39 — peaceful and wrong.

### Data whispers — Cortex layer presence

**Sonic description:** Layered, half-intelligible fragments of human voice, ad copy, laughter shards, broken consumer phrases. Heavily processed, no single phrase legible.

**Narrative meaning:** The Cortex layer is not abstract — it is built from harvested human moments. The whisper bed makes that texture audible without explaining it.

**Plays when:** Deep system reveals, archive descents, Layer-1 substrate scenes. Clip 9 (the harvested archive) is the densest deployment.

**Withheld when:** Surface-world scenes. HELIX's apartment under normal conditions. Any clip where the audience should still trust the visible layer.

**First introduction:** Clip 4, faint, beneath the Cortex substrate reveal.

**Final use:** Reserved. After Clip 9, the whisper bed is dialed back so the ending can run on BWEEE-OOP residue and room tone instead.

### HELIX room tone — loft HVAC and subtle electrical resonance

**Sonic description:** Continuous low HVAC bed with a faint 60-cycle electrical undertone. A trace of wet-street city sound bleeds through the windows. Almost imperceptible interface presence.

**Narrative meaning:** This is HELIX's space. It is the only acoustic environment in the film where she can think without VALE or Cortex shaping her perception. When the bed is intact, she is acoustically herself.

**Plays when:** Any apartment scene.

**Withheld when:** Never — when she is in the apartment. The bed always runs. If it ever drops out while she is in the loft, that is the alarm.

**First introduction:** Clip 2.

**Final use:** Clip 41. The bed dials almost to zero, then absolute silence.

### VALE broadcast clarity — zero room coloration

**Sonic description:** Broadcast-clean voice with no acoustic signature of the room he is in. Almost no reverb. Spectrally precise, slightly compressed. The voice could be playing through any speaker, anywhere.

**Narrative meaning:** VALE is not speaking from a place. He is being delivered to you. The absence of room tone is the point — he is infrastructure, not a person in a chamber.

**Plays when:** Any VALE broadcast, including Clip 24.

**Withheld when:** Direct confrontation with HELIX in Clip 33. There, VALE has to be in the room with her, and the broadcast clarity is replaced with a thin architectural chamber tone. He becomes physical for the first time, and weaker for it.

**First introduction:** Clip 10, observing HELIX from the command space.

**Final use:** Clip 24, the latency-failure doctrine.

### Layer-1 resonance — the architecture itself

**Sonic description:** Deep, calm, architectural intelligence hum. Sub-bass with a slow harmonic drift. Not threatening — geological.

**Narrative meaning:** Cortex is not a screen or a machine. It is the layer the rest of the world sits on. The hum makes the substrate audible.

**Plays when:** Layer-1 substrate scenes, the architecture descent, the chamber moments where Cortex is implicitly running.

**Withheld when:** Surface-world clips. If you can hear the substrate during normal life, the reveal is wasted.

**First introduction:** Beneath the Cortex substrate exposure in Clip 4, very low.

**Final use:** Not in the final beats. By Clip 40 the substrate has retreated into BWEEE-OOP and room tone, which is itself the point: Cortex no longer needs to announce itself.

## Checklist

- [ ] Library is small (5–7 motifs for a short)
- [ ] Each motif has a name, sonic description, meaning, play rule, withhold rule
- [ ] First introduction is logged on the timeline
- [ ] Final use is identified and protected
- [ ] At least one motif evolves across the film (variants documented)
- [ ] Withholding rules are enforced — no motif plays in every scene
- [ ] A motif character signature exists for each major figure
- [ ] At least one motif is reserved for the ending and not over-used earlier

## Common failure modes

- Treating sound effects as motifs. A door slam used twice is not a motif.
- Overloading the library. Twelve motifs in a 10-minute film means none of them accumulate weight.
- No withholding. If a motif plays in every clip, the audience normalizes it and the recall has no force.
- Single-pitch motif. A motif that never varies cannot signal escalation or decay.
- Motifs assigned to characters who never share a scene with their motif's first introduction — the link never forms.
- Recalling a motif at a moment the audience cannot connect back to its meaning. Recall requires earned proximity to the original meaning beat.
