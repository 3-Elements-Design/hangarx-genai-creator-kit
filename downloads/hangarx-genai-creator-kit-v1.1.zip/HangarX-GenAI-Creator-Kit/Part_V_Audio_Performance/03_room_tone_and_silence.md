# Room Tone and Silence

**Phase 6 · Add audio structure**

## Why this matters

Every scene has a sound, even when nothing is happening in it. That continuous low-level audio fingerprint — HVAC, distant traffic, electrical resonance, building hum — is the room tone bed. It is the layer the audience never consciously hears. It is also the layer that does the most to make a GenAI short feel like a film and not a slideshow of generated clips.

Room tone is the audio equivalent of a continuity pack. If the bed changes every cut, the audience hears the cuts. If the bed holds across a sequence, the cuts disappear into one location. When the bed deliberately drops, the audience registers it as a beat even if they cannot say why.

Silence after a sound-rich scene is not the absence of audio. It is a designed beat. A soft transition asks the audience to relax. A hard cut to silence asks them to lean forward. Films built on quiet dread — which most GenAI psychological thrillers want to be — depend on the second behavior.

## The framework: room tone as continuity

### One bed per location

Every distinct environment gets its own room tone bed, documented in the audio bible:

```
Location: [name]
Bed components: [HVAC, electrical, traffic bleed, etc.]
Spectral character: [low-heavy, mid-presence, etc.]
Loudness floor: [dB level relative to dialogue]
Variants: [day / night / system-active / system-quiet]
```

If two clips are in the same location, they share the bed. If a clip moves between locations within itself, the bed crossfades on the action that motivates the change.

### The continuity rule

If you can't hear the room when nobody's talking, you have a continuity bug.

GenAI-generated picture often arrives with no native audio, or with stock generic ambience. The temptation is to drop the audio entirely between dialogue lines. That produces clips that read as fragments rather than scenes. The fix is to record or assemble a clean room tone bed for each location and run it underneath everything else in that location.

### The silence rule

Silence is a beat. Score it. Mark it on the timeline. Protect it through QA. The two operative questions:

1. **Where in the film is silence allowed?** Usually: after a revelation line, before a major turn, at the final cut.
2. **What kind of silence?** A bed-drop (room tone fades, no other audio) is different from absolute silence (every layer zero). They land differently.

A bed-drop is uncomfortable but oriented — the audience still locates themselves in the scene because something might come back. Absolute silence is disorienting and feels like the film itself has paused. Use absolute silence rarely; use it last.

## HangarX filled example: Clip 40.1 → Clip 41

The ending sequence uses room tone and silence as the primary structural devices.

**Clip 40.1 — broadcast-clean Vale interlude is over; HELIX VO over apartment hold.**
The bed is the HELIX room tone (loft HVAC, faint electrical resonance, trace city bleed). Underneath the VO sits a "nearly subliminal predictive UI hush" — a system ambience that should not be there, but is. The bed is doing two things at once: it is acoustically her space (familiar), and it has a foreign presence in the low end (wrong). The mix never names this for the audience. The audience feels it as a slight wrongness in the calm.

**Clip 41 — the apartment hold continues, reflection mismatch, cut to black.**
The bed dials almost to zero. One faint residual Cortex tone or distant BWEEE-OOP sits in the otherwise empty space. The visual mismatch (the cup holds raised one extra beat in the reflection) lands against this near-empty mix.

Then: absolute silence on the cut to black. Every layer zero. No score sting, no fade, no breath.

Why this works:

- The calm in Clip 40.1 is already wrong because the bed has a foreign presence in it. The audience is being primed for instability.
- Clip 41 strips the bed almost entirely, which on a subconscious level reads as "her space is being removed."
- The reflection mismatch is the visual evidence of the audio's claim.
- Absolute silence on the cut is the only moment in the entire film with zero system presence. The system has briefly looked away — and that is the moment the screen goes black.

If Clip 40.1 had used a clean, untainted apartment bed and Clip 41 had used a soft fade, the ending would read as melancholy. As scored, it reads as ontological horror. The calm is the threat.

## Checklist

- [ ] Every location has a documented room tone bed
- [ ] Bed holds across clips in the same location
- [ ] Bed transitions are motivated by visible action (door open, location change, etc.)
- [ ] Silence beats are explicitly scored, not "no audio yet"
- [ ] At least one revelation line lands against a bed-drop
- [ ] At most one moment uses absolute silence
- [ ] The bed under a scene that should feel wrong contains an audible-but-unnamed foreign element
- [ ] No clip has zero audio underneath the dialogue (unless silence is the beat)

## Common failure modes

- Different room tone every clip because each clip was sound-designed in isolation. The audience hears the cuts.
- Generic stock ambience used in place of a specific bed. Two locations end up sounding identical.
- Dropping the bed to clean up dialogue. Now the dialogue floats in a vacuum and the scene reads as a recording, not a place.
- Treating silence as "the music stops." Real silence means every layer is zero.
- Using absolute silence three or four times. After the second use, the audience expects it and the recall is gone.
- A bed that gets louder when the action gets bigger. The bed should rarely move. If it moves, that is the signal.
- Failing to test the mix at low playback levels. A bed that is too loud reads as ambient drone music; a bed that is too quiet disappears and the continuity collapses.
- The "too clean" calm is not engineered. If the calm at the ending sounds like an audio engineer cleaned it up, the horror evaporates. The wrongness must be in the bed itself.
