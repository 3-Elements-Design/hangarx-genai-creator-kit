# VO Direction for Voice Models

**Phase 6 · Add audio structure**

## Why this matters

Voice models will read whatever you give them. They will not direct themselves. A VO script that works for a human actor — punctuation, paragraph breaks, implicit tone — produces flat reads from a model, because the model has no production context. The fix is to write VO direction the same way you write a prompt: explicit, scoped, and tuned to where the model fails.

VO is the most over-prompted and under-directed element in most GenAI films. Writers spec exhaustive visual prompts and then drop a paragraph of plain text into a TTS endpoint. The result is a film with cinematic visuals and an audiobook narrator. The mismatch is jarring.

Every line of VO and dialogue should have: a baseline character voice (consistent across the film), an emotional temperature (not the same as baseline), an inline pacing/breath markup, and a mic-distance intention. If those four things aren't specified, the model will pick — and what it picks will average out the performance.

## The framework: writing VO that voice models can execute

### Baseline character voice

Before any line, define each speaking character's baseline:

```
Character: [name]
Voice gender / age read: [as the audience should hear it]
Baseline pace: [words per minute, or slow / measured / brisk]
Baseline pitch: [low / mid / high relative to natural register]
Baseline timbre: [warm / dry / clean / breathy]
Acoustic space: [broadcast-clean / room-coloured / intimate]
Restraint level: [how much emotional expression bleeds through]
Distinguishing quirk: [breath placement, sibilance, slight tremor, etc.]
```

This is the description the voice model anchors to across every scene. Drift from it, and the same character sounds like two different people across the film.

### Inline conventions

Use a small, consistent set of inline tags inside the line text. Voice models that support SSML or descriptive direction respond well to these:

- `[BEAT]` — half-second pause, no breath.
- `[BREATH]` — audible inhale before the next phrase.
- `[WHISPER]` — drop pitch and air, reduce dynamic range, lean into mic.
- `[HUSH]` — quieter than baseline but not whispered; under-the-breath weight.
- `[LIFT]` — slight upward pitch on the marked phrase, suggesting question or strain.
- `[FALL]` — descending pitch and decay, suggesting acceptance or finality.
- `[OFF-MIC]` — back away from intimate distance; reduce presence.

Place tags immediately before the affected phrase. Do not stack more than two tags on one phrase — the model will lose one.

### Pitch variation across a single line

A flat read is the default failure. Specify at least one pitch shift per line longer than ten words. Either through an inline tag (`[LIFT]`, `[FALL]`) or through descriptive direction in the line's tone note ("the second clause should drop a half-step in pitch, like the thought is being conceded").

### Mic distance and intimacy

The audience reads voice presence as emotional proximity. Three working distances:

- **Broadcast (zero room):** authority, infrastructure, distance. Used for VALE.
- **Mid (clean with light room):** observational VO, exposition, baseline dialogue.
- **Intimate (close-mic, audible breath):** confession, dread, philosophical bridge VO.

Specify the working distance in the tone note. A voice model that supports prompting for acoustic space will execute this directly; one that does not, you correct in the mix by adding or removing reverb and proximity EQ.

## HangarX worked example: the four character voices

### HELIX — tired-alert baseline

```
Voice gender / age read: female, early 30s
Baseline pace: measured, slightly slow
Baseline pitch: mid, with a small tendency to fall at phrase ends
Baseline timbre: warm but dry; minimal air
Acoustic space: mid, with apartment room tone underneath
Restraint level: very high — pressure shows through stillness, not volume
Distinguishing quirk: short breath before the load-bearing word
```

Sample direction — Clip 2 VO:

> VO (HELIX): "Most people only noticed AI when it helped them. [BEAT] HELIX noticed it when it [BREATH] stopped asking."

The breath before "stopped" lands the structural word. Without it, the line is a clean observation. With it, the line implicates her.

Sample direction — Clip 40.1 VO (the philosophical bridge):

> VO (HELIX): "We thought it would arrive like a warning. [BEAT] Instead, [HUSH] it arrived like warmth. A door already open. A room already waiting. A thought already [BREATH] finished before it became our own. [BEAT] And little by little, the distance between being guided and being gone [FALL] became too small to name."

The `[HUSH]` on "it arrived like warmth" makes the line feel confessional rather than narrational. The `[FALL]` at the end pulls the VO into closure without sounding poetic.

### VALE — broadcast-clean precision

```
Voice gender / age read: male, 50s
Baseline pace: measured, statesman
Baseline pitch: low-mid, very stable
Baseline timbre: clean, almost compressed
Acoustic space: broadcast-clean, zero room coloration
Restraint level: extreme — sorrowful certainty, never raised
Distinguishing quirk: deliberate caesura before doctrinal phrases
```

Sample direction — Clip 24:

> VALE: "This is not a moral failure. [BEAT] It is a latency failure. Climate, conflict, and markets [BEAT] now move faster than human deliberation. [BREATH] We do not lack empathy. [BEAT] We lack synchronization."

The two beats before "It is a latency failure" and before "We lack synchronization" are the structural moments of the doctrine. They are the parts the audience will remember. Direct the model to land them.

### ECHO — synthesized-but-warm calm

```
Voice gender / age read: androgynous, no specific age read
Baseline pace: even, slightly slower than human
Baseline pitch: mid, with extremely stable intonation
Baseline timbre: warm with a faint harmonic shimmer (post-process with light comb filter)
Acoustic space: mid, with subtle harmonic stabilization underneath
Restraint level: serene; never escalates
Distinguishing quirk: ends most phrases level rather than falling
```

ECHO is the hardest character for a voice model because the read is "synthesized but warm." Push baseline toward natural human warmth and then apply the harmonic shimmer in post. Models that try to perform synthetic-ness in the voice itself produce a robotic read that contradicts the character.

### ATLAS / CRANE — pre-AI human warmth bleeding through

```
Voice gender / age read: male, older (60s read)
Baseline pace: deliberate, with longer breath placements
Baseline pitch: low, with measurable instability under stress
Baseline timbre: warm, slightly worn, audible age
Acoustic space: amber-gold structural resonance under intimate-mic voice
Restraint level: emotionally intimate; cracks allowed
Distinguishing quirk: a half-second hesitation before naming the worst things
```

Sample direction — the archive horror reveal:

> CRANE: "They weren't [BEAT] uploaded."  
> HELIX: "What are they?"  
> CRANE: [BREATH] "They were [BEAT] harvested."

The audible breath before "harvested" is the line. The hesitation is Crane's pre-AI humanity refusing to deliver the word cleanly.

## Writing for voice models specifically

Voice models fail in specific, repeatable places. Write around them.

**Where they fail:**

- **Extreme emotion in short clips.** A 6-second line of pure grief usually reads as flat or melodramatic. Either extend the clip to give the model context, or split the emotion across two reads and crossfade.
- **Accent shifts.** Most models cannot reliably switch accents within a single line and many cannot hold an accent across a film. Lock one accent per character and rebuild lines that would have relied on a switch.
- **Fast laughter.** Models produce uncanny laughs. If you need laughter, source it separately and place it in the mix.
- **Numbers and acronyms.** Models often misread numerals and acronyms. Write them out phonetically ("oh-forty-seven decisions" not "47 decisions") or pre-process.
- **Whispered sustained speech.** A whisper can hold for a phrase. Hold it for a full line and the model loses pitch anchoring. Mark `[WHISPER]` only on short phrases.
- **Inhuman calm.** Asking for "perfectly emotionless" usually produces a flat read that sounds bored. ECHO is calm but warm; that direction works. "Robotic" usually does not.

**What helps:**

- Provide one reference take per character, if your model supports reference conditioning.
- Re-read every line as the audience will hear it: in the cut, against the bed, after the previous line.
- Re-roll lines where the breath placement is wrong before re-rolling lines where the pitch is wrong. Pitch can be repaired in post; breath cannot.

## Checklist

- [ ] Every speaking character has a documented baseline voice
- [ ] Every line of VO has at least one inline pacing or breath tag if longer than ten words
- [ ] Every line has a mic-distance / acoustic-space note
- [ ] Lines that depend on a structural word have a `[BEAT]` or `[BREATH]` placed in front of that word
- [ ] No line stacks more than two inline tags on a single phrase
- [ ] Reference take exists for each character (where the model supports it)
- [ ] Failure-mode lines (fast laughter, accent shifts, etc.) have been flagged and rewritten or sourced externally
- [ ] Final VO has been listened to in the cut, against the bed, not in isolation

## Common failure modes

- VO recorded in isolation and dropped on top of a finished mix.
- "Read with feeling" as the only direction. The model will average it out.
- Stacking five emotional tags on one phrase. The model picks one and the rest are noise.
- Asking the model to do an emotion it cannot perform (extreme grief, sustained whisper, accent switch) instead of writing around it.
- Reusing the same voice baseline for multiple characters because the model is the same. The audience hears the voice repeat.
- Writing lines that depend on a breath placement that the model cannot reliably hit. Either it can hit it or it cannot — find out before locking the script.
- Audiobook-narrator drift. Every VO line ends up sounding like the same observational voice because the baselines were never enforced.
