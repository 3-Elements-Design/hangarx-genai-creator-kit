# Per-Clip Sound Design Template

**Phase 6 · Add audio structure**

## Why this matters

Sound design notes that live in a director's head do not survive the edit. A template forces every clip to declare its foreground, its bed, its motifs, and its handoffs in writing, so the audio designer and editor can work from one source. It also forces the writer to confront which clips have no sound logic at all — those are usually the same clips that have no narrative function and need rewriting.

The template is not a wishlist. It is a contract per clip: this is what this clip sounds like, this is what carries in from the previous clip, this is what hands off to the next.

## The framework: per-clip sound design template

```markdown
## Clip [number] — [shorthand name]

### Foreground
[The events the audience is meant to notice — specific sounds, named.]

### Ambient (room tone bed)
[The continuous bed underneath everything. Reference the named bed from the audio bible.]

### Motif
[Named library cue if present, plus its variant state. Mark "—" if no motif plays.]

### Pre-tail (bleed in from previous clip)
[What audio carries across the cut from the previous clip. Specify duration if it lingers past the cut.]

### Post-tail (bleed out into next clip)
[What audio carries across the cut into the next clip. Specify duration.]

### Silence
[Where and how long. Bed-drop, absolute silence, or none.]

### VO / dialogue
[Lines with inline direction tags. Reference 04_vo_direction.md.]

### Mix notes
[Loudness floor, where the mix duck happens, anything that fights with VO.]
```

## Project-level motif palette

Before clip-by-clip work, paste the project's motif palette at the top of the sound design document so every clip writer has it visible:

```markdown
## Motif palette
- BWEEE-OOP — reality-authentication cue
- Coherence tone — systems aligning too perfectly
- Data whispers — Cortex layer presence
- HELIX room tone — loft HVAC + faint electrical resonance
- VALE broadcast clarity — zero room coloration
- Layer-1 resonance — substrate hum

## Room tone beds
- HELIX loft (day) / HELIX loft (corrected city beyond glass)
- Berlin street (delegated world)
- NeuralCorp chamber
- Archive / Layer-1 substrate
- VALE broadcast space (broadcast-clean, near-zero bed)
```

If a clip's sound design references a motif or bed not on this list, that is a flag — either the palette is incomplete or the clip is introducing something the rest of the film cannot support.

## HangarX worked example: Clip 02 (HELIX apartment dawn)

```markdown
## Clip 02 — HELIX apartment dawn

### Foreground
- HELIX's chair settle as she sits at the workstation (subtle, 1 second in)
- Faint workstation activation cue — short, single tone, not BWEEE-OOP
- Ambient agent stream motion: a sub-audible "movement of air" texture suggesting the room's interfaces are already running
- Window glass acoustic at end of clip — a very soft thermal tick suggesting the building is breathing

### Ambient (room tone bed)
HELIX loft (day) — HVAC bed with faint 60-cycle electrical undertone. Light wet-street bleed through the windows (carries from Clip 01). Loudness floor: -38dB relative to dialogue.

### Motif
BWEEE-OOP motif tail from Clip 01 lands within the first 0.5 seconds of Clip 02, then fades. This is the audience's first explicit handoff between clips via motif. No other motif plays in Clip 02.

### Pre-tail
From Clip 01: city hum, transit tones, and the BWEEE-OOP tail. The city hum thins as the cut lands; the BWEEE-OOP tail crosses the cut explicitly.

### Post-tail
Light HVAC bed and one faint synchronized click hand off into Clip 03. The click is the seed of the coherence tone that arrives in Clip 03.

### Silence
None. The bed runs continuously. A faint 1-second loudness dip happens behind the VO's first phrase to clear space.

### VO / dialogue
VO (HELIX): "Most people only noticed AI when it helped them. [BEAT] HELIX noticed it when it [BREATH] stopped asking."

Mic distance: mid, with apartment room tone underneath. Baseline HELIX voice — measured, slightly slow, warm but dry. The breath before "stopped" is the load-bearing direction.

### Mix notes
- Bed ducks -3dB under VO for the duration of the line, restores within 0.5 seconds
- BWEEE-OOP tail from Clip 01 must not collide with the VO's first word — schedule it to land in the pre-VO half-second
- Window thermal tick at end of clip is the cue for the editor to time the cut to Clip 03
```

This template forces every clip to declare: what the audience hears in the foreground, what continuous bed they hear underneath, which library motifs are touching this clip, what crosses each cut, where silence is, what the VO does, and what the mix has to do to keep all of it coherent.

A clip with empty fields is a clip with no sound design. A clip with a foreground but no bed will float. A clip with a motif but no pre-tail or post-tail wastes the motif's structural potential.

## Checklist

- [ ] Every clip has its own template filled out
- [ ] The motif palette and room tone beds are documented at the project level
- [ ] No clip references a motif or bed that isn't on the project list
- [ ] Pre-tail and post-tail fields are filled for every cut (even if "—" for none)
- [ ] Silence is specified where it occurs, not implied by an empty field
- [ ] VO lines include inline direction tags (see 04_vo_direction.md)
- [ ] Mix notes call out collisions between foreground and VO
- [ ] Every clip's audio decisions have been read end-to-end as a single document before the mix

## Common failure modes

- Filling out the template for the first three clips and skipping the rest. The middle of the film becomes audio mush.
- "Standard ambience" written in the bed field. That is not a bed — it's a placeholder.
- Foreground sounds that the picture does not justify. The audience hears a sound and looks for the cause; if the cause isn't on screen, the mix breaks.
- Pre-tail and post-tail fields ignored. The film fragments at every cut.
- Motifs introduced in the field "ambient" instead of "motif." This dilutes the motif palette.
- Mix notes left for the mix engineer to figure out. The engineer will pick something, and it won't match the film's intent.
- A clip whose template is identical to the previous clip's. Either the clips are interchangeable (a script problem) or the audio has not been thought through.
