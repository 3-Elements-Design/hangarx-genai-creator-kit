# HangarX GenAI Creator Kit

**Version 1.1** · A complete production system for building cinematic GenAI films and graphic novels — packaged from the workflow used on *HANGAR X: The Mirror Protocol*.

---

## What this is

A working playbook for making GenAI short films and graphic novels that hold together. Not a list of prompts. A continuity-controlled, clip-architected, audio-structured production system you can apply end-to-end — from logline to release.

The kit is built around one principle: **a system beats a prompt dump.** Most GenAI film attempts fail not at prompting but at the architecture above it — continuity, clip structure, audio scaffolding, and iteration. This kit gives you the architecture.

Every section pairs a **blank template** you fill in for your own film with a **HANGAR X filled example** so you can see what "done" looks like.

## What's in the kit

The kit is organized into seven Parts, plus shared foundations:

| | |
|---|---|
| `00_Workflow_Overview.md` | The seven-phase concept-to-release arc. |
| `01_Core_Principles.md` | Six rules that govern every decision. |
| `Part_I_Story_Foundations/` | Logline, theme, runtime, emotional arc, ending design. |
| `Part_II_Worldbuilding_Continuity/` | World rules, hidden logic, character continuity packs, visual + audio language. |
| `Part_III_Clip_Architecture/` | The 15-second clip rule, three jobs per clip, the 40-clip grid, escalation curves. |
| `Part_IV_Prompting_System/` | Image, video, voice, and music prompt patterns. Same-beat-different-engine comparisons. |
| `Part_V_Audio_Performance/` | Audio as structure. Motif libraries. Room tone. Silence as a beat. VO direction. |
| `Part_VI_Production_Assembly/` | Folder structure, file naming, QA checklists, iteration loops, release packaging. |
| `Part_VII_Graphic_Novel_Companion/` | The same system applied to comics: page flow, panel grids, lettering, cross-medium continuity. |
| `examples_HangarX/` | The full HANGAR X reference implementation — every Part filled out for one film. |
| `checklists/` | Five short, sharp checklists you actually use during production. |

## How to use it

You can read this kit linearly — it's structured as a concept-to-release arc — but most filmmakers don't. Three working modes:

**Reference mode.** Skim the HangarX examples in `examples_HangarX/` first to see the finished system, then come back to the blank templates when you need them. Fastest path to understanding.

**Worksheet mode.** Open a fresh project folder. Walk through Parts I → VII in order, filling in the blank templates as you go. By the time you reach Part VI, you have a finished production plan and most of the assets you need to start generating.

**Surgical mode.** You already have a film in flight and one specific thing isn't working. Jump to the relevant Part (audio is structural drift? → Part V. Characters look like different people clip-to-clip? → Part II). Apply only what you need.

## What this isn't

Not model-specific. The kit references the tools used on HangarX (Seedance for video, GPT Image for stills, ElevenLabs for voice, Suno/Udio for music) but the **patterns** transfer to whatever stack you have. Swap engines; the architecture stays.

Not a magic-prompt list. The prompts in `Part_IV` are scaffolding, not incantations. The system is what makes them work.

Not finished. Treat this as v1.0 — fork it, change it, write your own conventions on top.

## Companion materials

The full reference implementation is available outside this kit:

- **The HANGAR X short film** — 10 minutes, 40×15s clips, the GenAI production this kit documents.
- **The HANGAR X graphic novel** — 41 pages, the same world adapted to comics, used as the worked example in Part VII.

---

*"Most GenAI film tutorials hand you a list of prompts and wish you luck. This kit hands you the architecture."*
