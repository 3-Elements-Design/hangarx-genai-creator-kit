# Continuity QC Checklist

**Run before:** writing prompts for any clip beyond the first three.

Continuity drift is the single most common failure in GenAI shorts. Faces change. Wardrobes shift. UI palettes wander. A clip that looks great in isolation falls apart in sequence. Catch drift on the still pass — fixing it after motion generation is expensive.

## Character identity

- [ ] Hero face stays recognizable across every clip the character appears in
- [ ] Age read is stable — no clip makes the character look five years younger or older
- [ ] Posture and presence stay consistent with the continuity pack
- [ ] Eye color, hair shape, and skin tone match across stills and motion
- [ ] Secondary characters are not accidentally morphing toward the protagonist

## Wardrobe

- [ ] Wardrobe progression is logical and intentional
- [ ] No accidental changes — same garment, same color, same wear state
- [ ] End-state look matches the ending design, not a generation default
- [ ] Layers (jacket on, jacket off) tracked across the timeline

## Environment

- [ ] Hero environments are architecturally coherent across clips
- [ ] Windows, doors, and key props occupy the same positions when revisited
- [ ] Time of day reads as intentional, not arbitrary
- [ ] Weather and light direction are consistent within a scene

## Lighting and palette

- [ ] Lighting logic stable — the film's color grammar holds across cuts
- [ ] No sudden golden-hour intrusions in a dawn-blue film
- [ ] Signature interactions (amber UI, cyan exterior) survive every relevant clip
- [ ] Shadow direction and color temperature track from clip to clip

## UI and system language

- [ ] Interface palette stays restrained and consistent
- [ ] Typography in UI matches the world's design language across appearances
- [ ] Glyph and icon vocabulary does not expand mid-film without reason
- [ ] No clip introduces a UI element that contradicts established rules

## Performance and emotional register

- [ ] Characters remain emotionally recognizable across clips
- [ ] Performance tone matches the continuity pack's default mode
- [ ] No clip drops the character into a generic "AI portrait" expression

## Final sweep

- [ ] Stills laid out in sequence, viewed at thumbnail size — no clip jumps out as broken
- [ ] Hero characters compared side-by-side at the same scale
- [ ] Ending stills match opening stills in identity, even after arc-driven changes
