# Final Delivery Checklist

**Run before:** publishing the film anywhere — YouTube, Vimeo, festival submission, portfolio site, internal share.

This is the boring checklist that prevents the embarrassing problems. Wrong export settings. Mismatched aspect ratio. Captions out of sync. Description with a typo in the title. Run it. Twice if you are tired.

## Picture

- [ ] Master cut exported at correct resolution and frame rate
- [ ] Aspect ratio matches platform target (16:9 / 9:16 / 2.39:1 as planned)
- [ ] Color grade survives compression — spot-check at platform's typical bitrate
- [ ] No black frames at head or tail unless intentional
- [ ] Final frame holds for at least one second before fade or cut to black

## Audio

- [ ] Audio levels balanced — dialogue intelligible, motifs present, no clipping
- [ ] Loudness normalized for platform (LUFS target met)
- [ ] No stray mute drops or asymmetric stereo issues
- [ ] Music and SFX licensed and documented where required
- [ ] Audio fades cleanly to silence on final cut

## Text and titles

- [ ] On-screen text legible at smallest expected playback size
- [ ] Title card spelling and punctuation verified
- [ ] End credits accurate — names, tools, models, music credits
- [ ] Captions or subtitles generated and synced if applicable
- [ ] No placeholder text left in the export

## Packaging

- [ ] Thumbnail prepared in correct dimensions for each platform
- [ ] Thumbnail hook text legible at mobile size
- [ ] Description finalized and proofread
- [ ] Title finalized and within platform character limits
- [ ] Upload metadata complete — tags, category, language, visibility

## Release pack

- [ ] Pinned comment drafted and ready to paste
- [ ] Short hook copy ready for cross-posting
- [ ] Hashtags assembled for relevant platforms
- [ ] One-paragraph press synopsis on hand
- [ ] Audience-positioning references ready ("if you like... ")

## Archive

- [ ] Project folder cleaned — no temp files, no dead drafts at the top level
- [ ] Master cut and stems backed up in two locations
- [ ] Continuity pack, prompt pack, and clip grid archived with the master
- [ ] Release pack saved alongside the cut
- [ ] Case-study notes captured while the memory is fresh
