# Pacing Checklist

**Run before:** picture lock. Twice if the cut is over five minutes.

Pacing is the single biggest gap between "a stack of beautiful clips" and "a film." Most GenAI shorts feel slow not because the clips are long but because the clips are not doing all three jobs. This checklist catches drift before you commit to the cut.

## Three jobs, every clip

- [ ] Every clip does atmosphere AND information AND handoff
- [ ] No clip is doing one job in a tuxedo (atmosphere-only)
- [ ] No two adjacent clips share the same atmosphere unless intentional
- [ ] No clip's information repeats the previous clip's

## Information density

- [ ] Something is revealed at least every one to two clips
- [ ] Act I delivers premise + protagonist + first anomaly before the five-minute mark for short films
- [ ] Information is on-screen — not delivered by VO alone
- [ ] No "concept fog" clips that imply something is wrong without naming it

## Momentum and handoffs

- [ ] Audio motifs carry across cuts where appropriate
- [ ] Transitions are emotionally or sonically linked, not just chronological
- [ ] No clip resolves cleanly without a handoff (last clip excepted)
- [ ] Viewer is pulled forward — you can name what makes them lean into the next clip

## Stillness

- [ ] Stillness is intentional, not accidental
- [ ] Silent or low-action beats earn their length by raising tension
- [ ] No three mood-only clips in a row anywhere in the runtime
- [ ] Final beat uses silence as punctuation, not as filler

## Dialogue and VO

- [ ] Dialogue is not too sparse — viewer is not left guessing every reveal
- [ ] Dialogue is not too dense — the visual still carries weight
- [ ] Bridge VO is used where it earns its place, not as a crutch
- [ ] No VO that simply names what the picture already shows

## Sequence-level pass

- [ ] The act escalates — pressure climbs from start to end
- [ ] Revelations land early enough to matter for the rest of the film
- [ ] Mid-film descent is faster than Act I, not slower
- [ ] Ending sequence flows as one idea, not four disconnected beats

## Final pacing pass

- [ ] Dead air cut wherever it adds nothing to tension
- [ ] Repetitive visual beats tightened or removed
- [ ] Discoveries moved earlier where the rewrite supports it
- [ ] You have watched the cut at 1.0× without skipping. It holds.
