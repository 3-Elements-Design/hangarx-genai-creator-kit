# Prompt QC Checklist

**Run before:** every generation pass. Especially before any expensive batch.

A prompt that looks clean in a doc can still fail in production. The point of this checklist is to catch sloppiness before you burn credits. If the prompt is not specific where it matters and quiet where it does not, it is not ready.

## Subject and environment

- [ ] Subject is clearly defined — one main figure, one main intent
- [ ] Environment is specific, not generic ("Berlin loft at dawn," not "cyberpunk city")
- [ ] No accidental two-subject ambiguity (model will split focus)
- [ ] Spatial relationships are stated, not implied

## Realism and mood

- [ ] Realism level is explicit (photoreal, illustrated, stylized — pick one)
- [ ] Mood stated in one or two words, not a paragraph of adjectives
- [ ] Lighting described in concrete terms (dawn-blue, amber spill, cool fluorescent)
- [ ] Camera grammar specified (lens feel, framing, distance)

## Continuity reinforcement

- [ ] Continuity anchors pasted in for any returning character
- [ ] Wardrobe, hair, and face notes match the continuity pack exactly
- [ ] Environment matches established hero-location rules
- [ ] Variant notes only diverge where the scene requires it

## Compression

- [ ] No unnecessary adjective stacking ("cinematic moody atmospheric noir" — pick one)
- [ ] No filler ("a stunning, breathtaking, awe-inspiring shot of...")
- [ ] Prompt fits comfortably in the model's effective attention window
- [ ] You can read the prompt aloud without losing track of its structure

## Model fit

- [ ] Prompt is formatted for the specific model (GPT Image vs Seedance vs other)
- [ ] Seedance prompts use the structured block format (cinematography / subject / action / etc.)
- [ ] GPT Image prompts state continuity rules and avoid motion-only verbs
- [ ] No prompt is using a template from a different model's grammar

## Failure prevention

- [ ] Negative prompts include the specific failure modes seen in earlier passes
- [ ] No reliance on text-on-screen if the model handles typography badly
- [ ] Risky elements (hands, reflections, small UI) flagged for review
- [ ] You know which artifact you are most likely to see — and you are watching for it

## Final pass

- [ ] Prompt name and version match the file-naming rules
- [ ] Prompt is logged in the prompt pack with a date and source clip ID
- [ ] You can answer "what is this prompt trying to do for the film?" in one sentence
