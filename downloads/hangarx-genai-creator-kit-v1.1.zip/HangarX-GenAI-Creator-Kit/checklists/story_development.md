# Story Development Checklist

**Run before:** worldbuilding, continuity packs, or any prompt writing.

If you cannot tick most of these, the problem is not your tools. Stop and fix the story first. Generation will not save an undefined premise.

## Premise and thesis

- [ ] Premise stated in one sentence, out loud, without notes
- [ ] One specific warning, mystery, or thesis the film is built around
- [ ] You can say what the film is *not* about (helps cut scope)
- [ ] "Why this film, why now" answerable in one line

## Protagonist

- [ ] Protagonist makes at least three meaningful decisions across the runtime
- [ ] The protagonist's defining trait is visible in their introduction clip
- [ ] You know what the protagonist wants and what they are willing to lose
- [ ] The protagonist is changed by the ending in a specific, nameable way

## Antagonist or opposing force

- [ ] Antagonist has a coherent worldview, not just an evil position
- [ ] You could write the antagonist's pitch and find it half-convincing
- [ ] The opposition pressures the protagonist's specific weakness, not a generic one
- [ ] No villain theater — the antagonist works as a system thinker, not a monologuer

## Escalation

- [ ] The story escalates across acts — pressure goes up, not sideways
- [ ] Each act ends on a beat that makes the next act necessary
- [ ] No two adjacent acts repeat the same kind of revelation
- [ ] Emotional arc is trackable: name the feeling at five points in the runtime

## Ending

- [ ] Ending is conceptually earned by setups in Act I and II
- [ ] Ending expresses the film's thesis, not a borrowed genre twist
- [ ] You can describe the final image in one sentence
- [ ] The last beat lands on a specific, film-native question — not a generic one

## Sanity pass

- [ ] You would still want to watch this film if a friend pitched it back to you
- [ ] The logline survives translation to a non-genre audience
- [ ] You have cut at least one beloved idea that did not serve the thesis
