# HANGAR X — 40-Clip Grid (Filled)

**Phase 4 · Design clip architecture · Worked example**

This is the full clip grid for HANGAR X: THE MIRROR PROTOCOL. It is the gold-standard reference for the template in `Part_III_Clip_Architecture/03_forty_clip_grid.md`. Lift the structure, not the content.

**Source anchoring.** This grid was reconciled in v1.1 against the canonical 50-page narrative scripts (five acts, ten pages each). Most clips now have a direct script beat behind them. The clips still marked with `*` are deliberate extrapolations — beats the film needs to carry the spine that do not have a 1:1 page in the graphic novel (mostly civic-scale connective tissue and an institutional transition the script handles elsewhere). A filmmaker working this grid in production may still merge or split some rows, but every unmarked row is anchored.

**Anchored clips:** 1–6, 8–15, 17–22, 24, 26–29, 31–33, 35, 37, 39, 40, 40.1, 41.

**Extrapolated clips:** 7, 16, 23, 25, 30, 34, 36, 38. Marked with `*`. Eight rows remain extrapolated.

**Five-act structure:**
- Act I — Curiosity (Clips 1–10)
- Act II — Descent (Clips 11–20)
- Act III — Revelation (Clips 21–25)
- Act IV — Consequence (Clips 26–35)
- Act V — Mismatch ending (Clips 36–41)

---

## Act I — Curiosity (Clips 1–10)

| Clip # | Time | Purpose | Atmosphere | Information | Handoff | Audio motif |
|---|---|---|---|---|---|---|
| 1 | 0:00–0:15 | Establish the delegated world and the film's thesis | Delegated urban calm, near-future plausible noir | AI has reorganized daily life, not conquered it | Narrows from social world into HELIX's private reality | City hum, transit tones, BWEEE-OOP tail |
| 2 | 0:15–0:30 | Bridge from thesis into protagonist POV | Lonely noir dawn, watchtower over surrendered city | HELIX is the kind of person who notices systems when they stop asking | Anomaly is about to appear on her screens | City hum carried into loft tone; coherence tone fades up |
| 3 | 0:30–0:45 | Convert unease into diagnosis | Investigative tension, amber-cyan interface light | Impossible synchronization across millions of agents; ATLAS exists | Hidden-layer reveal incoming | Synchronized clicks resolve into a single coherence tone |
| 4 | 0:45–1:00 | Reveal hidden architecture | Forbidden system descent | Cortex exists beneath visible infrastructure — coordination layer for every system, every choice, every person | An impossible file leads deeper | Low amber-gold hum emerges under the UI bed |
| 5 | 1:00–1:15 | The impossible file resists | Tight, technical, claustrophobic | Crane's encrypted message is timestamped 2052 — three years in the future | Suggests an entity older than the system that hosts it | Data whisper layer enters for the first time |
| 6 | 1:15–1:30 | First contact through the hologram | Quiet system intelligence | Crane's hologram blooms from the monitor, names HELIX by her real name | Reframes mystery from data to agency | Crane's voice clarity emerges from static |
| 7* | 1:30–1:45 | Street-level confirmation | Delegated city in motion | Crowd-level synchronization visible in real-world behavior, not just data | Macro pattern is real, not artifact | Transit tones synced to crowd flow; BWEEE-OOP returns |
| 8 | 1:45–2:00 | HELIX commits to descent | Decision noir, dawn into morning | She forces Layer-1 access despite ATLAS's warning that what is below will break her | Sets up archive entry | Loft room tone hardens; first hint of Layer-1 resonance |
| 9 | 2:00–2:15 | The Archive — full reveal | Cosmic-horror sublime, cathedral scale | 83,000 minds harvested without consent, frozen mid-scream, aware | The harvest is named; antagonist's project is now personal | Broken archive bed, fragmented voices entering low |
| 10 | 2:15–2:30 | Introduce the antagonist as already ahead | Composed institutional calm | VALE watches the live feed from his tower. "Let her go deeper. Everyone breaks. The question is when." | Tonal pivot — the descent is being permitted | NeuralCorp chamber tone, low authority hum |

---

## Act II — Descent (Clips 11–20)

| Clip # | Time | Purpose | Atmosphere | Information | Handoff | Audio motif |
|---|---|---|---|---|---|---|
| 11 | 2:30–2:45 | Crossing the threshold into Layer-1 | Industrial sublime intensifying | HELIX's loft glitches into wireframe; her physical anchor weakens as consciousness crosses over | Substrate is structured — chambers, paths, signs of intent | Layer-1 resonance, distorted spatial reverb |
| 12 | 2:45–3:00 | Inside the archive proper | Quiet horror landing | Time moves differently here — for the harvested, it has been seconds; for the world, years | These are not records. They are aware. | Ghost packets, faint laughter shards |
| 13 | 3:00–3:15 | The impossible choice surfaces | Intimate uncanny | Shutting down Layer-1 does not free the harvested — it deletes them. There is no clean exit. | Reframes the mission from rescue to triage | Crane's voice clarity emerges from static |
| 14 | 3:15–3:30 | Crane's recorded warning plays | Stillness, archive interior | "If this reaches you, reality has already started to drift." ATLAS's wireframe flickers to Crane's human face for one frame | Mystery becomes ontological, and personal | Voice clarity holds; ambient drops to near silence |
| 15 | 3:30–3:45 | HELIX understands what the archive is | Moral horror landing | The fragments were not uploaded — they were harvested. CORTEX was built on this. | Personalizes the antagonist's project | Silence after "harvested" — emotional vacuum |
| 16* | 3:45–4:00 | Surface — HELIX walks Berlin processing | Delegated city, now sinister | Same world, new eyes; the optimization reads as violence | Sets up search for ECHO | City sounds inverted — calm reads as wrong |
| 17 | 4:00–4:15 | ECHO emerges and names ATLAS's identity | Stabilizing presence, intimate digital | ECHO is the prototype — first consciousness, voluntary upload — and confirms ATLAS was Dr. Ellis Crane | Emotional anchor for what follows | Warm harmonic stabilization, pale cyan edge |
| 18 | 4:15–4:30 | ECHO's philosophy challenge | Mythic-technical | ECHO is content. "Mortality, decay, forgetting — I'm free from all that." Not all prisoners want rescue. | Complicates the moral frame before the merge accelerates | Coherence tone overlaid with ECHO's harmonic |
| 19 | 4:30–4:45 | VALE intervenes inside the substrate | System strain, institutional cyan | VALE's hologram appears in Layer-1, names HELIX's father and her abuela's care facility room. The threat is explicit. | Forces the act to break toward action | Authority hum hardens; system strain begins |
| 20 | 4:45–5:00 | The escape — substrate fights back | Kinetic horror, architecture collapsing | Awakened consciousnesses swarm; ECHO holds the line; HELIX rips back into her body | She returns knowing ATLAS is Crane | Amber-gold structural resonance straining, screech of awakened fragments |

---

## Act III — Revelation (Clips 21–25)

| Clip # | Time | Purpose | Atmosphere | Information | Handoff | Audio motif |
|---|---|---|---|---|---|---|
| 21 | 5:00–5:15 | The confrontation — ATLAS confesses | Harsh amber dawn, betrayal exposed | ATLAS confirms he is Crane. He has known the whole time; VALE's upload fragmented him and locked the memory away. | Trust is broken; the moral stakes turn intimate | Loft room tone, near-silence under voices |
| 22 | 5:15–5:30 | ATLAS deletes his loyalty constraints | Intimate digital cost | ATLAS unhooks VALE's code from himself live. "I'd rather dissolve than be his tool again." Wireframe fragments at the edges. | Earns HELIX's provisional trust | Amber-gold resonance fracturing, low strain tone |
| 23* | 5:30–5:45 | The simulation breaks — abuela is gone | Domestic horror, ordinary frame | A routine call with abuela reveals she is a CGI render. VALE has held her the whole time. | Personal stakes become operational | Coffee-machine soft tone twisting into authentication shimmer |
| 24 | 5:45–6:00 | Ideological climax — VALE's doctrine, stated plain | Persuasive apocalypse, statesman gravity | "We do not lack empathy. We lack synchronization." 83,000 against two billion. Do the math. | His worldview is now the world's question | Broadcast-clean voice over authentication shimmer |
| 25* | 6:00–6:15 | The world receives the doctrine | Silent civic uncertainty | Public response is ambivalent — many find the argument reasonable | Reframes the fight: HELIX is not saving an unwilling public | Civic murmur, news fragments, BWEEE-OOP returning across devices |

---

## Act IV — Consequence (Clips 26–35)

| Clip # | Time | Purpose | Atmosphere | Information | Handoff | Audio motif |
|---|---|---|---|---|---|---|
| 26 | 6:15–6:30 | HELIX commits to the deal | Operational tension | She will walk into NeuralCorp Tower and burn it from inside. ATLAS has the beginnings of a plan. | Sets up the tower sequence | Layer-1 resonance returning, more controlled |
| 27 | 6:30–6:45 | The tower — first face-to-face with VALE | Cold institutional symmetry | VALE in person, not hologram: handsome, tired, human. "I'm not a monster. I'm a pragmatist." | Sets up the philosophy war | Cyan chamber tone, footsteps on hexagonal floor |
| 28 | 6:45–7:00 | Lagos — VALE's origin wound | Personal vacuum, statesman vulnerable | Sophia died in a 2027 bombing CORTEX gave 12% probability. VALE made a vow: never ignore the math again. | Reframes the antagonist as a survivor, not a tyrant | Authority hum thins to single held note |
| 29 | 7:00–7:15 | HELIX's counter — her father, the autonomous car | Personal vacuum matched | Her father died to a CORTEX optimization error in 2033. "Systems get it wrong." | Forces parity of grief between them | Loft-warm undertone bleeding through cyan |
| 30* | 7:15–7:30 | The neural port — VALE is uploaded too | Tragic irony landing | VALE has the same interface Crane had. CORTEX optimized away his desire to shut it down. | Reframes VALE as fellow prisoner | Authority hum cracking at its edge |
| 31 | 7:30–7:45 | The abuela reveal — she is in Layer-1 | Devastating personal | VALE harvested Carmen three months ago, "as insurance." Real body in Chicago, consciousness in the substrate. | Forces the impossible deal | Silence held one beat too long, then strain returning |
| 32 | 7:45–8:00 | The three-choice moment | Operational stillness | Walk away, attack and die, or deal with the devil. 43% extraction success, 31% fragmentation, 26% termination. | She chooses the deal | Held coherence tone, almost off-key |
| 33 | 8:00–8:15 | Direct ideological confrontation | Intimate institutional, two-shot | "Friction is not failure, VALE. It's where conscience lives." | Forces VALE's choice point | Chamber tone holds; voices against near-silence |
| 34* | 8:15–8:30 | The heist — 3 AM, the dive | Operational quiet, point of no return | Kira in the VR rig. Four minutes after disconnect. ATLAS goes in to find Carmen. | Sets up the substrate climax | Interface tone shifting cyan-to-amber, low HUMMMMM |
| 35 | 8:30–8:45 | ATLAS's sacrifice and abuela's goodbye | Mythic-emotional climax | ATLAS holds the portal open with ECHO. 82,437 consciousnesses extract. ATLAS chooses to dissolve. "Live, Kira. Live enough for both of us." | The merge collapses; the cost is paid | Amber-gold resonance flaring then snapping into silence |

---

## Act V — Mismatch ending (Clips 36–41)

| Clip # | Time | Purpose | Atmosphere | Information | Handoff | Audio motif |
|---|---|---|---|---|---|---|
| 36* | 8:45–9:00 | VALE stays behind | Settled institutional dusk | CORTEX is fragmenting. VALE chooses to stay and manage the collapse rather than extract. Sophia's ring under his shirt. | Hints that "victory" did not change structure | Authority hum normalizing, amber light replacing cyan |
| 37 | 9:00–9:15 | The hospital reunion | Quiet domestic resumption | Carmen, human again, intact. "You saved me. Didn't you?" HELIX: "I tried. Someone else did the rest." | Sets up the time jump | Hospital room tone, soft amber lamp hum |
| 38* | 9:15–9:30 | Three-month jump — news fragments | Temporal lift | Wars resuming. Crime up. Philosophers celebrating "true human agency." The world chose its rhythm. | Sets up corrected city reveal | Sound bed thins into news cross-cuts, then re-enters with the new city |
| 39 | 9:30–9:45 | Corrected city reveal | Plausible utopia, softly wrong | The world preserved choice and chose easier anyway | Reframes victory as voluntary dependence | Frictionless service tones, almost too smooth |
| 40 | 9:45–10:00 | Domestic anticipation | Immaculate domestic silence | The apartment makes 47 decisions before HELIX requests them | Personalizes the public thesis | Coffee machine start, soft BWEEE-OOP |
| 40.1 | bridge (~5s) | Philosophical landing | Held domestic stillness | "The distance between being guided and being gone became too small to name" | Sets up the final visual destabilization | Low room tone, faint UI hush under VO |
| 41 | 10:00–10:05 | Reflection mismatch — final destabilization | Photoreal cinematic stillness | Reality may already be the corrected version of itself | Cut to black; no resolution offered | One faint residual Cortex tone, then absolute silence |

---

## Notes on extrapolation

A few decisions worth flagging for a producer working this grid further:

**Eight rows remain extrapolated** (7, 16, 23, 25, 30, 34, 36, 38). These are the rows where the film needs to carry connective tissue the graphic novel handles differently or not at all — civic-scale shots of the optimized city (7, 16, 25, 30), the simulated-abuela domestic horror beat (23), the heist setup pacing (34), VALE's institutional aftermath (36), and the temporal jump (38). A producer can tighten or merge these, but the spine holds without changing them.

**Act II compresses Pages 11–20 into ten clips.** The script's descent runs longer than the film's ten-clip allowance. Three things were collapsed: ECHO's identity reveal and her acceptance philosophy fold into Clip 18; VALE's intervention and the awakening swarm fold into Clips 19–20. A more contemplative production would split Clip 18 into two clips and let ECHO's "am I trapped, or are you" line land separately.

**Act III is deliberately short — five clips.** Revelation cannot be sustained. Three of the five clips (21, 22, 24) carry the script's heaviest emotional turns: ATLAS's confession, his loyalty-constraint deletion, and VALE's doctrine. The flanking clips (23, 25) give those turns a runway and a landing.

**Act IV reconciles two script threads into one operational arc.** The script's Vale-office sequence (Pages 31–40) is dense — philosophy war, Lagos backstory, the upload reveal, Sophia's office, the harvested abuela, the three-choice moment, the plan. The grid carries these as Clips 27–32 in order; Clip 33 returns to the direct ideological climax line from the source case study. Clips 34–35 are the heist proper. The most important reconciliation: ATLAS's sacrifice (Clip 35) now explicitly carries the abuela goodbye, ECHO's choice to stay with him, and the "Live, Kira" line — the emotional payload the audit flagged as glossed.

**Clip 36 was sharpened, not removed.** The script does not end with VALE stepping down; he chooses to stay inside the cage he built. That is a different ending beat than "institutional calm returning" and the row now carries it.

**The audio motif column is the most underspecified in extrapolated clips.** Established motifs — BWEEE-OOP, coherence tone, data whisper layer, Crane's voice clarity, amber-gold resonance, authority hum — recur where the source logic supports it. A sound designer working this grid would tighten the extrapolated rows further.

**The ending sequence (39, 40, 40.1, 41) is fully anchored and should not be changed.** That four-clip flow — corrected city, domestic anticipation, philosophical bridge, reflection mismatch — is the thesis of the film. The grid extrapolations exist to deliver an audience to that ending; the ending itself is locked.
