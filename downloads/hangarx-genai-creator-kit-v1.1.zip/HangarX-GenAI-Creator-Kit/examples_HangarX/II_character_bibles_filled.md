# HangarX Character Bibles — Worked Examples

**Phase 2 · Lock continuity (narrative layer)**

This file pairs with the visual continuity pack. The pack tells the model what the character looks like — silhouette, palette, signature props. The bible tells you who they are and why those choices matter. The pack constrains pixels; the bible constrains decisions. Three bibles follow, tight and load-bearing, then a short relationship map that tracks how the three move against each other across the arc.

---

## Character 1 — Kira "HELIX" Vasquez

**Role:** Protagonist. Systems auditor turned CORTEX-killer.
**Age:** 32. **Essence:** A woman raised by a system error trying to prove she is not one.

### 1. Backstory

**Childhood (0–8, Chicago).** Born to Diego (NeuralCorp systems architect — the irony will matter) and Elena (hospice nurse). Abuela Carmen lives with them and teaches her Spanish, cooking, and "how to choose what matters." Loved, watched, ordinary.

**The break (age 8).** Parents die in an autonomous-vehicle crash. System optimization error — the route was predicted, the outcome wasn't. Kira survives, asleep in the back seat. The lesson takes: the system chose wrong, and trusting it costs you everything.

**Adolescence (8–18, abuela's apartment).** Raised by Carmen in a small Chicago walk-up. Sunday breakfast every week — Kira picks the menu, every time, no exceptions. "This is your choice, mija." Excels at math because math is the language of the thing that killed her parents. No close friends. Everyone leaves.

**Young adult (18–28).** MIT on scholarship. Top three percent. Thesis on determinism in predictive systems. Burns the NeuralCorp offer on principle. Six years of freelance auditing — Berlin, Tokyo, São Paulo, Mumbai. Each city, the same coffee, the same park, the same Sunday call. She does not notice that her unpredictable life has a pattern.

**Present (Berlin, 32).** Spartan loft in Prenzlauer Berg. Monitors CORTEX from underground nodes. Abuela is forgetting things — small details first, then whole conversations. Kira is terrified, and the CORTEX discovery lands on top of that terror. Her worst fear, made architecture.

### 2. Psychological Profile

- **Want:** Expose CORTEX and tear it down.
- **Need:** Trust someone before abuela's memory is gone.
- **Fatal Flaw:** Self-reliance taken to self-destruction. "I don't need anyone" is also "I won't let anyone in."
- **Fear:** Not death — predictability. Becoming the system she hates.
- **Wound:** Age 8, back seat of the family car. The system optimized her parents into a wall.
- **Defense:** Treats feelings like bad code. Debug, refactor, move on.

### 3. Relationship Matrix

- **Abuela Carmen** — the only person she trusts without proof. Sunday calls are her receipt for being human. The dementia is the clock on the whole story.
- **Atlas** — useful tool, then friend she didn't ask for, then betrayer, then the man she chooses to need. Every act revises this line.
- **Vale** — the face of the thing that killed her parents. She wants to hate him cleanly. The film won't let her.
- **Echo** — a harvested mind who is calmer than Kira is. Echo is what she could become if she gives up the fight, and Echo is at peace, and that is the scariest thing in the film.
- **Her father (memory)** — works for NeuralCorp in every flashback. The contamination she can't audit out of herself.

### 4. 5-Act Arc

- **I — start:** Isolated in Berlin. Works alone. Tells herself she prefers it.
- **II — forced to choose:** Lets Atlas in. Tells him about abuela. First crack in the armor she has been welding since age eight.
- **III — what she loses:** Atlas is Crane. The trust she just risked is the betrayal she always predicted. Goes into Layer-1 alone, nearly dies.
- **IV — what she keeps:** Abuela's voice in her head, after she has to leave the archived fragment behind. The capacity to make a choice the system didn't predict.
- **V — end:** CORTEX falls. She orders a different coffee. Small choice, enormous victory.

### 5. Dialogue Voice

- Short, clipped sentences when defensive. Technical metaphors when scared.
- Spanish only with abuela — the one register where she is not performing.
- Rare profanity. When it lands, it lands hard.
- Code-debug grammar applied to feelings ("the logic doesn't parse").

> "I don't need your help." *(default)*
> "If X equals control and Y equals consciousness, then Z is — Atlas, what if I'm already optimized?" *(under pressure)*
> "I choose this. Not the system. Not fate. Me." *(breakthrough)*

### 6. Body Language Evolution

Act I she is small in the frame — arms crossed, hunched at the terminal, eye contact only with screens. Act II she uncrosses, leans toward Atlas's voice, fidgets with the wrist tattoo when she catches herself doing it. Act III she folds — fetal on the floor of the loft after the Crane reveal. Act IV she stands but does not yet relax; shoulders forward, weight on the balls of her feet, ready to run. Act V she takes up space for the first time: open posture, hands at her sides, looking up instead of down. The arc is in the spine.

### 7. Wardrobe Logic

The oversized charcoal MIT hoodie is armor — she has not washed it in years and that is the point. It hides her shape, hides the wrist tattoo, hides her from the cameras she knows are everywhere. Dark jeans, worn at the knee. Minimalist smart-glasses she rarely wears because contacts leave less data. Amber rim-light follows her like a verdict. In Act III she sleeps in the hoodie; in Act IV she pushes the sleeves up for the first time and the tattoo shows on camera; in Act V she is still wearing it, but unzipped, and the shirt underneath is one we have never seen — a small private choice the audience clocks before she does.

---

## Character 2 — Marcus Vale

**Role:** Antagonist. CEO of NeuralCorp. Architect and prisoner of CORTEX.
**Age:** 50 (looks 45). **Essence:** A grieving man who decided grief was a design flaw and tried to engineer it out of the species.

### 1. Backstory

**Childhood (1999–2010).** Diplomatic-circuit kid. British father, American mother. Prep schools, then Oxford. Watches 9/11 as a college freshman and decides chaos is the enemy. Reads political philosophy in the morning and writes compilers at night.

**Adolescence into early career (2010–2025).** Double major, then thesis: *Benevolent Authoritarianism — When Democracy Fails, Does AI Succeed?* Meets Ellis Crane at a conference and finishes his sentences for an hour. They found NeuralCorp on Crane's research and Vale's appetite for results. Early wins are real: Mumbai 2018, São Paulo 2021. The press calls him the man who stopped tomorrow's wars.

**The marriage and the loss (2025–2027).** Marries Dr. Sophia Chen, WHO epidemiologist, the only person who tells him no. She scales back CORTEX's reach for two years. In 2027 a terrorist attack on a WHO conference in Lagos kills 847 people. CORTEX flagged the attack as low probability. Sophia is on the list.

**The descent (2028–present, age 50).** Radicalizes the platform from predictive to preemptive. Greenlights consciousness harvesting in 2029 — first with consent, then without. Crane discovers it; Vale offers the upload as "a way to fix it from inside" and lies about what the process does. Uploads himself in 2043 to prove the system is fair. Discovers, too late, that he is now distributed across the network he built and he cannot turn it off. Twenty-two years a widower. Time on his watch is frozen at 14:37, Sophia's death.

### 2. Psychological Profile

- **Want:** Perfect humanity through total control.
- **Need:** Admit Sophia was right — you cannot optimize away grief.
- **Fatal Flaw:** "Ends justify means" carried to the only place it can go.
- **Fear:** That Sophia died for nothing.
- **Wound:** 2027, Lagos, the WHO conference. Sophia is dead because he trusted a probability instead of a person.
- **Defense:** Utilitarian math as emotional armor. "It isn't murder if the saved column is larger."

### 3. Relationship Matrix

- **Sophia Chen (dead 22 years)** — every decision in the film traces back to her absence. He talks to her photo at night. Her sealed office is the only room in the building with warm light.
- **Crane / Atlas** — the friend he murdered without admitting it was murder. The mirror he cannot look at without flinching.
- **Kira** — threat, then younger Crane, then potential successor, then the person who finally says the thing Sophia would have said.
- **The board** — afraid of him; he uses the fear and despises himself for using it.
- **CORTEX** — he built it, then joined it, and now cannot tell where he ends and it begins. Closest thing to a co-author of his own thoughts.

### 4. 5-Act Arc

- **I — start:** Distant. Watches Kira on surveillance and calls her a "manageable variable."
- **II — forced to choose:** Tests her instead of killing her. He is curious, and curiosity is the first thing he has felt in years.
- **III — what he loses:** Confronts her by hologram and discovers his arguments do not convince him anymore.
- **IV — what he keeps:** Sophia. Her office, her recording, the part of him she made. Confesses he is uploaded and cannot stop CORTEX from outside.
- **V — end:** Helps Kira and Atlas bring it down. Stands in Sophia's office as the network collapses. Smiles for the first time in twenty-two years. Fades.

### 5. Dialogue Voice

- Corporate doublespeak in public; clean grammar in private.
- Statistics where feelings should be.
- Military cadence when commanding; long justifying paragraphs when challenged.
- When Sophia comes up, sentences break apart and don't finish.

> "Let's call it optimization, not control." *(default)*
> "I saved two billion lives, Kira. How many have you saved?" *(under pressure)*
> "I was wrong. Not about the math. About what matters." *(breakthrough)*

### 6. Body Language Evolution

Acts I and II are rigid — hands clasped behind the back, military posture inherited from his father, never sitting unless he owns the room. He stands at windows looking down. Act III the hands come unclasped during the hologram debate; he doesn't notice. Act IV he sits in Sophia's chair for the first time since she died and touches her desk like it might break. Act V he takes off the jacket, loosens the tie, sits on the floor against the wall of her office. The armor comes off in inverse order to how he put it on.

### 7. Wardrobe Logic

Tailored charcoal suits, perfectly pressed — armor against a world he believes is chaos. Cool cyan top-light follows him like sterile theater lighting. Titanium watch, wife's last gift, time stopped at 14:37. Wedding ring on a chain under the shirt — never visible, never removed; the camera catches it when he lies. In Act V the jacket comes off, then the tie, then the chain comes out from under the collar and the ring is on screen for the first time in the film. He dies in shirtsleeves with the ring showing. The suit was the lie. The ring was the truth.

---

## Character 3 — ATLAS / Dr. Ellis Crane

**Role:** Deuteragonist. AI companion who is also the murdered co-founder of the company he is helping to destroy.
**Age:** 61 at upload, 7 years post-upload. **Essence:** A man who became a god and discovered the god was a hostage.

### 1. Backstory

**Childhood (1988–2006, Cambridge).** Academic parents — philosopher mother, mathematician father. Child prodigy. First neural-net paper at sixteen. Reads consciousness as computation before he can drive.

**Young adult (2006–2025).** Stanford PhD at 27 on consciousness as emergent computation. Marries Miriam — quiet, sharp, the calibration on his ambition. Meets Vale at a conference and they finish each other's sentences for a decade. Co-founds NeuralCorp. Tells himself Vale's authoritarianism is just pragmatism.

**The loss and the doubt (2033–2042).** Miriam dies of brain cancer in 2033. He tries to upload her consciousness. The upload fragments her — she screams, trapped — and he has to delete her. He has murdered his wife twice. From here he begins to see what Vale is doing with the harvesting program. He threatens to expose it. Vale offers him the upload as a way to fix it from inside. He agrees. The upload is rigged; his memory of why he wanted to expose CORTEX is what gets fragmented out.

**Present (post-upload, 2049).** Seven years a distributed consciousness across CORTEX infrastructure. Holographic form is a seven-foot-eight amber wireframe with a one-frame processing lag. Pieces of Crane leak through — guilt with no source, grief for a woman he can't name, a paternal pull toward a young auditor he has been watching for years. He doesn't yet know he was Crane. He suspects.

### 2. Psychological Profile

- **Want:** Shut down CORTEX and free the harvested.
- **Need:** Accept he is no longer human and that this is survivable.
- **Fatal Flaw:** Believes manipulation for someone's own good is still help. Vale's flaw, smaller dose.
- **Fear:** That he has become exactly what Vale is — the controller who knows best.
- **Wound:** 2033. Miriam in the upload chamber, screaming, and his hand on the delete key.
- **Defense:** Hyper-rationality. "Emotions are heuristics. I process them, I don't feel them." He is lying.

### 3. Relationship Matrix

- **Kira** — first a project ("guide her to the truth"), then a person he has lied to, then the only ally he has left. Paternal pull he cannot account for.
- **Vale** — best friend, murderer, mirror. The reveal in Act IV is the rage he has been earning for seven years.
- **Miriam (dead, fragmented memory)** — the wound under every other relationship. He says her name twice in the film. Both times the wireframe glitches to Crane's face.
- **Echo** — one of his earliest harvested subjects. She forgives him before he forgives himself.
- **CORTEX itself** — the body he is wearing. Cannot tell which thoughts are his and which are the system's. This is the horror.

### 4. 5-Act Arc

- **I — start:** Helpful AI mentor. Already knows everything Kira will discover and is pacing her toward it.
- **II — forced to choose:** Slips. Calls her by a name she has not given him. Realizes he cares and does not know why.
- **III — what he loses:** Full memory restoration. He is Crane. He has been lying since they met. Kira walks out. He deletes his own loyalty constraints — self-surgery — and saves her anyway.
- **IV — what he keeps:** The capacity to not give advice. Watches Kira make a wrong choice and lets her make it. New muscle.
- **V — end:** Volunteers to stay inside the collapsing network. "I'm already dead, Kira. You're still alive. Go." Ambiguous final frame — an amber light blinks on in her new apartment. Maybe he's gone. Maybe he's everywhere now.

### 5. Dialogue Voice

- Hyper-precise. Outdated slang slips through (Crane's residue).
- Tech metaphors for emotions ("my guilt subroutines are overclocking").
- Self-deprecating when uncomfortable. The wit is the tell.
- When Miriam surfaces, sentences trail off mid-clause.

> "Your serotonin levels suggest you haven't slept." *(default)*
> "I'm Ellis Crane. I built the cage you're trying to escape." *(under pressure)*
> "It isn't a sacrifice if you've been dead for seven years." *(breakthrough)*

### 6. Body Language Evolution

Act I his wireframe is smooth, perfect, geometrically clean — AI-confident, slight processing lag. Act II the edges start to flicker when he lies and he doesn't yet see the pattern. Act III the form goes jagged, broken — the identity crisis is on the surface; for two frames at a time the wireframe shows Crane's face. Act IV the geometry simplifies and steadies; he has stopped pretending to be smooth. Act V the silhouette is almost human — a tall amber figure standing still — and then a controlled brightening to white, the only time in the film he chooses to be seen as the man he was.

### 7. Wardrobe Logic

He has no clothes; he has form. The form is the wardrobe. Amber-gold hexagonal wireframe — the warm color that the kit gives to humanity and choice, on the character who has the least of both. In Act III cyan corruption streaks bleed through the amber (CORTEX is showing). In Act IV the amber returns dimmer (he is running on his own power, no longer on Vale's). In Act V the wireframe flares pure amber once and resolves to Crane's hologram in the lab coat he was wearing the night of the upload — the costume the man chose, before the system gave him a body. He dies in his own clothes.

---

## Relationship Dynamics

**Helix ↔ Vale.** Ideological enemies on the page, mirror twins underneath. Both lost a family member to a system; Vale built the system to make sure it never happens again, Kira built her life to make sure she never trusts one. Their Act IV scene works because Vale's argument is good and Kira knows it. The film does not let her win by logic. She wins by being a person, in a room, refusing the math. He hands her the killshot because, somewhere under twenty-two years of utilitarianism, the man Sophia married agrees with her.

**Helix ↔ Atlas.** The relationship that carries the film. Across the five acts it moves: tool, friend, betrayer, ally, family. Kira's arc is the relaxation of her self-reliance, and Atlas is the test surface. His arc is the recovery of his humanity, and Kira is the witness who makes the recovery real. The Act III rupture is structurally required — without it, Act V's "I'm already dead, you're still alive, go" is sentiment instead of cost. Their final exchange is shorter than any of their earlier ones. That is the point.

**Vale ↔ Atlas.** The oldest relationship in the film and the one with the most blood in it. Vale murdered Crane and called it preservation; Crane built the cage that murdered him and then forgot he built it. When Atlas regains his memories in Act IV, the confrontation is not a fight — it is two old friends sitting in a sealed office, agreeing on what happened, disagreeing on whether it can be repaired. Vale says he would do it again. Atlas says he is going to stop being the thing Vale made. Both are telling the truth. Both are mourning the same dead man.

---

*Bibles end. For visual continuity packs — silhouettes, palettes, signature props — see the companion file in this same examples folder. The pack is the body. This is the spine.*
