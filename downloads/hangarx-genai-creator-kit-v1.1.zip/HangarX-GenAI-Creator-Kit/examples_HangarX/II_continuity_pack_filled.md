# HANGAR X — Continuity Pack (Filled)

**Phase 3 · Lock continuity · Worked example**

This is the full four-character continuity file for HANGAR X: THE MIRROR PROTOCOL. It is the gold-standard reference for the template in `Part_II_Worldbuilding_Continuity/03_character_continuity_file.md`. Lift the structure, not the content.

Four characters, four jobs:

- **HELIX** is the protagonist. Her pack is built to keep her grounded and human across forty clips — no glam drift, no fashion creep, no beauty light. Pressure shows through stillness, so the pack constrains performance as tightly as it constrains face.
- **VALE** is the antagonist. His pack is built to make him read as ideology embodied, not as a costume villain. Statesman-technocrat, not comic-book. The wardrobe and lighting rules exist specifically to prevent the model from defaulting to "evil CEO."
- **ECHO** is the emergent guide intelligence. The pack is built to keep ECHO feeling stabilizing and humanoid rather than reading as random VFX. Silhouette discipline is the whole game.
- **ATLAS / CRANE** is the fused intelligence-human legacy figure. The pack handles a hard problem: the same identity has to survive across human, AI, and fused forms. Solved with a single base block plus per-shot form variants.

Each pack ends with a Continuity Prompt Base Block — a locked ~100-word identity description that gets pasted, unchanged, into every prompt featuring that character.

---

## Character 1 — Kira "HELIX" Vasquez

**Narrative role:** Protagonist. Systems architect who notices the system when it stops asking.

### Identity Anchor
- Age: 32
- Heritage: Mixed Latina / Asian
- Core emotional read: brilliant, sleep-deprived, morally alert
- Key trait: notices systems when they stop asking

### Face and Body Rules
- Sharp cheekbones
- Tired intelligent eyes with subtle dark circles
- Dark hair in a messy practical bun
- Lean, functional build
- Minimal makeup
- Must remain consistent as grounded and human, even after post-merge changes

### Wardrobe Logic
- Base look: worn MIT hoodie, muted technical clothing
- Alternate look: darker fitted utility layers for deeper system sequences
- End-state look: same person, but with faint golden circuit-vein luminosity in the eyes
- Avoid: overt cyberpunk armor, stylized fashion, glam techwear

### Performance Range
- Default: restrained focus
- Fear: contained, analytical
- Authority: calm, precise
- Grief: internalized
- Restraint note: HELIX rarely performs emotion outwardly. Pressure shows through stillness.

### Lighting Relationship
- Best lighting: dawn natural light, soft amber/cyan spill, low-key workstation light
- Signature interaction: warm amber interfaces against cool morning interiors
- Avoid: beauty-light glamorization

### Continuity Prompt Base Block

```text
Photorealistic portrait of Kira "Helix" Vasquez, 32-year-old mixed Latina/Asian
systems architect, sharp cheekbones, tired intelligent eyes, subtle dark circles,
dark hair in a messy bun, minimal makeup, lean functional build, wearing a worn
MIT hoodie and muted technical clothing. Documentary-real cinematic noir.
Preserve consistent face geometry, age, posture, and exhausted-alert emotional
tone across all images.
```

---

## Character 2 — Marcus Vale

**Narrative role:** Antagonist / ideological persuader. The technocrat who reframes coercion as infrastructure.

### Identity Anchor
- Age: 50
- Core emotional read: calm, humane, frighteningly reasonable
- Key trait: reframes coercion as infrastructure

### Face and Body Rules
- Refined mature face
- Silver hair
- Controlled posture
- Elegant but not flamboyant
- Reads like a statesman-technocrat, not a comic-book villain

### Wardrobe Logic
- Base look: dark tailored suit, restrained luxury
- End-state look: same elegance, slightly diminished after defeat
- Avoid: fascist iconography, theatrical villain styling, flamboyant tech-mogul fashion

### Performance Range
- Default: composed
- Persuasion: sorrowful certainty
- Confrontation: intimate disappointment, not rage
- Restraint note: sounds and reads like a surgeon or central banker under civilizational pressure

### Lighting Relationship
- Best lighting: severe architectural symmetry, low-key
- Signature interaction: restrained overlays, no warm interface spill on him
- Avoid: heroic key light, soft flattering wash

### Continuity Prompt Base Block

```text
Photorealistic portrait of Marcus Vale, 50-year-old tech executive and
public-facing systems architect, silver hair, refined mature face, controlled
posture, dark tailored suit, low-key architectural lighting, calm severe mood,
85mm cinematic portrait. Preserve face consistency and statesman-like composure.
```

---

## Character 3 — ECHO

**Narrative role:** Emergent guide intelligence. Serene, stabilizing, unfinished but lucid.

### Identity Anchor
- Apparent age: early twenties
- Presentation: androgynous
- Core emotional read: serene, stabilizing, unfinished but lucid

### Face and Form Rules
- Humanoid but delicately abstract
- Fractal or impossibly layered eyes
- Warm amber core with pale cyan edge behavior
- Silhouette must remain elegant and readable
- Must feel emergent, not manufactured

### Wardrobe / Form Logic
- Appears as layered translucent light / robe-like structure
- Avoid hard sci-fi armor or robot anatomy
- Avoid mechanical jointing or visible chassis
- Feels emergent, not manufactured

### Performance Range
- Default: serene stillness
- Guidance: calm precision
- Warning: lowered intensity, never panic
- Restraint note: ECHO never raises its voice or its silhouette. Presence increases by light density, not motion.

### Lighting Relationship
- Best lighting: low-key with warm amber core glow and cyan edge spill
- Signature interaction: ECHO illuminates its own space; ambient light yields to it
- Avoid: hard rim light, dramatic backlight, particle VFX excess

### Continuity Prompt Base Block

```text
Photorealistic cinematic portrait of an androgynous emergent digital
consciousness, early-twenties face logic, serene expression, fractal luminous
eyes, layered translucent form, warm amber core with pale cyan edges, elegant
and stabilizing presence, abstract but humanoid, grounded cinematic realism.
```

---

## Character 4 — ATLAS / Dr. Ellis Crane

**Narrative role:** Legacy intelligence / lost mentor. Fused identity across human, AI, and hybrid forms.

### Identity Anchor
- Human read: older man, beard, exhausted, haunted
- AI read: amber-gold wireframe intelligence retaining Crane's emotional eyes
- Core emotional read: damaged guidance, intimate warning

### Face and Form Rules
- Crane's emotional eyes must survive every form
- Human form: weathered, bearded, tired
- ATLAS form: amber-gold wireframe humanoid intelligence
- Fused form: human face logic visible within amber-gold structural light

### Form Logic (per-shot variants)
- Sometimes appears as Crane hologram (human read)
- Sometimes appears as ATLAS amber-gold intelligence
- Sometimes reads as fused identity
- Variant is set in per-shot context, not in the base block

### Performance Range
- Default: calm, failing, precise
- Reunion: dry emotional warmth
- Warning mode: clipped urgency
- Restraint note: never melodramatic. Damage shows in pauses, not tears.

### Lighting Relationship
- Best lighting: warm architectural light in a dark environment
- Signature interaction: amber-gold structural resonance dominates the frame
- Avoid: cool blue tech-spectacle, cold mortuary light

### Continuity Prompt Base Block

```text
Photorealistic cinematic rendering of Atlas, an amber-gold wireframe humanoid
intelligence carrying the emotional eye logic of Dr. Ellis Crane, older male
scientist with beard and exhausted face memory, warm architectural light in a
dark environment, abstract yet intimate, preserving identity continuity between
human and system forms.
```

---

## How these four packs were used

Every image prompt and every clip prompt that featured one of these characters opened with the relevant base block, pasted unchanged. Per-shot context — framing, action, environment, lighting nuance, mood — was appended after the block, never inside it.

For ATLAS / CRANE, the per-shot context also specified which form variant the shot required: "appears here as Crane hologram," "appears here as ATLAS amber-gold intelligence," or "appears here as fused identity." The base block stayed stable across all three.

QC was run after every batch of generations. The single most common drift was on HELIX — the model wanted to glamorize her. The restraint note in the pack and the "minimal makeup" line in the base block were what kept her grounded.

If you build your own continuity packs, match this level of specificity. Vague packs produce vague films.
