# HANGAR X: THE MIRROR PROTOCOL - Motif System (filled)

Deep reference. Seven motifs, each with full act-by-act evolution. The Part II file uses five of these inline; this is where the rest live and where the act-by-act tables sit unabridged. Paste from here into prompts.

---

## Motif 1: Coffee cup

- **Theme it carries:** Choice / Optimization
- **First appearance:** Clip 1 - HELIX takes the same chipped white ceramic cup, single 2cm chip on right rim, 2cm from top. The 847th time.
- **Last appearance:** Clip 41 - cafe counter, matcha latte. The cup motif has been replaced by its own evolution. "This matcha latte tastes terrible. Tomorrow, I'll order something else."
- **Visual anchor:** White ceramic, single chip on right rim (2cm from top). Camera holds on hand-hovering-over-cup whenever a real choice is being made. Hexagonal pattern in foam — subtle in Acts I-II, obvious by Act III.
- **Audio anchor:** Soft ceramic-on-counter tone. Absence of BWEEE-OOP notification when she picks it up in Acts I-II — the system does not need to flag predictable behavior.

| Act | Charge | Clip | What happens |
|---|---|---|---|
| I | Comfort | 1 | Perfect, steaming, normal. The routine is invisible. |
| I | First glitch | 6 | Steam moves backward. First reality glitch through the motif. |
| II | Optimization | 14 | She tries to order something different. ATLAS: "You ordered that 4 months ago. It's in your pattern." |
| II | Refilled | 18 | Cup is full and she does not remember filling it. |
| III | Broken | 25 | Cup phases through her hand. Reality is now openly compromised. |
| III | Weapon | 28 | VALE offers her coffee in his office. She refuses. First truly unpredictable choice. |
| IV | Relic | 35 | She finds her own childhood coffee cup in the Archive, harvested as a memory object. |
| IV | Letting go | 39 | She leaves the cup behind. Letting go of the past. |
| V | Replaced | 41 | Matcha latte. Bad. Hers. |

---

## Motif 2: Hexagons

- **Theme it carries:** Order / Chaos (primary), Choice / Optimization (secondary — the architecture of predictability)
- **First appearance:** Clip 1 - hex pattern barely visible in coffee foam. Some background buildings have hex windows.
- **Last appearance:** Clip 41 - zero hexagons in frame. The architecture of control is gone from the world.
- **Visual anchor:** Amber hexagons for CORTEX's intended infrastructure. Cyan hexagons for VALE's corrupted control. Wide shots in Acts I-II include 3-5 background hexagons as a re-reader layer. Hex panel borders during Layer-1 sequences (Act IV).
- **Audio anchor:** Coherence harmonics rise as hex density rises. When the hexagons dissolve in Act V, the coherence tone collapses into ambient room presence.

| Act | Charge | Saturation | What surfaces show it |
|---|---|---|---|
| I | Subtle | 5-10% of background detail | Coffee foam patterns, UI corners, Berlin hex-window architecture |
| II | Noticeable | 20-30% | Monitor screens shift to hex panels; HELIX's loft windows cast hex shadows; ATLAS's wireframe becomes hex-dominant |
| III | Invasive | 50-60% | Tree bark in parks shows hex patterns; human skin pores become hexagonal (body horror); HELIX's mirror reflection has hex-distortion edges |
| IV | Overwhelming | 90-100% | Layer-1 is an entirely hexagonal cathedral-scale honeycomb. Every surface, every consciousness fragment, every beam of light |
| V | Dissolution | 0% by clip 41 | Hexagons break into irregular shards as CORTEX collapses. Final clip: none visible. Freedom restored. |

---

## Motif 3: Mirrors and reflections

- **Theme it carries:** Identity / Function (primary), Memory / Reality (secondary)
- **First appearance:** Clip 6 - HELIX's window reflection is 2 seconds delayed. First sign of desynchronization.
- **Last appearance:** Clip 41 - HELIX's reflection in the cafe window is perfectly synchronized for the first time since clip 1. She is free.
- **Visual anchor:** Real-HELIX lit amber. Reflection-HELIX tinted cyan until Act V. Use reflective surfaces — windows, monitors, polished floors, VALE's glass desk — in roughly 60% of panels. Reflection shots carry a 1-3 frame delay until Act V resolution.
- **Audio anchor:** Subtle frequency shift on each desync beat. Silence when reflections fail to match.

| Act | Charge | Clip | Beat |
|---|---|---|---|
| I | Desync | 6 | Window reflection lags 2 seconds. Blink-and-miss-it. |
| II | Independent | 16 | Bathroom mirror — her reflection blinks separately from her. |
| III | Betrayal | 23 | ATLAS revealed as CRANE — his wireframe reflection in HELIX's monitor shows CRANE's human face. |
| III | Self-loss | 29 | VALE's office floor is polished black marble. He walks across it; his reflection smiles when he does not. He has lost control of himself. |
| IV | Wrong | 38 | Carmen's consciousness appears as a mirror version of herself — younger, but reversed. The reflection is the only thing left. |
| V | Synchronized | 41 | Cafe window. HELIX and reflection move as one. |

---

## Motif 4: Lighting and color psychology

- **Theme it carries:** Humanity / Machine (primary), Connection / Isolation (secondary)
- **First appearance:** Clip 1 - amber rim-light on HELIX from behind/side. Cool cyan spill from the loft window UI.
- **Last appearance:** Clip 41 - pure amber dawn. No cyan in frame. Humanity has won.
- **Visual anchor:** Five-color system locked. Amber `#C79A5A` to `#FFB84D` for humanity, choice, memory. Cyan `#2FAFC0` to `#5FE6FF` for control, surveillance, corporate power. Purple (amber + cyan blended) for transformation, identity crisis, danger. Navy `#0A0E1A` for void, unknown, substrate. Cream `#FEF9E7` for hope, escape, dawn.
- **Audio anchor:** Amber scenes carry warm structural resonance. Cyan scenes carry broadcast-clean clarity and HVAC sterility. Purple scenes blend both into discordance. Navy scenes drop to barely-audible data whispers. Cream scenes are silence with ambient breath.

| Act | Dominant | Used for |
|---|---|---|
| I | Amber, cyan accent | HELIX's loft (amber dawn). Cyan from the loft window UI as the system watches. |
| II | Cyan encroaching | VALE's office (cyan top-light, God-complex framing). NeuralCorp exterior LED strips. CORTEX's corrupted systems. |
| III | Purple | HELIX enters Layer-1 (transition from human to digital). ATLAS during identity reveal (two natures colliding). VALE's breakdown. |
| IV | Navy with cream god-rays | Layer-1's cosmic horror emptiness, lit only by cream god-rays cutting through the Archive — light cutting through horror. |
| V | Amber returns | Pure amber by clip 41. Cyan retreats fully. Cream dawn. |

**Per-character lighting rules.** HELIX: amber rim-light from behind/side, always backlit, always moving forward. Soft fill. VALE: cyan top-light from above, harsh shadows under the eyes. ATLAS: self-luminous internal glow, no external source. Flickers when lying or emotional. Archive scenes: light from everywhere and nowhere, no single source — unnatural.

---

## Motif 5: Panel and frame composition

- **Theme it carries:** Order / Chaos (primary), Choice / Optimization (secondary)
- **First appearance:** Clip 1 - clean 3x2 grid composition, locked 2.39:1 anamorphic frame, 2-3mm equivalent black bar discipline.
- **Last appearance:** Clip 41 - single borderless frame. Composition breaking free of structure entirely.
- **Visual anchor:** Composition evolves with the protagonist's loss of control. Frame rules below.
- **Audio anchor:** Silence used on the most composed frames in Acts I-II and on the most broken frames in Acts III-IV. Sound returns as composition relaxes in Act V.

| Act | Composition language |
|---|---|
| I | Clean grids (3x2, 2x3). Locked horizon. Centered subjects. Order imposed, but HELIX does not know it yet. |
| II | Frames begin overlapping. Edges blur. Some borders fade on one side. Reality becoming uncertain. |
| III | Tilted frames (5-15 degree rotations — disorientation). Broken-glass layouts, shattered irregular shapes. Some elements bleed off frame. |
| IV | Hexagonal frame borders (CORTEX's language has consumed the medium itself). Layered, stacked compositions — sense of depth, falling. |
| V | Return to grids but looser. Irregular sizes. Final clip: single borderless frame. Breaking free of structure. |

**Silent frame strategy.** One silent frame per sequence minimum. Full silent sequences at emotional peaks: clip 6 (reality slips — micro-frame sequence, zero dialogue), clip 9 (Archive reveal — single splash, minimal text), clip 38 (HELIX leaves Carmen's consciousness — five-frame sequence, no words).

---

## Motif 6: Typography and text integration

- **Theme it carries:** Identity / Function (each speaker has a sound-shape on the page), Memory / Reality (UI text is data, dialogue is human)
- **First appearance:** Clip 1 - HELIX's interior monologue in white rounded balloons, black text. CORTEX UI in amber monospace on dark background, hex-framed.
- **Last appearance:** Clip 41 - HELIX's final caption in italic serif, bottom-right. No CORTEX text on screen anywhere.
- **Visual anchor:** Balloon shape and font are character identity made visible.
- **Audio anchor:** Each character's text shape correlates with their voice signature from the audio language doc.

| Speaker | Balloon | Font | Tail | Notes |
|---|---|---|---|---|
| HELIX / humans | White rounded | Standard serif, black text | Curved; jagged when angry | Small text under 8pt when whispering |
| ATLAS / AIs | White squared | Geometric, black text | Angled, not curved | Monospace when giving data |
| VALE | White rounded with 1px cyan outline | Sans-serif, precise | Corporate sharp | The outline is the tell |
| ECHO | Translucent (50% opacity) | Gradient amber to cyan | Fragmenting | Some words trail off — "We were... before... the breaking... oh..." |
| Captions | White rectangles, sharp corners | Italic serif | None | Bottom-right or top-left, never center |

**UI text rules.** CORTEX interfaces: amber monospace on dark, hex-framed. Error messages: cyan bold, chromatic aberration glitch (red/blue offset 2px). VALE's surveillance feeds: small white text top-left, format `SUBJECT: VASQUEZ, K. | THREAT: ESCALATING`.

---

## Motif 7: Visual foreshadowing (the second-read layer)

- **Theme it carries:** Legacy / Responsibility (you are responsible for what you planted), Memory / Reality (the answer was always already in frame)
- **First appearance:** Clip 1 - hex in foam, monitor reads `PATTERN_STABLE`, Carmen photo timestamped exactly 3 years old (same as CRANE's file).
- **Last appearance:** Clip 41 - the cafe window holds long enough for first-read viewers to think it is empty. Second-read viewers see the reflection sync precisely. The film's answer to clip 6.
- **Visual anchor:** Plants are subliminal — 3 frames maximum, never highlighted by camera. Background composed deliberately, never accidentally. Re-readers find the plant; first-read viewers feel it without knowing why.
- **Audio anchor:** Silence on every planted beat. Ambient bed only. The film never tells you "look here."

| Act | Function | Example beats |
|---|---|---|
| I | Planted | Clip 1: hex in foam, `PATTERN_STABLE`, 3-year-old photo. Clip 10: VALE pulls out wedding ring; one of his screens shows Carmen being watched; caption "everyone breaks." |
| II | Half-seen | Clip 7: ATLAS's wireframe glitches to CRANE's face for 3 frames during the holographic interruption. |
| III | Paid out | The wedding ring matters. The Carmen surveillance matters. "Everyone breaks" is about VALE, not HELIX. |
| IV | Confirmed | Every Act I detail is now load-bearing. The photo timestamp was the seed of the whole CORTEX timeline. |
| V | Rewarded | The synchronized reflection in clip 41 is the answer to the 2-second desync in clip 6. The audience does not need to be told. |

**The rule.** A plant should be invisible on first read and inevitable on second. If first-read viewers notice it, it is too loud. If second-read viewers do not notice it, it is too quiet. The hex in the foam is the calibration point — barely there, impossible to unsee once you know.
