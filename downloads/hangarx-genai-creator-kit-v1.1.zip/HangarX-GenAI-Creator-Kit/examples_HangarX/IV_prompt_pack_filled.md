# HANGAR X: The Mirror Protocol — Filled Prompt Pack

A copy-ready prompt pack for the HangarX short film. Five image prompts, five video prompts, three voice prompts, and three music briefs. All four engines aimed at the same world, the same continuity rules, the same realism level.

Use this pack as a reference for your own film, not as content to recycle.

---

## Image Prompts (GPT Image)

### 1. HELIX Hero Continuity

**Purpose:** Primary portrait continuity reference.

```
Create a photorealistic cinematic portrait of Kira "HELIX" Vasquez,
a 32-year-old mixed Latina/Asian systems architect with sharp cheekbones,
tired intelligent eyes, subtle dark circles, dark hair in a messy
practical bun, minimal makeup, and a lean functional build. She wears
a worn MIT hoodie over muted technical clothing. Place her in a
near-future Berlin loft with restrained amber and cyan interface
spill, soft dawn window light, dark concrete surfaces, and
floor-to-ceiling windows. The mood is brilliant, exhausted, isolated,
and alert. Documentary-real cinematic noir, grounded and plausible,
never stylized. Preserve face geometry and age consistency across
all outputs.
```

**Continuity:**
- Keep same face, same age read, same hair structure
- Avoid glamour lighting or stylized cyberpunk exaggeration
- Maintain grounded near-future realism

---

### 2. Vale Broadcast Portrait

**Purpose:** Antagonist continuity / ideological keyframe.

```
Create a photorealistic cinematic portrait of Marcus Vale, a 50-year-old
tech executive with silver hair, refined mature features, calm severe
expression, and controlled posture, wearing a dark tailored suit. Place
him in an elegant glass-walled NeuralCorp broadcast chamber with subtle
architectural lighting, minimal amber/cyan system overlays, and
restrained futurist authority. He should appear humane, intelligent,
and frighteningly reasonable, not villainous. Use 85mm portrait logic,
low-key lighting, cinematic realism, and preserve consistent face and
posture.
```

**Continuity:**
- Statesman-like, not fascistic
- No theatrical villain energy
- Keep architectural control and emotional restraint

---

### 3. ECHO Emergence

**Purpose:** Guide-intelligence reveal.

```
Create a photorealistic cinematic rendering of ECHO, an androgynous
emergent digital consciousness with serene early-twenties face logic,
fractal luminous eyes, layered translucent form, warm amber core, and
pale cyan edge behavior. ECHO appears within a ruined intelligence
substrate and should feel stabilizing rather than threatening. Keep the
form elegant, abstract, and humanoid without looking like a robot.
Cinematic realism, soft volumetric atmosphere, near-future intelligence
architecture, no fantasy styling.
```

**Continuity:**
- Preserve serene face logic
- Maintain warm-amber / pale-cyan identity
- Keep abstraction readable and emotionally grounded

---

### 4. Corrected City Morning

**Purpose:** Epilogue environment keyframe.

```
Create a photorealistic cinematic street-level frame of HELIX walking
through corrected Berlin six months after the crisis. Humans and
synthetic beings move together in seamless harmony. Traffic parts
before congestion, café lighting adjusts before use, delivery drones
arrive before recipients check phones. The city is beautiful, calm,
plausible, and subtly over-optimized rather than overtly dystopian.
Soft natural morning light, desaturated perfection, documentary
realism, faint golden trace in HELIX's eyes, no utopian glamour.
```

**Continuity:**
- Berlin must feel lived-in and real
- Optimization should be visible through behavior, not flashy spectacle
- HELIX must remain recognizably the same person

---

### 5. Reflection Mismatch Final Frame

**Purpose:** Final unsettling image.

```
Create a photorealistic cinematic interior frame of HELIX holding a
coffee cup before the apartment window in soft morning light. The
corrected city beyond the glass is calm, immaculate, and frictionless.
Preserve HELIX continuity exactly. Capture the moment just as she
lowers the cup, but in the window reflection the cup remains raised
for one extra beat, implying a minute continuity mismatch rather than
a glitch effect. Use soft desaturated morning tones, subtle unease,
50–85mm realism, no overt VFX spectacle, and make the image feel
plausible until the discrepancy registers.
```

**Continuity:**
- No hard glitch graphics
- Reflection mismatch must be subtle and believable
- Emotional tone: quiet, destabilizing, final

---

## Video Prompts (Seedance)

### CLIP 1 — The delegated world

```
CLIP 1

[Cinematography]: Rapid cinematic montage of 5–6 establishing shots,
each 2–3 seconds, smooth gimbal actions: aerial descent through drone
traffic, lateral track past climate-control rooms, interior dolly push
toward smart-home interface, handheld follow of synthetic companion
in public space.

[Subject]: The delegated world itself; no central protagonist.

[Action / Transition]: Delivery drones, climate grids, personal agents,
synthetic companions, pedestrians checking phones and accepting AI
suggestions. The world feels reorganized rather than conquered.

[Context]: Realistic European/Asian city architecture, wet pavement
reflections, subtle volumetric haze, calm infrastructure intelligence
everywhere.

[Style & Ambiance]: Photoreal cinematic noir, Blade Runner 2049 realism
with painterly restraint, warm gold #C79A5A, cool cyan #2FAFC0, deep
navy #0A0E1A, pale cream #FEF9E7, anamorphic horizontal flare streaks,
35mm grain, medium haze.

[Dialogue]: VO (female, calm, slightly ominous): "The world did not
end when AI arrived. It delegated itself."

[Audio Design]: Sparse city hum, autonomous transit tones, soft UI
notification chimes, data-stream whispers, final beat of silence
before next clip.

[Duration]: 15 seconds
[Aspect Ratio]: 16:9 cinematic
```

---

### CLIP 3 — The anomaly resolves

```
CLIP 3

[Cinematography]: Continue from Clip 2 with a rack-focus over HELIX's
shoulder into her workstation. Slow push toward translucent interface
layers. End with HELIX reflected in the glass as the pattern resolves.

[Subject]: HELIX at workstation; ATLAS emerging as amber-gold
intelligence within the interface.

[Action / Transition]: Ambient agent streams condense into a synchronized
anomaly: millions of agents make the same micro-decision. HELIX leans
in. ATLAS appears with calm certainty.

[Context]: Berlin industrial loft at dawn, dark concrete walls,
floor-to-ceiling windows, restrained near-future UI.

[Style & Ambiance]: Investigative, precise, photoreal cinematic noir,
amber and cyan contrast under low natural dawn.

[Dialogue]: HELIX: "Why are they all choosing the same path?"
ATLAS: "This isn't a bug. It's coordination."

[Audio Design]: Sparse city hum, HVAC resonance, synchronized clicks,
low coherence tone, slight hush before next reveal.

[Duration]: 15 seconds
[Aspect Ratio]: 16:9 cinematic
```

---

### CLIP 24 — Vale's broadcast

```
CLIP 24

[Cinematography]: Open on the truth from the previous reveal, then cut
to VALE delivering a system-wide broadcast like a statesman addressing
history. Slow symmetrical push-in. Restrained overlays only.

[Subject]: VALE delivering ideological justification for forced merge
and synchronized control.

[Action / Transition]: VALE argues that humanity is not failing morally
but procedurally; climate collapse, war, and markets now exceed human
deliberative speed.

[Context]: Elegant glass-walled NeuralCorp chamber, controlled
authority, subtle system architecture.

[Style & Ambiance]: Persuasive apocalypse. Severe, humane, terrifyingly
reasonable. No villain theater.

[Dialogue]: VALE: "This is not a moral failure. It is a latency failure.
Climate, conflict, and markets now move faster than human deliberation.
We do not lack empathy. We lack synchronization."

[Audio Design]: Broadcast-clean voice, minimal room tone, subtle
reality-authentication shimmer behind him.

[Duration]: 15 seconds
[Aspect Ratio]: 16:9 cinematic
```

---

### CLIP 39 — Corrected city

```
CLIP 39

[Cinematography]: Street-level glide through a calm Berlin morning,
following HELIX through the corrected city with almost too-smooth
camera motion. Let optimization reveal itself through anticipatory
micro-events.

[Subject]: HELIX walking through the corrected city; humans and
synthetic beings in seamless coexistence.

[Action / Transition]: The city feels peaceful, plausible, and deeply
over-optimized. Victory has become atmosphere.

[Context]: Berlin morning, clean infrastructure, responsive cafés,
autonomous transit, subtle service intelligence everywhere.

[Style & Ambiance]: Calm, plausible, frictionless, softly unsettling.
Desaturated morning perfection.

[Dialogue]: VO (HELIX): "We stopped the forced merge. We preserved
choice. And the world chose… easier."

[Audio Design]: Soft city morning, seamless service tones, distant
transit, almost no conflict in the mix.

[Duration]: 15 seconds
[Aspect Ratio]: 16:9 cinematic
```

---

### CLIP 40.1 — Anticipatory apartment

```
CLIP 40.1

[Cinematography]: Hold on HELIX with the coffee in her hand in the
same apartment. Minimal movement or an almost imperceptible drift.
Let tiny environmental adjustments play in-frame: transit estimate
update, subtle light-warm shift, calendar conflict self-resolving.

[Subject]: HELIX suspended inside a life already being arranged for her.

[Action / Transition]: The system continues making small decisions
before she does. The world remains calm, beautiful, and completely
anticipatory.

[Context]: Berlin apartment, corrected city beyond the glass, restrained
Cortex overlays, immaculate domestic stillness.

[Style & Ambiance]: Philosophical warning disguised as comfort. Photoreal
realism, soft desaturated tones, subtle dread inside convenience.

[Dialogue]: VO (HELIX): "We thought it would arrive like a warning.
Instead, it arrived like warmth. A door already open. A room already
waiting. A thought already finished before it became our own. And
little by little, the distance between being guided and being gone
became too small to name."

[Audio Design]: Low room tone, gentle UI hush, almost imperceptible
system ambience under voiceover.

[Duration]: 5 seconds
[Aspect Ratio]: 16:9 cinematic
```

---

### CLIP 41 — The reflection mismatch

```
CLIP 41

[Cinematography]: Hold on HELIX in the apartment after the end of
Clip 40.1. Soft morning light, corrected city beyond glass. Almost
imperceptible slow push-in. Let the shot feel complete for one beat
too long.

[Subject]: HELIX alone, holding the coffee, standing before the window.

[Action / Transition]: HELIX lowers the cup after a sip. In the window
reflection, the cup remains raised for one extra beat before the cut,
as if the reflection belongs to a slightly different version of the
moment. Cut to black immediately after the mismatch registers.

[Context]: Berlin apartment, perfect city beyond glass, no overt
glitching, no explanatory text, no hard VFX event.

[Style & Ambiance]: Photoreal cinematic noir, immaculate realism, soft
desaturated morning tones, continuity slipping by millimeters, subtle
but destabilizing.

[Dialogue]: No dialogue.

[Audio Design]: One faint residual Cortex tone or distant BWEEE-OOP,
almost subliminal. Then absolute silence.

[Duration]: 5 seconds
[Aspect Ratio]: 16:9 cinematic
```

---

## Voice Prompts (ElevenLabs / Resemble)

### Voice 1 — HELIX, Opening bridge (Clip 02)

```
VOICE CAST
- Character: Kira "HELIX" Vasquez
- Age: 32
- Gender / presentation: female
- Accent: neutral North American with faint Berlin inflection
- Timbre: warm-low, slight rasp from fatigue
- Default pace: measured, thinking-out-loud
- Default emotional baseline: brilliant, exhausted, alert
- Reference voice: [HELIX_baseline_v3.wav]

LINE
"Most people only noticed AI when it helped them. [BEAT]
HELIX noticed it [SOFT] when it stopped asking."

DIRECTION
- Emotional state: tired-alert, observational
- Pace: slow, almost talking to herself
- Volume: intimate, just above whisper
- Breath: audible in-breath before "HELIX"
- Mic distance: close
- Room tone: soft loft reverb, dawn quiet
- Restraint: hold back — inside of her head, not a speech
```

---

### Voice 2 — VALE, Broadcast doctrine (Clip 24)

```
VOICE CAST
- Character: Marcus Vale
- Age: 50
- Gender / presentation: male
- Accent: cultivated transatlantic
- Timbre: resonant, controlled, statesman
- Default pace: measured, weight on every clause
- Default emotional baseline: sorrowful certainty
- Reference voice: [VALE_broadcast_v2.wav]

LINE
"This is not a moral failure. [BEAT]
It is a latency failure. [PAUSE]
Climate, conflict, and markets now move faster than human deliberation.
[BEAT] We do not lack empathy. [SOFT] We lack synchronization."

DIRECTION
- Emotional state: humane, reasonable, terrifyingly calm
- Pace: measured statesman cadence, weight on "latency" and "synchronization"
- Volume: conversational-projected, not raised
- Breath: held in-breath before "latency failure"
- Mic distance: close, broadcast-mic intimacy
- Room tone: broadcast-clean, minimal coloration
- Restraint: extreme — Vale never raises his voice

NOTES
Never read as villain. Vale believes every word.
```

---

### Voice 3 — HELIX, Closing bridge (Clip 40.1)

```
VOICE CAST
- Character: Kira "HELIX" Vasquez
- Reference voice: [HELIX_baseline_v3.wav]

LINE
"We thought it would arrive like a warning. [BEAT]
Instead, [SOFT] it arrived like warmth. [PAUSE]
A door already open. [BEAT]
A room already waiting. [BEAT]
A thought already finished before it became our own. [PAUSE]
And little by little, [SOFT] the distance between being guided
and being gone [BEAT] became too small to name."

DIRECTION
- Emotional state: quiet philosophical recognition
- Pace: very slow, ruminative
- Volume: intimate, just above whisper
- Breath: audible in-breath before "Instead" and before "And little by little"
- Mic distance: close, almost interior
- Room tone: dry, no apartment reverb
- Restraint: extreme. Land flat.

NOTES
The last line HELIX speaks in the film. Sounds like someone naming
a thing they have already accepted.
```

---

## Music Briefs (Suno / Udio)

### Cue 1 — Dawn-noir bed (Clip 02)

```
CUE 02 — Dawn-noir bed

PURPOSE
Sit under HELIX's introduction. Establish solitude and intelligence
without telegraphing thriller.

DURATION
~15 seconds, covering Clip 02. Designed to extend under Clip 03 opening.

TEMPO + KEY
~58 BPM, D minor, no time signature pulse.

INSTRUMENTATION
- Low synth pad (warm, slight detune)
- Sub bass (felt, not heard)
- One distant piano note every 4–6 seconds, no melody
- Faint room-tone texture

EMOTIONAL ARC
Quiet observation → faint forward pull → unresolved.

CUE POINTS
- 00:00 — VO begins — pad already present
- 00:08 — "stopped asking" — single piano note on "asking"
- 00:13 — last second — pad thins, sub bass holds

DYNAMICS
Pad at -18dB under VO. Piano notes peak -12dB. No swells.

REFERENCE
Jóhann Jóhannsson, Arrival — "Heptapod B" opening.

EXCLUSIONS
No drums. No melodic phrase. No build. No resolution to major.
```

---

### Cue 2 — The hidden layer (Clip 09 + bridge)

```
CUE 19 — The hidden layer

PURPOSE
Carry HELIX through the revelation that Cortex was built on harvested
consciousness. Escalate without resolving.

DURATION
~28 seconds, covering Clip 09 + bridge into Clip 10.

TEMPO + KEY
~72 BPM emerging from rubato, A minor.

INSTRUMENTATION
- Layered synth pads (cold, harmonically coherent)
- Sub bass with slow upward drift
- Choral texture (wordless, ethical weight)
- One sustained cello note

EMOTIONAL ARC
Suspended dread → moral recognition → harden, do not release.

CUE POINTS
- 00:00 — archive opens — pad and sub already running
- 00:11 — "They weren't uploaded" — choral texture enters
- 00:17 — "They were harvested" — cello note lands; drop to sub only
- 00:20 — three-second silence on sub bass alone
- 00:23 — bridge — pad returns one octave lower

DYNAMICS
Build under dialogue but never cover it. Cello at 00:17 is loudest.

REFERENCE
Mica Levi, Under the Skin — "Lipstick to Void" cue.

EXCLUSIONS
No drums. No tonal resolution. No relief. End colder than it started.
```

---

### Cue 3 — Over-resolved warmth (Clip 40 / 40.1)

```
CUE 40 — Over-resolved warmth

PURPOSE
Underscore the final apartment sequence. The horror is that the music
sounds *right* — warm, clean, gently major — and lands wrong because
the picture is showing surveillance disguised as comfort.

DURATION
~20 seconds, covering Clip 40 through end of Clip 40.1. Drops to
silence at the start of Clip 41.

TEMPO + KEY
~62 BPM, F major (deliberately the wrong key).

INSTRUMENTATION
- Soft piano (clean, no detune)
- Warm string pad (consonant, no tension intervals)
- Faint UI tone (BWEEE-OOP motif, harmonized into the key)

EMOTIONAL ARC
Domestic warmth → settled warmth → too-settled warmth → silence.

CUE POINTS
- 00:00 — espresso machine starts — piano enters
- 00:06 — Cortex notification appears — BWEEE-OOP folds into harmony
- 00:12 — HELIX dismisses notification — piano completes phrase
- 00:18 — VO begins — pad holds, piano fades
- 00:20 — VO ends, cut to Clip 41 — cue drops to silence

DYNAMICS
Soft throughout. The most pleasant music in the film. The drop at
00:20 is total.

REFERENCE
Cliff Martinez, Solaris — "First Sleep" cue, but warmer.

EXCLUSIONS
No minor-key shading. No dissonance. No "this is wrong" signaling.
The wrongness is the absence of wrongness. No fade.
```

---

## How to use this pack

These are the prompts that built the worked example beats of HangarX. Treat them as a reference for how the four-engine quartet looks when the engines agree on intent — not as a library to copy into your own film. The continuity anchors, the world bible, the tonal restraint: those are HangarX's. Your film deserves its own.

The pattern, though, is portable:
- one image prompt per hero continuity asset and per environment keyframe
- one video prompt per 15s (or 5s) beat
- one voice prompt per spoken line, casting locked, line-level direction explicit
- one music brief per cue, written to picture with cue points

Build the four together. The unit is the quartet.
