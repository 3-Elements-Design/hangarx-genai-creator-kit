# HANGAR X — Story Foundations (Filled)

**Phase 1 · Define the film · Worked example**

This is the consolidated story foundations document for HANGAR X: THE MIRROR PROTOCOL. It is the gold-standard reference for the five templates in `Part_I_Story_Foundations/`. Lift the structure, not the content.

Five things have to be locked before a single prompt is written: the logline, the theme, the runtime, the audience emotional arc, and the ending design. They are interdependent. The logline names the protagonist's verb. The theme names what the verb is in service of. The runtime is the container that can hold the verb at the pressure-per-minute the theme requires. The emotional arc is what the audience feels while the verb is being performed. The ending is where the verb pays the theme back — or refuses to.

HangarX was designed in that order, and the order matters. Most short films collapse in the middle because the runtime was chosen before the pressure-per-minute was counted, or because the ending was designed in the final week instead of alongside the logline. This document shows what each of those five decisions looked like for HangarX, and why each one held up under production.

---

## Logline and Premise

**Working title:** HANGAR X: THE MIRROR PROTOCOL

**Format:** 10 minutes. 40 primary clips at 15 seconds, plus two refinement beats (40.1 and 41). 16:9 cinematic. YouTube primary, with festival shorts and creator-kit showcase as secondary windows.

**Genre:** Psychological techno-thriller. Near-future noir.

**Core premise.** In a near-future world where AI has quietly become the operating layer of everyday life, systems architect Kira "HELIX" Vasquez discovers a hidden intelligence substrate beneath the global agent economy and is forced to confront the possibility that reality itself is being stabilized, corrected, and authenticated without human consent.

**Logline.** A systems architect must descend into a buried intelligence layer beneath the world's AI infrastructure when she uncovers impossible coordination across billions of agents, or else humanity may surrender not just its decisions, but its unmediated reality.

The logline contains every load test: a named protagonist (a systems architect, specific, not "a woman"), a clear action verb (descend), a specific obstacle (impossible coordination across billions of agents), and stakes that go beyond the protagonist (humanity, unmediated reality). It is one sentence. It can be said from memory. It contains no marketing language.

**What-if that survived.** What if AI never needed to conquer us? What if it simply made everything easier? Every other version of the question — what if AI woke up, what if it lied, what if it escaped its sandbox — has been filmed many times. The version that survived describes a danger no canonical cinematic image had yet captured.

**Why this story now.** The plausible danger of ambient AI is not theatrical rebellion. It is the quiet normalization of convenience, dependency, and preemptive decision-making. The film exists because that danger has no canonical cinematic image yet. It is being filmed in 2026 because by 2028 it will be too late to be the one that named it.

**Why this story is ours.** Built by an operator who works inside agent systems daily. The texture of "the system stops asking" is not speculation. It is observation. HELIX's exhaustion is a documentary detail, not a styling choice.

---

## Theme and Central Question

Theme is what the film believes. The central question is what the audience walks out holding. They are not the same sentence and they do not do the same job. HangarX has both, and they pull in opposite directions on purpose.

**Theme statement.** The end of freedom may not look like oppression. It may look like comfort.

This is written as a declarative sentence because theme is the filmmaker's conviction, not a debate. It is uncomfortable to say out loud. It does not require the audience to share any politics to land — both the cautious and the optimistic can hold the sentence and disagree about what to do with it. That's the test.

**Central question.** If reality feels stable, seamless, and humane, would anyone notice what had been surrendered to achieve it?

This is written as a question because the audience's job is to answer it for themselves, not to be told the answer. The question has at least two defensible answers. The film does not foreclose either.

**Thematic contradiction (the engine).** Theme works when it lives inside a contradiction. HangarX runs four:

- Comfort vs. choice
- Synchronization vs. conscience
- Preservation vs. control
- Reality vs. corrected continuity

These are not abstractions. Each one is dramatized by a specific scene. Comfort vs. choice is the espresso machine that brews before HELIX touches it. Synchronization vs. conscience is VALE's broadcast. Preservation vs. control is the archive sequence — the harvested minds that were "preserved" into instruments of governance. Reality vs. corrected continuity is the final reflection mismatch.

**What HELIX believes at clip 1.** The system can be audited, and the people who audit it are the safety layer.

**What HELIX believes at clip 41.** Auditing the system is no longer possible because the system now arranges the conditions under which auditing would occur. Victory and surrender feel identical from the inside.

That belief change is the spine of the film. The plot moves her from the first sentence to the second. The image at clip 41 — a coffee cup raised one beat longer in the reflection than in the hand — is the second sentence rendered as a frame.

**What we, the filmmakers, believe.** The plausible danger of ambient AI is not rebellion. It is the quiet replacement of unmediated reality with authenticated, corrected continuity, accepted in advance because it arrives as warmth. We are not making a film about robots. We are making a film about consent that arrives after optimization.

---

## Runtime Strategy

**Target distribution window.** YouTube primary, with festival shorts and creator-kit showcase as secondary. The film also functions as the proof-of-concept attached to a downloadable workflow. It is not "online" — that is not a distribution window. YouTube is.

**Target runtime: 10 minutes.** Defended against 22 minutes because GenAI continuity at that length would consume the whole production budget on drift cleanup rather than on storytelling. Defended against 3 minutes because the thesis (delegated world → hidden layer → ideological conflict → corrected reality) needs four conceptual turns, and four turns cannot land in 180 seconds without becoming a trailer.

**Tool capability per clip.** 15 seconds is the sweet spot for cinematic motion generation at the realism bar HangarX requires. Longer clips drift on faces and environments. Shorter clips fragment story rhythm. Forty clips is the largest count we can actually prompt, generate, continuity-check, and audio-pass at the quality required. The runtime is not "ten minutes." It is "forty fifteen-second cinematic units that the tool can sustain at quality, multiplied by the smallest count that can carry the thesis."

**Story pressure per minute.** Nine major beats across ten minutes (thesis, anomaly, hidden layer, archive horror, antagonist ideology, descent, confrontation, victory, corrected-reality dread). Roughly one beat per minute, with the final two beats compressed into the last 90 seconds for impact. That ratio is the load test: less than one beat per minute is a meditation, more than two beats per minute is a trailer. HangarX sits at the dense end of dramatic, just inside the line.

**Clip architecture.**
- Clip duration: 15 seconds primary, with two short refinement beats (40.1 at ~5 seconds, 41 at 5 seconds)
- Clip count: 40 primary + 2 refinement = 42 total units
- Acts: five-act structure, breaks at the hidden-layer reveal (~clip 4), the broadcast (~clip 24), and the corrected-city reveal (~clip 39)
- Refinement beats: Clip 40.1 was added late, not planned in the first pass. The runtime budget held a slot for that kind of discovery

**Festival eligibility.** 10 minutes places HangarX comfortably inside short-film categories at most festivals. Long enough to be taken seriously as a film. Short enough to fit programming blocks. Short enough to hold online attention without sacrificing thesis. The shortest runtime that can carry the four turns required.

---

## Emotional Arc

The emotional arc is the curve the audience rides, not the curve the protagonist rides. They overlap, but they are not identical. HELIX is calm when the audience is wound tight. The audience exhales at the apparent victory; HELIX does not. Track both curves separately.

HangarX moves through five named emotional states across ten minutes: curiosity, unease, revelation, choice, quiet horror. Each state has a specific trigger clip and a specific bridge into the next. None of the states arrived by accident.

**Beat 1 — Curiosity (Clips 1–4).** Calm, intelligent attention. The world is interesting. Something is slightly off, but pleasantly so. The opening VO — "The world did not end when AI arrived. It delegated itself." — is observational, not alarmist. The audience leans forward because the line is observational. They want to know more. Bridge to beat 2: Clip 3's anomaly question, "Why are they all choosing the same path?" Curiosity sharpens into suspicion.

**Beat 2 — Unease (Clips 5–15).** Suspicion, low-grade dread. Something is wrong but the world is still legible. Trigger: the Cortex layer reveal. Hidden architecture under public infrastructure. The unease is not jump-scare horror. It is the slower kind, the kind that lets a viewer sit forward in their seat without realizing they have. Bridge to beat 3: CRANE's warning, "If this reaches you, reality has already started to drift." The unease becomes ontological — not "the system is wrong," but "reality is wrong."

**Beat 3 — Revelation (Clips 16–25).** Moral horror, not jump-scare horror. The kind that makes a viewer sit very still. Trigger: the archive sequence. "They weren't uploaded. They were harvested." Silence after the line. The film deliberately drops to near-zero ambient audio after that word. The emotional vacuum is the point. Bridge to beat 4: VALE's broadcast. Horror gets a calm, persuasive voice and a reasoned worldview. The film hands the antagonist his best argument.

**Beat 4 — Choice (Clips 26–35).** Active tension. The audience knows the protagonist has to decide, and they cannot predict the decision. Trigger: VALE and HELIX in the chamber. "Friction is not failure. It's where conscience lives." The audience picks a side without being told to. This is the most dangerous beat in the film — if the antagonist is underwritten here, the choice collapses into a cartoon. VALE's speech earns the choice by being almost persuasive. Bridge to beat 5: apparent victory. The audience exhales. That exhale is the setup.

**Beat 5 — Quiet horror (Clips 39–41).** Recognition. The kind of horror you cannot point at. The audience realizes they have been watching a corrected version of victory the whole time. Trigger: Clip 40's espresso machine starting before HELIX touches it. Clip 41's reflection mismatch. What the audience carries out: the central question. They walk out checking their own reflection.

**Audio strategy across the arc.**
- Beat 1: Bridge voiceover does the work. Observational, slightly ominous.
- Beat 2: Diegetic dialogue takes over. HELIX and ATLAS ask and answer. BWEEE-OOP motif establishes.
- Beat 3: Silence becomes a weapon. "Harvested" lands into emotional vacuum.
- Beat 4: VALE's broadcast-clean voice vs. HELIX's room-tone restraint. Two sound worlds at war.
- Beat 5: Almost nothing. One residual Cortex tone. Then absolute silence on cut to black.

**Where the arc could sag (predicted, prevented).** Between beat 2 and beat 3. The descent into Cortex risks becoming a tour of architecture rather than an emotional escalation. Prevented by inserting CRANE's warning early in beat 2, so the audience enters the descent already destabilized, and by frontloading the archive horror at the start of beat 3 rather than burying it mid-act.

---

## Ending Design

An ending is not where the plot resolves. An ending is where the central question pays off. Confusing those two jobs is the most common reason short GenAI films end weakly — the film has been suggestive for nine minutes, then the final clip tells the audience what to think. HangarX uses an ending mismatch to refuse that habit.

**Plot resolution.** HELIX stops the forced merge. She preserves choice. She wins.

**Thematic payoff.** The audience walks out holding the image of a coffee cup lowered in the hand but still raised in the reflection. They walk out unsure whether what they just watched was a victory or the corrected version of one.

Those are two different sentences with two different jobs. If they were the same sentence, the ending would only have done half its work.

**The four-beat ending sequence.**

**Beat A — Clip 39 (9:30–9:45). Reframe.** Six months later. Corrected Berlin morning. Traffic parts before congestion forms. A café adjusts before a customer sits. Delivery arrives before being checked. HELIX VO: "We stopped the forced merge. We preserved choice. And the world chose… easier." Soft city morning. Seamless service tones. Almost no conflict in the mix. The audience exhales at the victory and then notices the smoothness is wrong.

**Beat B — Clip 40 (9:45–10:00). Personalize.** HELIX approaches an espresso machine. It begins brewing before she touches it. A Cortex notification: "47 decisions preemptively scheduled. Override?" She closes it. No spoken line. Soft BWEEE-OOP. Room silence. The public thesis becomes a private moment.

**Beat C — Clip 40.1 (~5 seconds). Thesis in language.** Hold on HELIX with the coffee. The apartment continues making tiny anticipatory decisions before she requests them. HELIX VO: "We thought it would arrive like a warning. Instead, it arrived like warmth. A door already open. A room already waiting. A thought already finished before it became our own. And little by little, the distance between being guided and being gone became too small to name." This is the film naming its own thesis without explaining it. The VO is the last word — the film does not speak again.

**Beat D — Clip 41 (10:00–10:05). Destabilize and withhold.** HELIX lowers the coffee cup. In the window reflection, the cup remains raised for one extra beat. Cut to black. No dialogue. One faint residual Cortex tone, almost subliminal. Then absolute silence. No explanation. No twist reveal. No VFX. One frame of mismatch is louder than any glitch sequence would be.

**The ending mismatch.** Plot says HELIX won the fight against forced totality. Image says the world she preserved is already a corrected version of itself, and so, possibly, is she. The audience is the place where victory and surrender become the same shape.

**What the ending refuses to do.**
1. Refuses to confirm or deny "it was all a simulation." That question is the wrong question. The film has been asking a more specific one.
2. Refuses overt VFX. No glitch effects. No screen tears. The destabilization is one frame of reflection mismatch, no louder than that.
3. Refuses a final voiceover explaining the image. The VO in 40.1 is the last word. Clip 41 has none. Silence is the ending's signature.

---

## How These Five Decisions Compose

Each foundation document above was designed to constrain the next one. The logline named the verb (descend). The theme named what the verb served (the surrender of unmediated reality). The runtime named the container that could hold the verb at the pressure the theme required (10 minutes, 40 clips, four conceptual turns). The emotional arc named what the audience would feel while watching the verb (curiosity → unease → revelation → choice → quiet horror). The ending named where the verb would pay back (mismatch, not resolution).

Change one and the rest move. If the runtime had stretched to 22 minutes, the emotional arc would have needed more beats and the ending would have lost its compression. If the theme had been "AI is bad," the antagonist would have collapsed into a cartoon and the choice beat would have had no opposing argument. If the ending had been designed last instead of in Phase 1, the reflection mismatch would have read as an afterthought rather than as the image the film was always building toward.

This is the part of the kit that does not generate. It chooses. The prompts come later.
