# HANGAR X: THE MIRROR PROTOCOL — Audio Strategy (Filled)

**Phase 6 · Add audio structure — worked example**

This is the complete audio strategy for HANGAR X. It consolidates motif library, character voice notes, per-act audio progression, and a "what we cut" section. Use it as a reference for how the templates in Part V compose into a finished audio bible.

---

## 1. Core sonic identity

A restrained near-future audio world where infrastructure sounds intelligent, elegant, and quietly invasive. The mix is controlled rather than chaotic. Sound reveals system presence before the visuals fully explain it. No traditional score; the motif library and room tone beds do the structural work.

The audience should leave the film with one realization they cannot quite name: the calm sound of the world was the proof of what had happened.

---

## 2. Motif library

### BWEEE-OOP — reality-authentication notification
- Soft two-tone UI notification. Second tone falls a minor third below the first.
- Plays when Cortex schedules, anticipates, or authenticates something.
- Withheld during HELIX's interior moments, Crane's archive horror lines, and the direct VALE confrontation.
- Variants: clean on first read; faintly longer tail by Clip 40; almost subliminal in Clip 41.

### Coherence tone — systems aligning too perfectly
- Low synchronized harmonic with a faint upper partial. Not quite musical, not quite mechanical.
- Plays during synchronized data events and faintly under VALE broadcasts.
- Withheld in action and kinetic confrontation.
- First introduction Clip 3; folded into corrected-city ambience by Clip 39.

### Data whispers — Cortex layer presence
- Layered fragments of harvested human voice, ad copy, laughter shards. No phrase legible.
- Plays during deep system reveals and archive descents.
- Densest in Clip 9 (the harvested archive).
- Withheld in surface-world scenes.

### HELIX room tone — loft HVAC and electrical resonance
- Continuous HVAC bed with faint 60-cycle electrical undertone. Trace wet-street city bleed through windows.
- The bed always runs when she is in the apartment. If it drops, that is the alarm.
- Almost zeroed at the final beat of Clip 41.

### VALE broadcast clarity — zero room coloration
- Broadcast-clean voice. No reverb. Spectrally precise, lightly compressed.
- The absence of room is the meaning. VALE is infrastructure, not a man in a chamber.
- Replaced with thin architectural chamber tone during the direct Clip 33 confrontation, where he is forced to be physical.

### Layer-1 resonance — the substrate itself
- Deep, calm architectural hum. Sub-bass with slow harmonic drift. Geological rather than threatening.
- Plays in substrate scenes and Cortex-implicit chamber moments.
- Withheld in normal life. By the ending, retreated entirely into BWEEE-OOP and room tone — the substrate no longer needs to announce itself.

---

## 3. Room tone beds

| Location | Components | Notes |
|---|---|---|
| HELIX loft (day) | HVAC, 60-cycle electrical, wet-street bleed | Her acoustic identity |
| HELIX loft (corrected) | Same bed plus faint predictive UI hush | The wrongness is in the bed |
| Berlin street (delegated) | Sparse morning hum, transit tones, distant drones | Carries into Clip 2 |
| NeuralCorp chamber | Minimal architectural chamber tone | Used in VALE direct scenes |
| Archive / Layer-1 | Ghost packets, broken voices, destabilized spatial resonance | Used sparingly |
| VALE broadcast space | Near-zero bed | The point is the absence |

---

## 4. Character voice signatures

### HELIX (Kira Vasquez)
- Female, early 30s, mid pitch with slight fall at phrase ends, warm-but-dry timbre
- Mid-distance mic with apartment room tone underneath
- Very high restraint; pressure shows through stillness, not volume
- Distinguishing quirk: short breath before the load-bearing word
- Direction: pace measured, slightly slow; occasional `[HUSH]` for confessional moments

### VALE (Marcus Vale)
- Male, 50s, low-mid pitch, very stable, clean almost-compressed timbre
- Broadcast-clean acoustic space, zero room coloration
- Extreme restraint — sorrowful certainty, never raised
- Distinguishing quirk: deliberate caesura before doctrinal phrases
- Direction: every load-bearing doctrinal phrase gets a `[BEAT]`

### ECHO
- Androgynous, no specific age read, mid pitch with stable intonation
- Mid-distance mic with subtle harmonic stabilization underneath
- Serene; never escalates
- Distinguishing quirk: ends most phrases level rather than falling
- Direction: push the voice model toward natural warmth, apply harmonic shimmer in post — never ask the model to perform "synthetic"

### ATLAS / CRANE
- Male, older (60s read), deliberate pace, low pitch with measurable instability under stress
- Intimate-mic voice with amber-gold structural resonance underneath
- Emotionally intimate; cracks allowed
- Distinguishing quirk: half-second hesitation before naming the worst things
- Direction: the breath before "harvested" is the line — protect it

### Cortex
- Not voiced. Present as calm, deep, architectural intelligence hum.
- Cortex never speaks. If it spoke, it would lose its threat — it works because it shapes events without language.

---

## 5. Per-act audio progression

The film's 10 minutes break into five audio acts. Each act has a dominant audio behavior.

### Act I — Delegation (Clips 1–5)
**Dominant audio: sparse hum + first BWEEE-OOP.**

The delegated world is acoustically calm. Sparse city hum, autonomous transit tones, soft UI notification chimes, data-stream whispers in the deep background. The first BWEEE-OOP tail bridges Clip 1 into Clip 2 — the audience hears the cue before they know what it means. By Clip 3, the coherence tone arrives underneath the synchronized-pattern reveal. Layer-1 resonance is introduced very low in Clip 4 beneath the Cortex substrate exposure.

The audience should be sonically settled by the end of Act I. The calm is the trap.

### Act II — Descent (Clips 6–18)
**Dominant audio: coherence tones surfacing; data whispers introduced.**

The archive descent and the harvested-archive horror anchor this act. Data whispers reach their densest deployment in Clip 9 — the harvested fragments make Cortex's source material audible without explaining it. The coherence tone, previously a single deployment, now appears under multiple scenes and starts to shade VALE's surveillance moments. The room tone beds shift more often as HELIX moves between locations.

Crane's archive horror line ("They were harvested") lands against a hard cut to silence. This is the first major bed-drop in the film. The audience does not consciously notice the bed has been pulled — they notice the line.

### Act III — Doctrine (Clips 19–28)
**Dominant audio: harmonic peak; VALE broadcast clarity dominates.**

VALE's broadcast doctrine (Clip 24) is the structural midpoint and the audio high point. Broadcast-clean voice over near-zero bed. Subtle reality-authentication shimmer underneath. The coherence tone returns very low in the mix during the doctrine — the audience hears VALE and feels something behind him agreeing.

This is the only act where the film's audio palette runs near full. Layer-1 resonance, coherence tone, VALE broadcast clarity, and data whispers all touch the act. After this, the palette deliberately thins.

### Act IV — Confrontation (Clips 29–38)
**Dominant audio: system strain; broadcast clarity broken.**

The direct HELIX/VALE confrontation in the NeuralCorp chamber (Clip 33) is the first time VALE has a room around him. Broadcast clarity is replaced with thin architectural chamber tone. He sounds smaller. He is.

System strain enters the mix — low-end pressure, the coherence tone fraying slightly at its upper partial. Motifs are dialed back rather than added. The film stops introducing new audio material in this act.

The act ends with the forced merge averted — narratively a victory, audibly an exhale.

### Act V — Correction (Clips 39–41)
**Dominant audio: over-clean; final silence.**

The corrected city of Clip 39 is the audio thesis statement: peaceful and wrong. Soft city morning, seamless service tones, distant transit, almost no conflict in the mix. The audience should feel the mix is too clean before they can name why.

Clip 40 brings the BWEEE-OOP back as both interface cue and moral punctuation — the espresso machine starts before HELIX touches it, the "47 decisions" notification fires. Clip 40.1 holds her in the apartment under philosophical VO with a foreign predictive UI hush sitting in the low end of her bed.

Clip 41 is the final beat. Room tone dials almost to zero. One faint residual Cortex tone or distant BWEEE-OOP. Reflection mismatch. Absolute silence on cut to black — every layer zero for the first and only time in the film.

The audience has been listening to a corrected world for ten minutes. The silence is the proof that they were.

---

## 6. Audio bridge map (selected handoffs)

| Cut | Carries across | Breaks at cut |
|---|---|---|
| Clip 1 → Clip 2 | BWEEE-OOP tail; thinning city hum | Wide social bed → HELIX loft bed |
| Clip 2 → Clip 3 | HELIX loft bed; faint synchronized click | VO ends |
| Clip 3 → Clip 4 | Coherence tone (low) | Foreground synchronized clicks resolve |
| Clip 8 → Clip 9 | Layer-1 resonance | Surface beds replaced with archive bed |
| Clip 9 → Clip 10 | Hard cut to silence after "harvested" | Bed re-enters on VALE command space |
| Clip 23 → Clip 24 | Reality-authentication shimmer | Bed thins toward broadcast-clean |
| Clip 33 → Clip 34 | Architectural chamber tone | VALE broadcast clarity lost |
| Clip 38 → Clip 39 | Light system ambience | Mid-film palette retired |
| Clip 39 → Clip 40 | Predictive service tones | Outdoor bed → indoor bed |
| Clip 40 → Clip 40.1 | HELIX loft bed | BWEEE-OOP does not carry |
| Clip 40.1 → Clip 41 | HELIX loft bed (dialed low) | VO ends |
| Clip 41 → black | Nothing | Absolute silence |

---

## 7. What we cut (and why)

A short film's audio strategy is partly a record of decisions that were tried and rejected. Documenting these protects the final mix from drifting back toward them.

- **Traditional musical score across the ending.** Tested as a swelling minimal piano motif under Clips 39–41. It made the ending feel like melancholy instead of horror. Cut. The motif library and room tone beds carry the ending without score.
- **A VALE-specific musical theme.** Tested as a low brass-and-synth swell underneath his broadcasts. Cut for the same reason VALE doesn't have a room — adding a musical signature would have made him a character with a theme song. He works as infrastructure with a voice.
- **BWEEE-OOP in Clip 33.** The motif was placed under the direct confrontation as a Cortex presence cue. Cut. Cortex should not be present in the moment HELIX and VALE meet face to face — that is the one room where the system is not in charge.
- **Heartbeat motif for HELIX under tension.** Tested as a low pulse during the archive descent. Cut. Too on-the-nose, and it dragged her from "exhausted-alert" toward "scared." Her character is restraint; the audio cannot perform the emotion she withholds.
- **Reverb on VALE's voice during the chamber confrontation.** Briefly added to give the broadcast voice "place." Cut and replaced with a thin architectural chamber tone. Reverb made him sound powerful; the thin chamber tone makes him sound smaller in HELIX's room, which is the point.
- **A musical sting on the reflection mismatch.** Tested. Cut. A sting tells the audience "this is the twist." Absolute silence makes them ask whether they saw it.
- **Layer-1 resonance through Act IV.** Held over from Act III into the confrontation arc. Cut. The substrate retreating into BWEEE-OOP and room tone is the audio version of the film's ending thesis — Cortex no longer needs to announce itself.
- **An ECHO musical theme.** Tested as a warm choral cluster around her appearances. Cut. The harmonic shimmer on her voice does the work; a theme made her feel like a fantasy character rather than an emergent intelligence.
- **Diegetic news radio fragments during Act II.** Tested as a way to surface political context. Cut. The data whisper layer already carries the "harvested human texture" idea more effectively, and news fragments dated the film.

---

## 8. Final integration notes

- The audio bible runs to one document so the mix engineer, editor, and writer share a single source of truth.
- Every clip's per-clip sound design template (see Part V file 05) references this document for motifs and beds.
- Mix priorities, in order: protect the bed continuity, protect the VO breath placement, protect the silences, then place motifs, then everything else.
- Final QA listen passes are done at two playback levels: nominal cinema reference and a quiet domestic level. The Clip 41 silence must read as silence at both.

The film's central thesis — that the end of freedom may look like comfort — is delivered as much by audio as by image. The visuals show a calm world. The audio is the evidence that the calm is engineered.
