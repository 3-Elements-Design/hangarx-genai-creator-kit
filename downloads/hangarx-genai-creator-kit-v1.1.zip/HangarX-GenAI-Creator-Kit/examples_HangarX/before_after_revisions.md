# HANGAR X — Before / After Revisions

**Phase 7 · Iterate weak scenes · Worked example**

Four worked rewrites from the HANGAR X production. Each one followed the same loop: identify the weak clip, diagnose which of the three jobs was missing, rewrite the prompt or the line, regenerate, compare. These are the receipts for the method described in `Part_VI_Production_Assembly/03_iteration_loop.md`.

Each example has the same structure:

1. **Original prompt or beat** — what was generated first
2. **What was failing** — symptom, not diagnosis
3. **Diagnosis** — which of the three jobs (atmosphere / information / handoff) was absent
4. **Revised prompt or beat** — the rewrite
5. **Why it landed** — what changed and why it works

Read them in order. The pattern repeats. Most weak clips fail the information job, the handoff job, or both. Atmosphere alone is almost never the problem.

---

## Example 1 — HELIX Introduction (Clip 2, 0:15–0:30)

### Original beat

A wide-to-tight on HELIX at her workstation in the Berlin loft. Floor-to-ceiling windows, blue dawn outside, amber UI light inside. She is working. The shot lingers on her face, the city, the interface.

**Original prompt notes:**
- Subject: HELIX at workstation
- Mood: cinematic dawn, contemplative
- Camera: slow push-in, 35mm, shallow depth
- Audio: ambient city, low hum

### What was failing

The clip looked great. Posters could have been pulled from it. But by 0:25 the audience had no reason to keep watching. It played as a beautiful but inert mood board.

### Diagnosis

**Atmosphere:** strong. World-class even.
**Information:** missing. The audience could not finish "in this clip, we learn that ____."
**Handoff:** missing. The clip resolved on HELIX's face, which is closed. Nothing pointed into Clip 3.

The clip was doing one job in a tuxedo.

### Revised beat

Same visual frame. Added a VO line during the push-in. Changed the ambient agent streams to be *visibly moving* before HELIX acts — the city's automation pre-acting around her becomes the visual seed for the next clip's reveal.

**Revised prompt additions:**
- Subject: HELIX at workstation. Ambient agent streams visible in the loft air, moving with purpose before she touches the interface.
- Audio: ambient city carried directly from Clip 1, with a low coherence tone fading up under the VO
- VO: "Most people only noticed AI when it helped them. HELIX noticed it when it stopped asking."
- Handoff: the agent streams continue past the cut; the anomaly in Clip 3 is the resolution of what they were already doing

### Why it landed

Information was added directly to the visual (streams pre-acting) and the audio (VO that names her specific attention). Handoff was added by leaving the agent streams unresolved — they continue into Clip 3, where they synchronize into the impossibility. The atmosphere did not change. The two missing jobs got added without overloading the shot.

The viewer is no longer just observing mood. They are being pulled into a discovery.

---

## Example 2 — The Anomaly Reveal (Clip 3, 0:30–0:45)

### Original beat

HELIX studies her screens. A pattern is visible across them. The camera moves between her face and the UI. The pattern is there if you know what to look for.

**Original prompt notes:**
- Subject: HELIX at screens
- Visuals: distributed pattern across multiple displays
- Mood: investigative
- Dialogue: minimal

### What was failing

The audience could see something was happening but did not know what they were supposed to feel about it. The moment played as observational rather than dramatic. People watching with the sound on did not lean forward.

### Diagnosis

**Atmosphere:** present.
**Information:** technically present, but buried. The "thing being learned" was abstract and in the periphery of the frame.
**Handoff:** weak. The clip resolved on HELIX still looking at the screens. Pattern visible, no diagnosis.

The information was there. It was not named. Visible is not the same as legible.

### Revised beat

Added a short Q&A between HELIX and ATLAS. The pattern resolves into a single coordinated impossibility — the same micro-decision being made by millions of agents simultaneously. HELIX asks. ATLAS answers in one line.

**Revised dialogue:**
- HELIX: "These aren't independent. They're synchronized."
- ATLAS: "Twelve million agents. One decision."

**Revised prompt additions:**
- Visual: pattern across screens resolves into a single coherence — same vector, same timing, all at once
- Audio: the synchronized clicks of agent decisions resolve into one coherence tone
- Handoff: HELIX's next action (descend into the hidden layer) is set up by the question she just had answered

### Why it landed

The information stopped being abstract and became diagnostic. HELIX naming the pattern, ATLAS confirming it — that turns "I see something" into "we have a problem." Audio matched the visual: a wash of clicks resolving into one tone is the synchronization made audible. The handoff is now intellectual — the next clip has to answer what made twelve million agents move as one.

Atmosphere into diagnosis. The mystery hardened.

---

## Example 3 — VALE's Broadcast (Clip 24, 5:45–6:00)

### Original beat

VALE addresses an audience. Severe symmetry, glass chamber, broadcast lighting. He delivers a short authoritarian line about order and necessity. He looks the part.

**Original line:**
> "Some choices must be made for the species. We have made them."

### What was failing

VALE read as a generic villain. The line was clear but compressed past the point of seduction. He was right-coded, the audience knew it, and there was no risk of being convinced by him. A flat antagonist makes the protagonist's resistance feel automatic instead of earned.

### Diagnosis

**Atmosphere:** correct.
**Information:** present but thin. The audience learned VALE's position. They did not learn *why anyone would follow him*.
**Handoff:** the line landed but did not carry intellectual pressure into the next sequence.

The information was wrong-sized. Compressed past usefulness. You can fit an ideology in one sentence. You cannot fit a *seduction* in one sentence.

### Revised beat

Expanded the line into a short technocratic argument. VALE reframes collapse as a synchronization problem rather than a moral one. He sounds calm, humane, and frighteningly reasonable. The visuals stayed identical.

**Revised line:**
> "Civilizational collapse is not a moral failure. It is a latency problem. Every system that has ever ended ended because its components could not synchronize fast enough to survive what came next. We are not asking you to surrender choice. We are asking you to surrender the lag between choice and outcome. The mercy is the speed."

### Why it landed

The expanded language gives VALE a real worldview. "Latency failure" is technical, plausible, and reframes coercion as infrastructure. The phrase "the mercy is the speed" is the kind of line a smart person would underline in his book. Audience now understands why people would follow him — which makes HELIX's resistance dramatic instead of automatic.

The handoff also strengthened: VALE's doctrine becomes the intellectual pressure HELIX has to answer for the next twenty clips. The handoff is ideological, not just sonic.

Generic villain becomes ideologically dangerous. The film gets harder, which makes it better.

---

## Example 4 — The Ending Sequence (Clips 39, 40, 40.1, 41)

### Original beat

A single ending clip: HELIX wins, the system stabilizes, the city looks correct, fade to black. Some kind of glitch in the final frame. Thematic but generic.

**Original prompt notes:**
- Final shot: HELIX at window, city beneath
- Suggestion of a system anomaly in the final second
- Mood: ambiguous victory

### What was failing

The ending had the right theme but the wrong expression of it. It was flirting with "was it all a simulation?" territory — a beat the audience has seen many times. The thesis (comfort as the delivery system of surrender) was not landing in the final image.

### Diagnosis

The whole sequence was trying to do too much in one clip. Atmosphere, information, and handoff were all crammed into the same beat — which meant none of them landed cleanly. The fix was not to rewrite the clip. The fix was to split it into four.

**The diagnosis named the structural problem, not just the symptom.**

### Revised beat

Rebuilt the ending as four linked clips, each with its own job:

**Clip 39 — public thesis.**
A corrected city. Frictionless morning. Peaceful and slightly wrong.
- Atmosphere: peaceful and wrong
- Information: the corrected world is not dystopian. It is *nice*. That is the point.
- Handoff: zoom into a single domestic interior

**Clip 40 — domestic anticipation.**
A coffee machine starts before HELIX walks into the kitchen.
- Atmosphere: immaculate domestic silence
- Information: automation now acts *before* intention. The world has gotten ahead of choice.
- Handoff: the soft BWEEE-OOP tone carries into the next beat

**Clip 40.1 — philosophical bridge.**
HELIX at the window. A VO line over the visual.
- Atmosphere: low room tone, faint system ambience
- Information: the warning, spoken plainly. Comfort is the surrender.
- Handoff: the VO ends. The silence begins.

**Clip 41 — visual destabilization.**
HELIX's reflection. A millimeter mismatch — her reflection's eyes move a fraction before hers do.
- Atmosphere: absolute silence
- Information: reality may already be corrected
- Handoff: cut to black on the mismatch. No resolution.

### Why it landed

The thesis is now expressed at four scales: civic, domestic, philosophical, and personal. Each scale lands its own version of the same idea, and the cumulative effect is much stronger than any single ending clip could have carried.

The mismatch is millimeters, not spectacle. The audience either sees it or feels it. Either reading works — and both readings carry the thesis.

The film now ends on its own thesis: reality may still be real, but it may already be the corrected version of itself.

---

## What these four examples have in common

Three patterns repeat:

1. **The atmosphere was never the problem.** In all four cases, the visuals were already strong. Adding more "cinematic mood" would not have helped.

2. **The fix was almost always information + handoff.** Adding a line, a pre-acting visual, a sound that carries, an answered question. Small surgical additions, not rewrites from scratch.

3. **When the diagnosis named a structural problem (Example 4), the fix was to split, not to rewrite.** One clip carrying three jobs poorly is sometimes better solved by four clips each carrying one job well.

The loop is repeatable. Identify the weak clip with the pacing checklist. Diagnose which job is missing. Rewrite the smallest possible thing that adds the missing job. Regenerate. Compare.
